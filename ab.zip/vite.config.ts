import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import {defineConfig, Plugin} from 'vite';

function tatkalApiPlugin(): Plugin {
  const storageFilePath = path.resolve(__dirname, 'data/app_storage.json');
  function readStorage() {
    try {
      if (fs.existsSync(storageFilePath)) {
        return JSON.parse(fs.readFileSync(storageFilePath, 'utf8'));
      }
    } catch (e) {
      console.error('Failed to read storage', e);
    }
    return { version: 4, updatedAt: Date.now(), items: {} };
  }
  function writeStorage(data: any) {
    try {
      fs.writeFileSync(storageFilePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
      console.error('Failed to write storage', e);
    }
  }

  async function sendMailHelper(mailCfg: any, to: string, subject: string, html: string, text?: string) {
    const host = mailCfg.smtpHost || 'mail.tatkalguru.com';
    const port = Number(mailCfg.smtpPort) || 465;
    const user = (!mailCfg.smtpUser || mailCfg.smtpUser === 'info@tatkalguru.com') ? 'info@tatkalguru.com' : mailCfg.smtpUser;
    const pass = mailCfg.smtpPass || 'Rumi@1624';
    const senderEmail = (!mailCfg.senderEmail || mailCfg.senderEmail === 'info@tatkalguru.com') ? 'info@tatkalguru.com' : mailCfg.senderEmail;
    const senderName = mailCfg.senderName || 'Tatkal Guru';

    const transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
      tls: { rejectUnauthorized: false }
    });

    return await transporter.sendMail({
      from: `"${senderName}" <${senderEmail}>`,
      to,
      subject,
      html,
      text: text || html.replace(/<[^>]*>?/gm, '')
    });
  }

  return {
    name: 'tatkal-api-middleware',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const url = req.url || '';
        if (url.startsWith('/api/storage_bootstrap.php')) {
          res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
          const store = readStorage();
          const items: Record<string, any> = {};
          if (store.items) {
            Object.keys(store.items).forEach((k) => {
              if (['sh_current_user', 'sh_admin_session', 'sh_admin_security'].includes(k)) return;
              items[k] = store.items[k];
            });
          }
          const code = `(function(){try{var d=${JSON.stringify(items)};var m={};try{m=JSON.parse(localStorage.getItem("sh_sync_meta")||"{}")}catch(e){};Object.keys(d).forEach(function(k){var r=d[k];if(!r||typeof r!=="object")return;var st=Number(r.updatedAt||0),lt=Number(m[k]||0);if(localStorage.getItem(k)===null||st>lt){localStorage.setItem(k,String(r.value==null?"":r.value));m[k]=st;}});localStorage.setItem("sh_sync_meta",JSON.stringify(m));}catch(e){console.error("DB bootstrap failed",e);}})();`;
          res.end(code);
          return;
        }

        if (url.startsWith('/api/storage_get.php')) {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          const store = readStorage();
          res.end(JSON.stringify({
            ok: true,
            version: 4,
            updatedAt: Date.now(),
            items: store.items || {},
          }));
          return;
        }

        if (url.startsWith('/api/storage_sync.php') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => { body += chunk; });
          req.on('end', () => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            try {
              const parsed = JSON.parse(body);
              const store = readStorage();
              store.items = store.items || {};
              let accepted = 0;
              const now = Date.now();
              if (parsed.items) {
                Object.keys(parsed.items).forEach((k) => {
                  store.items[k] = parsed.items[k];
                  accepted++;
                });
              }
              store.updatedAt = now;
              writeStorage(store);
              res.end(JSON.stringify({ ok: true, accepted, updatedAt: now }));
            } catch (err: any) {
              res.statusCode = 400;
              res.end(JSON.stringify({ ok: false, error: err.message }));
            }
          });
          return;
        }

        if (url.startsWith('/api/gemini.php') || url.startsWith('/api/gemini')) {
          let body = '';
          req.on('data', (chunk) => { body += chunk; });
          req.on('end', async () => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            try {
              const data = body ? JSON.parse(body) : {};
              const action = data.action || 'ask';
              if (action === 'ask') {
                const prompt = (data.prompt || '').trim();
                if (!prompt) {
                  res.end(JSON.stringify({ ok: false, message: 'Please enter a question.' }));
                  return;
                }

                // Try live Gemini API if key is valid
                let answer = '';
                const apiKey = process.env.GEMINI_API_KEY;
                if (apiKey && !apiKey.startsWith('AQ.')) {
                  try {
                    const { GoogleGenAI } = await import('@google/genai');
                    const ai = new GoogleGenAI({ apiKey });
                    const response = await ai.models.generateContent({
                      model: 'gemini-2.5-flash',
                      contents: `You are the AI Assistant for "Deepak Bhai Tatkal Guru" (tatkalguru.com), India's premier portal for Railway Tatkal tools, Low-latency Indian VPS, SMS OTP verifications, IRCTC autofill, proxies, and digital utility services.
Answer user questions concisely, politely, and practically in Hindi or Hinglish or English as requested.
Key facts:
- AC Tatkal booking starts at 10:00 AM; Non-AC (Sleeper) starts at 11:00 AM.
- VPS provided have ultra-low ping (<2ms to Indian servers) with Windows/Linux and Virtualizor control panel.
- Wallet balance recharge is done via UPI QR Code and entering the 12-digit UTR number.
- SMS OTP service supports IRCTC, Google, Telegram, WhatsApp, etc.
- Never ask for or expose real user passwords, OTPs, or financial secrets.

User Question: ${prompt}`,
                    });
                    answer = response.text || '';
                  } catch (apiErr: any) {
                    console.log('Gemini API call skipped or errored, using domain assistant:', apiErr.message);
                  }
                }

                if (!answer) {
                  const p = prompt.toLowerCase();
                  if (p.includes('tatkal') && (p.includes('time') || p.includes('samay') || p.includes('kab'))) {
                    answer = '🚄 **Tatkal Booking Timings:**\n- **AC Classes (2A, 3A, 3E, CC, EC):** Subah **10:00 AM** par open hota hai.\n- **Non-AC / Sleeper (SL, 2S):** Subah **11:00 AM** par open hota hai.\n\n⚡ **Tip:** Hamare Tatkal Guru Low-Latency VPS aur Fast Autofill tool ka use karke aap 10:00 ya 11:00 baje first second me ticket confirm book kar sakte hain.';
                  } else if (p.includes('vps') || p.includes('server') || p.includes('speed')) {
                    answer = '💻 **Tatkal Guru VPS Features:**\n- **Ultra Low Ping:** Indian Datacenter se connect jisse IRCTC server par < 2ms latency milti hai.\n- **Virtualizor Panel:** Instant Start, Stop, Reboot aur Re-install.\n- **Windows & Linux:** Pre-configured OS jo high-speed automation aur tatkal tools ke liye optimized hai.';
                  } else if (p.includes('recharge') || p.includes('wallet') || p.includes('payment') || p.includes('upi') || p.includes('utr')) {
                    answer = '💰 **Wallet Recharge Kaise Karein:**\n1. Website par **Add Balance / Wallet** section me jayein.\n2. Screen par dikhaye gaye **UPI QR Code** par kisi bhi UPI app (PhonePe, GPay, Paytm) se pay karein.\n3. Payment ke baad **12-digit UTR / Reference No.** daalkar submit karein.\n4. Aapka balance instantly credit ho jayega!';
                  } else if (p.includes('sms') || p.includes('otp')) {
                    answer = '📱 **SMS OTP Service:**\n- Tatkal Guru par aapko IRCTC, WhatsApp, Telegram, Google aur kai services ke liye fresh Indian virtual numbers milte hain.\n- Instant OTP delivery aur automatic refund agar OTP na mile.';
                  } else if (p.includes('software') || p.includes('tool') || p.includes('autofill') || p.includes('promax')) {
                    answer = '⚡ **Tatkal Software & Autofill:**\n- Fast form auto-fill, master list integration aur direct UPI payment bypass.\n- Software license key wallet balance se purchase karte hi automatically deliver ho jati hai.';
                  } else if (p.includes('admin') || p.includes('login')) {
                    answer = '🔐 **Admin Access:**\n- Admin Portal access karne ke liye keyboard par `Ctrl + Shift + A` dabayein ya URL ke aage `#admin` open karein.\n- Default 6-digit PIN se login karein.';
                  } else {
                    answer = `✦ **Tatkal Guru AI Support:**\nAapke sawal "${prompt}" ke sandarbh me: Tatkal Guru portal par aapko high-speed Indian VPS, Railway Tatkal tools, SMS OTP verification, aur automatic digital services milti hain.\n\nKoi specific jaankari chahiye toh niche diye gaye topics me se puchiye:
- 🚄 Tatkal booking timing aur rules
- 💻 Best VPS configuration
- 💰 Wallet payment aur UTR verification
- 📱 SMS OTP verification`;
                  }
                }

                res.end(JSON.stringify({ ok: true, answer }));
                return;
              }

              res.end(JSON.stringify({ ok: true, message: 'Gemini service active' }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ ok: false, error: err.message }));
            }
          });
          return;
        }

        if (url.startsWith('/api/notify.php') || url.startsWith('/api/mail.php')) {
          let body = '';
          req.on('data', (chunk) => { body += chunk; });
          req.on('end', async () => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            try {
              const data = body ? JSON.parse(body) : {};
              const action = data.action || (data.type ? 'send' : 'get_settings');
              const store = readStorage();
              store.items = store.items || {};

              let apiSettings: any = {};
              try {
                if (store.items.sh_api_settings && store.items.sh_api_settings.value) {
                  apiSettings = JSON.parse(store.items.sh_api_settings.value);
                }
              } catch (e) {}

              const mail = Object.assign({
                enabled: true,
                smtpHost: 'mail.tatkalguru.com',
                smtpPort: 465,
                smtpUser: 'info@tatkalguru.com',
                smtpPass: 'Rumi@1624',
                senderName: 'Tatkal Guru',
                senderEmail: 'info@tatkalguru.com',
                encryption: 'SSL',
                sendOrderEmail: true,
                sendPasswordResetEmail: true
              }, apiSettings.mailSettings || {});
              if (!mail.smtpUser || mail.smtpUser === 'info@tatkalguru.com') mail.smtpUser = 'info@tatkalguru.com';
              if (!mail.smtpPass) mail.smtpPass = 'Rumi@1624';
              if (!mail.senderEmail || mail.senderEmail === 'info@tatkalguru.com') mail.senderEmail = 'info@tatkalguru.com';

              const notif = apiSettings.notificationSettings || {};
              const adminDest = notif.adminEmail || 'irsad98@gmail.com';

              if (action === 'get_settings') {
                const merged = {
                  enabled: true,
                  adminEmail: adminDest,
                  email: Object.assign({}, mail, notif.email || {}),
                  events: notif.events || {}
                };
                res.end(JSON.stringify({ ok: true, settings: merged }));
                return;
              }

              if (action === 'save_settings') {
                apiSettings.notificationSettings = Object.assign({}, apiSettings.notificationSettings || {}, data.settings || {});
                if (data.settings && data.settings.email) {
                  apiSettings.mailSettings = Object.assign({}, apiSettings.mailSettings || {}, data.settings.email);
                }
                store.items.sh_api_settings = {
                  value: JSON.stringify(apiSettings),
                  updatedAt: Date.now()
                };
                writeStorage(store);
                res.end(JSON.stringify({ ok: true, message: 'Settings saved successfully.' }));
                return;
              }

              if (action === 'test') {
                const to = data.to || adminDest;
                try {
                  const info = await sendMailHelper(mail, to, 'Tatkal Guru - System SMTP Verification Test', `
                    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;border:1px solid #e2e8f0;border-radius:12px;background:#ffffff;color:#1e293b">
                      <div style="background:#0d2b52;color:#ffffff;padding:16px 20px;border-radius:8px;margin-bottom:20px">
                        <h2 style="margin:0;font-size:18px">Tatkal Guru - SMTP Verification Test</h2>
                      </div>
                      <p style="font-size:15px">Hello Administrator,</p>
                      <p style="font-size:14px;line-height:1.6">This is a live test notification verifying that the <strong>Tatkal Guru</strong> email delivery system is fully active, operational, and connected to your official SMTP server.</p>
                      <div style="background:#f8fafc;border-left:4px solid #10b981;padding:12px 16px;margin:18px 0">
                        <div style="font-size:13px;font-weight:bold;color:#0f766e">✓ SMTP Status: Active & Operational</div>
                        <div style="font-size:12px;color:#475569;margin-top:4px">Server: mail.tatkalguru.com:465 (SSL) | Sender: ${mail.senderEmail}</div>
                        <div style="font-size:12px;color:#475569">Target Recipient: ${to}</div>
                      </div>
                      <p style="font-size:12px;color:#64748b;margin-top:20px">Timestamp: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>
                    </div>
                  `);
                  res.end(JSON.stringify({ ok: true, message: `✓ Email successfully delivered to ${to}! (ID: ${info.messageId})` }));
                } catch (err: any) {
                  res.end(JSON.stringify({ ok: false, message: `SMTP dispatch failed: ${err.message}` }));
                }
                return;
              }

              if (action === 'order') {
                const order = data.order || {};
                const toUser = data.to || order.userEmail;
                const id = order.id || 'ORD_' + Date.now();
                const amount = order.totalAmount || 0;
                const product = order.productName || order.productId || 'Digital Product';
                const qty = order.quantity || 1;
                const payment = order.paymentMethod || 'Wallet';
                const status = order.status || 'Delivered';
                const created = order.createdAt || new Date().toISOString();
                const userEmail = order.userEmail || toUser;
                const userMobile = order.userMobile || '';
                const deliveredData = order.deliveredData || '';

                if (toUser && toUser.includes('@')) {
                  try {
                    await sendMailHelper(mail, toUser, `Order Confirmation - ${id}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033">
                        <div style="background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0">
                          <h2 style="margin:0">Tatkal Guru</h2>
                          <div style="margin-top:5px;opacity:.9">Order Confirmation - ${id}</div>
                        </div>
                        <div style="padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px">
                          <p>Thank you! Your order has been placed successfully.</p>
                          <table cellpadding="8" style="border-collapse:collapse;width:100%;font-size:14px">
                            <tr><td><b>Order ID</b></td><td>${id}</td></tr>
                            <tr><td><b>Product</b></td><td>${product}</td></tr>
                            <tr><td><b>Quantity</b></td><td>${qty}</td></tr>
                            <tr><td><b>Total Paid</b></td><td><strong>₹${amount}</strong></td></tr>
                            <tr><td><b>Payment Method</b></td><td>${payment}</td></tr>
                            <tr><td><b>Status</b></td><td>${status}</td></tr>
                            <tr><td><b>Order Date</b></td><td>${created}</td></tr>
                          </table>
                          <h3 style="margin-top:20px">Delivered Item / Credentials:</h3>
                          <div style="background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word">${deliveredData || 'Processing delivery'}</div>
                        </div>
                      </div>
                    `);
                  } catch (err: any) {
                    console.error('User order email failed:', err);
                  }
                }

                try {
                  await sendMailHelper(mail, adminDest, `🔔 New Order Received - ${id} (₹${amount})`, `
                    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033">
                      <div style="background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0">
                        <h2 style="margin:0">Tatkal Guru - Admin Order Alert</h2>
                      </div>
                      <div style="padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px">
                        <p style="font-size:16px;color:#10b981;font-weight:bold">🔔 New Order Placed on Tatkal Guru!</p>
                        <table cellpadding="8" style="border-collapse:collapse;width:100%;font-size:14px">
                          <tr><td><b>Order ID</b></td><td>${id}</td></tr>
                          <tr><td><b>Customer Email</b></td><td>${userEmail}</td></tr>
                          <tr><td><b>Customer Mobile</b></td><td>${userMobile}</td></tr>
                          <tr><td><b>Product</b></td><td>${product}</td></tr>
                          <tr><td><b>Quantity</b></td><td>${qty}</td></tr>
                          <tr><td><b>Total Paid</b></td><td><strong>₹${amount}</strong></td></tr>
                          <tr><td><b>Payment Method</b></td><td>${payment}</td></tr>
                          <tr><td><b>Status</b></td><td>${status}</td></tr>
                          <tr><td><b>Order Time</b></td><td>${created}</td></tr>
                        </table>
                        <h3 style="margin-top:20px">Delivered / Stock Data:</h3>
                        <div style="background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word">${deliveredData || 'None'}</div>
                        <p style="margin-top:20px"><a href="https://tatkalguru.com/#admin" style="display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold">Open Tatkal Guru Admin Panel</a></p>
                      </div>
                    </div>
                  `);
                } catch (err: any) {
                  console.error('Admin order alert email failed:', err);
                }

                res.end(JSON.stringify({ ok: true, message: 'Order confirmation and admin notification dispatched.' }));
                return;
              }

              if (action === 'password_reset') {
                const identifier = String(data.identifier || data.to || data.email || '').trim();
                if (!identifier) {
                  res.end(JSON.stringify({ ok: false, message: 'Please enter your registered email address or mobile number.' }));
                  return;
                }

                const store = readStorage();
                let users: any[] = [];
                try {
                  users = JSON.parse(store.items?.sh_users?.value || '[]');
                } catch (e) {}

                const idLower = identifier.toLowerCase();
                const foundUser = users.find((u: any) =>
                  (u.email && u.email.toLowerCase() === idLower) ||
                  (u.mobile && (String(u.mobile) === identifier || String(u.mobile).includes(identifier) || identifier.includes(String(u.mobile)))) ||
                  (u.fullName && u.fullName.toLowerCase() === idLower)
                );

                let toUser = '';
                if (foundUser && foundUser.email) {
                  toUser = foundUser.email;
                } else if (identifier.includes('@')) {
                  toUser = identifier;
                } else if (data.to && String(data.to).includes('@')) {
                  toUser = String(data.to);
                } else if (data.email && String(data.email).includes('@')) {
                  toUser = String(data.email);
                }

                if (!toUser) {
                  res.end(JSON.stringify({ ok: false, message: 'No registered user account found with that mobile number or email.' }));
                  return;
                }

                const otp = Math.floor(100000 + Math.random() * 900000).toString();
                const otpsFile = path.resolve(__dirname, 'data/mail_otps.json');
                let otps: any = {};
                try { otps = JSON.parse(fs.readFileSync(otpsFile, 'utf8')); } catch(e) {}
                otps[toUser.toLowerCase()] = { otp, expiresAt: Date.now() + 15 * 60 * 1000, email: toUser };
                if (foundUser && foundUser.id) {
                  otps[String(foundUser.id)] = { otp, expiresAt: Date.now() + 15 * 60 * 1000, email: toUser };
                }
                fs.writeFileSync(otpsFile, JSON.stringify(otps, null, 2));

                try {
                  await Promise.race([
                    sendMailHelper(mail, toUser, 'Password Reset OTP - Tatkal Guru', `
                      <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;border:1px solid #e2e8f0;border-radius:12px;background:#ffffff;color:#1e293b">
                        <div style="background:#0d2b52;color:#ffffff;padding:16px 20px;border-radius:8px;margin-bottom:20px">
                          <h2 style="margin:0;font-size:18px">Tatkal Guru - Password Reset</h2>
                        </div>
                        <p>Hello,</p>
                        <p>Your password recovery OTP is:</p>
                        <div style="font-size:28px;font-weight:bold;letter-spacing:4px;color:#0d2b52;background:#f1f5f9;padding:12px 24px;border-radius:8px;display:inline-block;margin:12px 0">${otp}</div>
                        <p style="font-size:13px;color:#64748b">This OTP is valid for 15 minutes. If you did not request this, please ignore.</p>
                      </div>
                    `),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('SMTP timeout')), 3500))
                  ]);
                  res.end(JSON.stringify({
                    ok: true,
                    message: 'Password recovery OTP sent to ' + toUser + '! Check your inbox.',
                    otp: otp,
                    email: toUser
                  }));
                } catch (err: any) {
                  console.warn('Mail send notice:', err?.message);
                  res.end(JSON.stringify({
                    ok: true,
                    message: `Password recovery OTP generated for ${toUser}. (Enter OTP: ${otp})`,
                    otp: otp,
                    email: toUser
                  }));
                }
                return;
              }

              if (action === 'custom') {
                const to = data.to;
                const subject = data.subject || 'Message from Tatkal Guru';
                const message = data.message || '';
                await sendMailHelper(mail, to, subject, `<div style="font-family:Arial,sans-serif;padding:20px">${message.replace(/\\n/g, '<br>')}</div>`);
                res.end(JSON.stringify({ ok: true, message: 'Custom email sent to ' + to }));
                return;
              }

              // Event Dispatcher for all events
              const evType = data.type || data.event || action;
              const payload = data.payload || data || {};
              const userObj = payload.user || {};
              const itemObj = payload.item || {};
              const userEmail = userObj.email || payload.userEmail || (typeof payload.email === 'string' ? payload.email : '');
              const events = notif.events || {};

              if (evType === 'admin_new_balance_request' || evType === 'wallet' || evType === 'user_balance_add_request') {
                const amount = itemObj.amount || payload.amount || '0';
                const utr = itemObj.utrNumber || itemObj.utr || payload.utr || 'N/A';
                const uEmail = itemObj.userEmail || userEmail || 'Customer';
                const uMobile = itemObj.userMobile || userObj.mobile || 'N/A';

                if (events['admin_new_balance_request']?.email !== false) {
                  try {
                    await sendMailHelper(mail, adminDest, `🔔 New Balance Request (UTR: ${utr}) - ₹${amount}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - Balance Add Request</h2></div>
                        <p style="font-size:15px;color:#059669;font-weight:bold">A customer has submitted a wallet recharge request:</p>
                        <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                          <tr><td><b>UTR Reference Number:</b></td><td style="font-family:monospace;font-size:15px;color:#7c3aed"><b>${utr}</b></td></tr>
                          <tr><td><b>Recharge Amount:</b></td><td><strong style="color:#059669;font-size:16px">₹${amount}</strong></td></tr>
                          <tr><td><b>Customer Email:</b></td><td>${uEmail}</td></tr>
                          <tr><td><b>Customer Mobile:</b></td><td>${uMobile}</td></tr>
                          <tr><td><b>Time:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                        </table>
                        <p style="margin-top:20px"><a href="https://tatkalguru.com/#admin" style="display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold">Review & Approve in Admin Panel</a></p>
                      </div>
                    `);
                  } catch(e) { console.error('Admin balance alert failed:', e); }
                }

                if (uEmail && uEmail.includes('@') && events['user_balance_add_request']?.email !== false) {
                  try {
                    await sendMailHelper(mail, uEmail, `Balance Add Request Received - UTR: ${utr}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru</h2></div>
                        <p>Hello,</p>
                        <p>We have received your balance recharge request of <strong>₹${amount}</strong> with UTR reference <strong>${utr}</strong>.</p>
                        <p>Our team will verify your payment and credit your wallet shortly.</p>
                      </div>
                    `);
                  } catch(e) {}
                }
                res.end(JSON.stringify({ ok: true, message: 'Balance request notification dispatched.' }));
                return;
              }

              if (evType === 'user_registration_welcome' || evType === 'registration' || evType === 'admin_new_user_registration' || evType === 'user') {
                const uName = userObj.fullName || userObj.name || payload.fullName || 'Customer';
                const uEmail = userEmail || itemObj.email;
                const uMobile = userObj.mobile || itemObj.mobile || 'N/A';

                if (events['admin_new_user_registration']?.email !== false) {
                  try {
                    await sendMailHelper(mail, adminDest, `👤 New User Registration - ${uName}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - New Customer Signup</h2></div>
                        <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                          <tr><td><b>Name:</b></td><td>${uName}</td></tr>
                          <tr><td><b>Email:</b></td><td>${uEmail}</td></tr>
                          <tr><td><b>Mobile:</b></td><td>${uMobile}</td></tr>
                          <tr><td><b>Registered At:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                        </table>
                      </div>
                    `);
                  } catch(e) {}
                }

                if (uEmail && uEmail.includes('@') && events['user_registration_welcome']?.email !== false) {
                  try {
                    await sendMailHelper(mail, uEmail, `Welcome to Tatkal Guru, ${uName}!`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Welcome to Tatkal Guru</h2></div>
                        <p>Hello <strong>${uName}</strong>,</p>
                        <p>Welcome to Tatkal Guru! Your account has been registered successfully.</p>
                        <p>You can now log in, recharge your wallet, and purchase services seamlessly.</p>
                        <p style="margin-top:20px"><a href="https://tatkalguru.com" style="display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold">Go to Tatkal Guru Portal</a></p>
                      </div>
                    `);
                  } catch(e) {}
                }
                res.end(JSON.stringify({ ok: true, message: 'Registration notifications dispatched.' }));
                return;
              }

              if (evType === 'user_balance_approved' || evType === 'user_balance_rejected' || evType === 'admin_balance_approved_rejected') {
                const isApproved = evType === 'user_balance_approved' || payload.status === 'Approved';
                const amount = payload.amount || itemObj.amount || 0;
                const uEmail = payload.userEmail || userEmail;

                if (uEmail && uEmail.includes('@')) {
                  try {
                    await sendMailHelper(mail, uEmail, isApproved ? `Wallet Recharge Approved - ₹${amount}` : 'Wallet Recharge Notice', `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - Balance Update</h2></div>
                        <p>Hello,</p>
                        <p>Your wallet recharge of <strong>₹${amount}</strong> has been <strong>${isApproved ? 'Approved & Credited to your wallet' : 'Declined/Rejected'}</strong>.</p>
                        ${isApproved ? '<p style="color:#059669;font-weight:bold">Your new balance is updated and ready for instant use!</p>' : '<p style="color:#dc2626">Please re-verify your UTR number or contact support.</p>'}
                      </div>
                    `);
                  } catch(e) {}
                }
                res.end(JSON.stringify({ ok: true, message: 'Balance status notification dispatched.' }));
                return;
              }

              // Tatkal Request Alert to Admin
              if (evType === 'admin_tatkal_request' || evType === 'tatkal') {
                const train = itemObj.trainNumber || itemObj.train || payload.train || 'Tatkal Booking';
                const pnr = itemObj.pnr || payload.pnr || 'N/A';
                const uEmail = itemObj.userEmail || userEmail || 'Customer';
                try {
                  await sendMailHelper(mail, adminDest, `⚡ New Tatkal Booking Request - ${train}`, `
                    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                      <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - Tatkal Request</h2></div>
                      <p style="font-size:15px;color:#d97706;font-weight:bold">A new Tatkal service request was placed:</p>
                      <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                        <tr><td><b>Service/Train:</b></td><td>${train}</td></tr>
                        <tr><td><b>Customer:</b></td><td>${uEmail}</td></tr>
                        <tr><td><b>Details:</b></td><td>${JSON.stringify(itemObj || payload)}</td></tr>
                        <tr><td><b>Time:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                      </table>
                    </div>
                  `);
                } catch(e) {}
                res.end(JSON.stringify({ ok: true, message: 'Tatkal request alert dispatched.' }));
                return;
              }

              // SMS OTP Order Alert to Admin
              if (evType === 'admin_sms_otp_order' || evType === 'sms_order') {
                const service = itemObj.service || payload.service || 'IRCTC OTP';
                const num = itemObj.number || payload.number || 'N/A';
                const uEmail = itemObj.userEmail || userEmail || 'Customer';
                try {
                  await sendMailHelper(mail, adminDest, `📱 New SMS OTP Order - ${service}`, `
                    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                      <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - SMS OTP Order</h2></div>
                      <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                        <tr><td><b>Service:</b></td><td>${service}</td></tr>
                        <tr><td><b>Customer:</b></td><td>${uEmail}</td></tr>
                        <tr><td><b>Phone/Number:</b></td><td>${num}</td></tr>
                        <tr><td><b>Time:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                      </table>
                    </div>
                  `);
                } catch(e) {}
                res.end(JSON.stringify({ ok: true, message: 'SMS OTP order alert dispatched.' }));
                return;
              }

              // Fallback generic event dispatcher
              const subject = payload.subject || `Tatkal Guru Notification: ${evType}`;
              const msg = payload.message || JSON.stringify(payload);
              if (userEmail && userEmail.includes('@')) {
                try { await sendMailHelper(mail, userEmail, subject, `<p>${msg}</p>`); } catch(e) {}
              }
              if (adminDest) {
                try { await sendMailHelper(mail, adminDest, `[Admin Alert] ${subject}`, `<p>${msg}</p>`); } catch(e) {}
              }
              res.end(JSON.stringify({ ok: true, message: 'Event notification processed.' }));
              return;
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ ok: false, message: err.message }));
            }
          });
          return;
        }

        if (url.startsWith('/api/')) {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.end(JSON.stringify({ ok: true, message: 'Simulated API endpoint' }));
          return;
        }

        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), tatkalApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

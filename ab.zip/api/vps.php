<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok'=>false,'message'=>'POST required']);
    exit;
}

require_once __DIR__.'/dbcon.php';
require_once __DIR__.'/virtualizor_config.php';

function vps_out(bool $ok, string $message = '', array $extra = [], int $status = 200): never {
    http_response_code($status);
    echo json_encode(array_merge(['ok'=>$ok,'success'=>$ok,'message'=>$message], $extra),
        JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function input_json(): array {
    $raw = file_get_contents('php://input') ?: '';
    $in = json_decode($raw, true);
    return is_array($in) ? $in : $_POST;
}
function cfg(): array {
    $c = [
        'host'=>VIRTUALIZOR_HOST,
        'fallbackHost'=>VIRTUALIZOR_HOST,
        'key'=>VIRTUALIZOR_API_KEY,
        'pass'=>VIRTUALIZOR_API_PASS,
        'port'=>VIRTUALIZOR_PORT,
        'virt'=>VIRTUALIZOR_VIRT,
        'defaultOsId'=>VIRTUALIZOR_DEFAULT_OSID,
    ];
    try {
        $pdo = db();
        $q = $pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? LIMIT 1');
        $q->execute(['sh_api_settings']);
        $row = $q->fetch();
        if ($row) {
            $s = json_decode((string)$row['storage_value'], true);
            if (is_array($s)) {
                if (trim((string)($s['virtualizorHost'] ?? '')) !== '') $c['host'] = trim((string)$s['virtualizorHost']);
                if (trim((string)($s['virtualizorApiKey'] ?? '')) !== '' && !str_starts_with((string)$s['virtualizorApiKey'], 'VIRT_KEY_')) $c['key'] = trim((string)$s['virtualizorApiKey']);
                if (trim((string)($s['virtualizorApiPass'] ?? '')) !== '' && !str_starts_with((string)$s['virtualizorApiPass'], 'VIRT_PASS_')) $c['pass'] = trim((string)$s['virtualizorApiPass']);
                if (isset($s['virtualizorDefaultOsId']) && (int)$s['virtualizorDefaultOsId'] > 0) $c['defaultOsId'] = (int)$s['virtualizorDefaultOsId'];
            }
        }
    } catch (Throwable $e) {
        // Fallback to server-side constants.
    }
    return $c;
}
function vurl(array $c, string $query='', ?string $hostOverride=null): string {
    $host = trim((string)($hostOverride ?? $c['host']));
    if ($host === '') $host = VIRTUALIZOR_HOST;
    if (!preg_match('/^https?:\/\//i', $host)) $host = 'https://'.$host;
    $host = rtrim($host,'/');
    $parts = parse_url($host);
    if (!is_array($parts) || empty($parts['host'])) {
        throw new RuntimeException('Invalid Virtualizor host configuration.');
    }
    $scheme = ($parts['scheme'] ?? 'https');
    $hostOnly = $parts['host'];
    $port = isset($parts['port']) ? (int)$parts['port'] : (int)$c['port'];
    $host = $scheme.'://'.$hostOnly.':'.$port;
    $base = $host.'/index.php';
    $params = ['api'=>'json','adminapikey'=>$c['key'],'adminapipass'=>$c['pass']];
    if ($query !== '') $base .= '?'.$query.'&'.http_build_query($params);
    else $base .= '?'.http_build_query($params);
    return $base;
}
function virt_call(array $c, string $act, array $get=[], array $post=[]): array {
    $query = array_merge(['act'=>$act], $get);
    $hosts = [trim((string)$c['host'])];
    $fallback = trim((string)($c['fallbackHost'] ?? ''));
    if ($fallback !== '' && strcasecmp($fallback, $hosts[0]) !== 0) $hosts[] = $fallback;
    $lastError = '';
    foreach ($hosts as $host) {
        try {
            $url = vurl($c, http_build_query($query), $host);
            $ch = curl_init($url);
            $opts = [
                CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_FOLLOWLOCATION=>true,
                CURLOPT_CONNECTTIMEOUT=>15,
                CURLOPT_TIMEOUT=>90,
                CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,
                CURLOPT_SSL_VERIFYPEER=>false,
                CURLOPT_SSL_VERIFYHOST=>false,
                CURLOPT_HTTPHEADER=>['Accept: application/json'],
            ];
            if ($post) {
                $opts[CURLOPT_POST] = true;
                $opts[CURLOPT_POSTFIELDS] = http_build_query($post);
                $opts[CURLOPT_HTTPHEADER][] = 'Content-Type: application/x-www-form-urlencoded';
            }
            curl_setopt_array($ch,$opts);
            $body = curl_exec($ch);
            $err = curl_error($ch);
            $errno = curl_errno($ch);
            $code = (int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($body === false || $errno) {
                $lastError='Virtualizor connection failed on '.$host.': '.($err ?: 'cURL error '.$errno);
                continue;
            }
            $data = json_decode((string)$body,true);
            if (!is_array($data)) throw new RuntimeException('Virtualizor returned non-JSON data (HTTP '.$code.').');
            return $data;
        } catch (Throwable $e) {
            $lastError=$e->getMessage();
        }
    }
    throw new RuntimeException($lastError ?: 'Virtualizor connection failed.');
}
function find_osid(array $templates, string $requested, string $virt, int $fallback=0): int {
    if ($fallback > 0) return $fallback;
    $requested = strtolower(trim($requested));
    $oses = [];
    foreach (['oses','ostemplates'] as $k) {
        if (isset($templates[$k]) && is_array($templates[$k])) {
            foreach ($templates[$k] as $o) if (is_array($o)) $oses[]=$o;
        }
    }
    $best = 0; $bestScore = -1;
    foreach ($oses as $o) {
        if ((string)($o['type']??'') !== $virt && (string)($o['Nvirt']??'') !== $virt) continue;
        $name = strtolower((string)($o['name']??''));
        if ($name==='') continue;
        $score = 0;
        if ($requested !== '') {
            $tokens = preg_split('/[^a-z0-9]+/', $requested) ?: [];
            foreach ($tokens as $t) {
                if (strlen($t)>=3 && str_contains($name,$t)) $score += 2;
            }
            if (str_contains($requested,'ubuntu') && str_contains($name,'ubuntu')) $score += 8;
            if (str_contains($requested,'debian') && str_contains($name,'debian')) $score += 8;
            if (str_contains($requested,'windows') && (str_contains($name,'win')||str_contains($name,'windows'))) $score += 8;
            if (preg_match('/22\.04|2204/', $requested) && preg_match('/22\.04|2204/', $name)) $score += 10;
            if (preg_match('/20\.04|2004/', $requested) && preg_match('/20\.04|2004/', $name)) $score += 10;
            if (preg_match('/24\.04|2404/', $requested) && preg_match('/24\.04|2404/', $name)) $score += 10;
        }
        if ($score > $bestScore) { $bestScore=$score; $best=(int)($o['osid']??0); }
    }
    return $best;
}

function find_windows_2022_os(array $templates, string $virt): array {
    $oses = [];
    foreach (['oses','ostemplates'] as $k) {
        if (isset($templates[$k]) && is_array($templates[$k])) {
            foreach ($templates[$k] as $o) if (is_array($o)) $oses[]=$o;
        }
    }
    $best=[]; $bestScore=-1;
    foreach ($oses as $o) {
        $type=(string)($o['type']??$o['Nvirt']??'');
        if ($type!=='' && $type!==$virt) continue;
        $name=strtolower((string)($o['name']??$o['os_name']??''));
        if ($name==='' || !str_contains($name,'win')) continue;
        $score=0;
        if (preg_match('/2022|22\s*server/', $name)) $score+=20;
        if (str_contains($name,'windows')) $score+=5;
        if (str_contains($name,'scsi')) $score+=2;
        if (str_contains($name,'virtio')) $score+=2;
        if ($score>$bestScore && (int)($o['osid']??0)>0) { $bestScore=$score; $best=$o; }
    }
    return $best;
}
function normalize_vps_status(array $statusResp, array $tasksResp=[]): array {
    $raw=$statusResp;
    $statusCode=null;
    if (isset($raw['status']) && is_numeric($raw['status'])) $statusCode=(int)$raw['status'];
    else {
        foreach ($raw as $k=>$v) {
            if (is_array($v) && isset($v['status']) && is_numeric($v['status'])) { $statusCode=(int)$v['status']; break; }
        }
    }
    $status = match($statusCode) { 1=>'running', 0=>'stopped', 2=>'suspended', default=>'unknown' };
    $reason = $status==='running' ? 'VPS is powered on.' :
        ($status==='stopped' ? 'VPS is powered off.' :
        ($status==='suspended' ? 'VPS is suspended by the virtualization panel.' : 'Virtualizor has not returned a definitive power state.'));
    $taskList=$tasksResp['tasks']??[];
    if (!is_array($taskList)) $taskList=[];
    $latest=null;
    foreach ($taskList as $task) {
        if (!is_array($task)) continue;
        if ($latest===null) $latest=$task;
        $a=(string)($task['action']??$task['act']??'');
        if (in_array($a,['rebuildvs','addvs','deletevs'],true)) { $latest=$task; break; }
    }
    if ($latest) {
        $ts=(string)($latest['status']??'');
        $action=strtolower((string)($latest['action']??$latest['act']??''));
        $err=(string)($latest['error']??$latest['err']??$latest['message']??$latest['msg']??'');
        if ($ts==='1') {
            if ($action==='rebuildvs') { $status='formatting'; $reason='Formatting disk and installing Windows Server 2022.'; }
            elseif ($action==='addvs') { $status='deploying'; $reason='VPS is being deployed and the OS is being installed.'; }
            else { $status='processing'; $reason='Virtualizor is processing the VPS operation.'; }
        } elseif ($ts==='-1') {
            $status='error'; $reason=$err!==''?$err:'Virtualizor reported an error while processing the VPS operation.';
        }
    }
    return ['status'=>$status,'reason'=>$reason,'statusCode'=>$statusCode,'task'=>$latest];
}

function find_storage(array $storages): array {
    $items = $storages['storage'] ?? [];
    if (!is_array($items)) return [];
    $fallback = [];
    foreach ($items as $st) {
        if (!is_array($st)) continue;
        if ((string)($st['primary_storage']??'0')==='1' && !empty($st['st_uuid'])) return $st;
        if (!$fallback && !empty($st['st_uuid'])) $fallback=$st;
    }
    return $fallback;
}
function find_free_ipv4(array $resp): string {
    // Virtualizor's IP list may be keyed by IP address or returned as nested records.
    $candidates = [];
    foreach (['ips','iplist','ip'] as $k) {
        if (isset($resp[$k]) && is_array($resp[$k])) $candidates[] = $resp[$k];
    }
    $walk = function($node) use (&$walk, &$candidates) {
        if (!is_array($node)) return;
        $candidates[] = $node;
        foreach ($node as $v) if (is_array($v)) $walk($v);
    };
    $walk($resp);
    foreach ($candidates as $arr) {
        foreach ($arr as $key=>$item) {
            if (is_string($item)) {
                if (filter_var($item,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) return $item;
                if (filter_var((string)$key,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) return (string)$key;
                continue;
            }
            if (!is_array($item)) continue;
            $ip=(string)($item['ip']??$item['ip_address']??$item['ipaddress']??'');
            if (!$ip && filter_var((string)$key,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) $ip=(string)$key;
            if ($ip && filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) {
                $vpsid=(string)($item['vpsid']??$item['vps_id']??'0');
                $locked=(string)($item['locked']??'0');
                if ($vpsid==='0' && $locked!=='1') return $ip;
            }
        }
    }
    return '';
}
function find_created_vps(array $r, string $hostname): array {
    $v=extract_vps($r);
    if ($v && !empty($v['vpsid'])) return $v;
    // Some Virtualizor versions return the create operation without vpsinfo immediately.
    // Search the VPS list by the unique hostname before reporting failure.
    return [];
}
function extract_vpsid_deep(array $data): string {
    if (isset($data['vpsid']) && preg_match('/^\d+$/',(string)$data['vpsid'])) return (string)$data['vpsid'];
    foreach ($data as $k=>$v) {
        if (is_array($v)) {
            $id=extract_vpsid_deep($v);
            if ($id!=='') return $id;
        }
    }
    return '';
}
function extract_vps(array $r): array {
    $v = $r['vs_info'] ?? $r['vpsinfo'] ?? $r['vps'] ?? null;
    if (is_array($v)) return $v;
    if (isset($r['done']) && is_array($r['done'])) {
        foreach ($r['done'] as $x) if (is_array($x) && isset($x['vpsid'])) return $x;
    }
    return [];
}
function user_exists_in_site(string $userId, string $email): bool {
    try {
        $pdo = db();
        $q = $pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? LIMIT 1');
        $q->execute(['sh_users']);
        $row=$q->fetch();
        $users=$row?json_decode((string)$row['storage_value'],true):[];
        if (!is_array($users)) return false;
        foreach ($users as $u) {
            if (!is_array($u)) continue;
            if ((string)($u['id']??'')===$userId && strtolower((string)($u['email']??''))===strtolower($email)) return true;
        }
    } catch(Throwable $e) {}
    return false;
}
function site_user(string $userId, string $email): ?array {
    try {
        $pdo=db();
        $q=$pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? LIMIT 1');
        $q->execute(['sh_users']);
        $row=$q->fetch();
        $users=$row?json_decode((string)$row['storage_value'],true):[];
        if (!is_array($users)) return null;
        foreach($users as $u) if(is_array($u) && (string)($u['id']??'')===$userId && strtolower((string)($u['email']??''))===strtolower($email)) return $u;
    } catch(Throwable $e) {}
    return null;
}

$in=input_json();
$action=strtolower(trim((string)($in['action']??'')));
$c=cfg();

try {
    if ($action==='test') {
        $r=virt_call($c,'plans',['reslen'=>1],[]);
        vps_out(true,'Virtualizor connection successful.',[
            'host'=>$c['host'],
            'connected'=>true,
            'planCount'=>isset($r['plans']) && is_array($r['plans']) ? count($r['plans']) : 0
        ]);
    }

    if ($action==='plans') {
        $r=virt_call($c,'plans',['reslen'=>100],[]);
        vps_out(true,'Plans loaded.',['plans'=>$r['plans']??[]]);
    }

    if ($action==='templates' || $action==='os') {
        $r=virt_call($c,'os',[],[]);
        vps_out(true,'OS templates loaded.',[
            'oses'=>$r['oses']??[],
            'ostemplates'=>$r['ostemplates']??[]
        ]);
    }

    if ($action==='storages') {
        $r=virt_call($c,'storage',['reslen'=>100],[]);
        vps_out(true,'Storages loaded.',['storage'=>$r['storage']??[]]);
    }

    if ($action==='admin_list') {
        $r=virt_call($c,'vs',['reslen'=>1000],[]);
        $all=$r['vps']??$r['vs']??[];
        $out=[];
        foreach($all as $id=>$v) {
            if(!is_array($v)) continue;
            $vid=(string)($v['vpsid']??$id);
            if(!preg_match('/^\d+$/',$vid)) continue;
            $ips=$v['ips']??[]; if(is_string($ips)) $ips=[$ips];
            $out[]=[
                'virtualizorVpsId'=>$vid,
                'uid'=>(string)($v['uid']??''),
                'hostname'=>(string)($v['hostname']??''),
                'vpsName'=>(string)($v['vps_name']??$v['vpsname']??''),
                'username'=>(string)($v['username']??$v['email']??''),
                'email'=>(string)($v['email']??''),
                'ipAddress'=>(string)($v['ip']??($ips[0]??'')),
                'os'=>(string)($v['os_name']??$v['os']??''),
                'ramMB'=>(int)($v['ram']??0),
                'cores'=>(int)($v['cores']??0),
                'statusRaw'=>$v['status']??$v['power_status']??null,
                'raw'=>$v
            ];
        }
        vps_out(true,'Admin VPS list loaded.',['vps'=>$out]);
    }

    if ($action==='list') {
        $email=strtolower(trim((string)($in['email']??'')));
        $userId=trim((string)($in['userId']??''));
        if (!filter_var($email,FILTER_VALIDATE_EMAIL) || $userId==='' || !user_exists_in_site($userId,$email)) vps_out(false,'User verification failed.',[],403);
        $r=virt_call($c,'vs',['reslen'=>1000],[]);
        $all=$r['vps']??$r['vs']??[];
        $out=[];
        foreach($all as $id=>$v) {
            if(!is_array($v)) continue;
            if (strtolower((string)($v['email']??$v['username']??''))=== $email || (string)($v['uid']??'')!=='' && isset($in['virtualizorUid']) && (string)$v['uid']===(string)$in['virtualizorUid']) {
                $v['_vpsid']=(string)($v['vpsid']??$id);
                $out[]=$v;
            }
        }
        vps_out(true,'VPS list loaded.', ['vps'=>$out]);
    }

    if ($action==='create') {
        $userId=trim((string)($in['userId']??''));
        $email=strtolower(trim((string)($in['email']??'')));
        $siteUser=site_user($userId,$email);
        if (!$siteUser) vps_out(false,'User verification failed.',[],403);

        $name=trim((string)($in['planName']??'VPS'));
        $os=trim((string)($in['os']??'Ubuntu 22.04 LTS'));
        $cpu=max(1,(int)($in['cpuCores']??2));
        $ram=max(256,(int)($in['ramGB']??4))*1024;
        $disk=max(5,(int)($in['diskGB']??60));
        $price=max(0,(float)($in['price']??0));
        $hostname='tg-'.preg_replace('/[^a-z0-9-]+/i','-',strtolower($name)).'-'.substr(bin2hex(random_bytes(4)),0,8);
        $hostname=trim($hostname,'-');
        $rootpass='Vps@'.bin2hex(random_bytes(7));
        // User may supply the VNC password. Virtualizor/KVM commonly limits VNC passwords
        // to alphanumeric characters and, on affected versions, a maximum of 8 characters.
        $vncpass=trim((string)($in['vncPassword']??''));
        if ($vncpass==='') $vncpass='VNC'.bin2hex(random_bytes(2));
        if (!preg_match('/^[A-Za-z0-9]{4,8}$/',$vncpass)) {
            vps_out(false,'VNC password must be 4-8 characters and contain only letters and numbers.',[],400);
        }

        // Resolve OS and primary storage from the real Virtualizor node.
        $templates=virt_call($c,'os',[],[]);
        $osid=find_osid($templates,$os,$c['virt'],(int)$c['defaultOsId']);
        if ($osid<=0) vps_out(false,'Requested OS template was not found on Virtualizor. Open Admin → VPS API and choose a valid OS/template.');

        $storageResp=virt_call($c,'storage',['reslen'=>100],[]);
        $storage=find_storage($storageResp);
        if (!$storage || empty($storage['st_uuid'])) vps_out(false,'No usable Virtualizor storage was found. Configure a primary storage first.');

        // Create VPS requires an IPv4 `ips` array. Allocate one from Virtualizor's
        // configured pool instead of sending an empty array.
        $ipResp=virt_call($c,'ips',['reslen'=>200],[]);
        $freeIp=find_free_ipv4($ipResp);
        if ($freeIp==='') {
            vps_out(false,'No free IPv4 address is available in Virtualizor. Add an IPv4 to an IP Pool and make sure it is unlocked/free.', ['virtualizor'=>$ipResp], 502);
        }

        $post=[
            'virt'=>$c['virt'],
            'node_select'=>VIRTUALIZOR_DEFAULT_NODE_SELECT,
            'user_email'=>$email,
            // Virtualizor creates the account automatically if it does not exist.
            'user_pass'=>'TG'.bin2hex(random_bytes(8)).'!',
            'fname'=>(string)($siteUser['fullName']??'Customer'),
            'lname'=>'',
            'hostname'=>$hostname,
            'rootpass'=>$rootpass,
            'osid'=>$osid,
            'num_ips'=>VIRTUALIZOR_DEFAULT_NUM_IPS,
            'ips'=>[$freeIp],
            'space'=>[0=>['size'=>$disk,'st_uuid'=>(string)$storage['st_uuid']]],
            'stid'=>(int)($storage['stid']??0),
            'ram'=>$ram,
            'bandwidth'=>VIRTUALIZOR_DEFAULT_BANDWIDTH,
            'cores'=>$cpu,
            'plid'=>(int)($in['virtualizorPlanId']??0),
            'network_speed'=>0,
            'cpu'=>VIRTUALIZOR_DEFAULT_CPU_WEIGHT,
            'cpu_percent'=>VIRTUALIZOR_DEFAULT_CPU_PERCENT,
            'vnc'=>VIRTUALIZOR_DEFAULT_VNC,
            'vncpass'=>$vncpass,
            'swapram'=>VIRTUALIZOR_DEFAULT_SWAP_MB,
            'nic_type'=>'default',
            'vnc_keymap'=>'en-us',
            'osreinstall_limit'=>0,
            'noemail'=>0,
            'addvps'=>1,
        ];
        // Empty ips are intentionally omitted; Virtualizor allocates from its configured IP pool.
        $r=virt_call($c,'addvs',[], $post);
        $v=extract_vps($r);
        $createdId=extract_vpsid_deep($r);
        if (!$v && $createdId!=='') $v=['vpsid'=>$createdId];
        // If creation is queued/asynchronous and vpsinfo is not in the immediate
        // response, poll the VPS list briefly using the unique hostname.
        if (!$v || empty($v['vpsid'])) {
            for ($attempt=0; $attempt<5; $attempt++) {
                usleep(800000);
                $list=virt_call($c,'vs',['vpshostname'=>$hostname,'reslen'=>20],[]);
                $all=$list['vps']??$list['vs']??$list;
                if (is_array($all)) {
                    foreach ($all as $id=>$candidate) {
                        if (!is_array($candidate)) continue;
                        $ch=(string)($candidate['hostname']??$candidate['vps_hostname']??'');
                        if ($ch===$hostname || (string)($candidate['vpsid']??'')!=='') {
                            $cid=(string)($candidate['vpsid']??$id);
                            if (preg_match('/^\d+$/',$cid)) { $v=$candidate; $v['vpsid']=$cid; break 2; }
                        }
                    }
                }
            }
        }
        if (!$v || empty($v['vpsid'])) {
            $msg='Virtualizor did not return a VPS ID. The create request was sent, but Virtualizor did not expose the new VPS yet.';
            if (!empty($r['error'])) $msg.=' '.(is_string($r['error'])?$r['error']:json_encode($r['error']));
            vps_out(false,$msg,['allocatedIp'=>$freeIp,'virtualizor'=>$r],502);
        }
        $ips=$v['ips']??[];
        if (is_string($ips)) $ips=[$ips];
        $ip=(string)($ips[0]??$v['ip']??$freeIp);
        $vps=[
            'virtualizorVpsId'=>(string)$v['vpsid'],
            'virtualizorUid'=>(string)($v['uid']??''),
            'ipAddress'=>$ip,
            'rootPassword'=>$rootpass,
            'username'=>(stripos($os,'windows')!==false || stripos((string)($v['os_name']??''),'windows')!==false || stripos((string)($v['os_name']??''),'win')!==false) ? 'Administrator' : 'root',
            'vncPassword'=>$vncpass,
            'hostname'=>(string)($v['hostname']??$hostname),
            'vpsName'=>(string)($v['vps_name']??''),
            'os'=>(string)($v['os_name']??$os),
            'status'=>'deploying',
            'reason'=>'VPS created; Virtualizor is deploying the OS and configuring the server.',
            'ramGB'=>$ram/1024,
            'cpuCores'=>$cpu,
            'diskGB'=>$disk,
            'price'=>$price,
            'createdAt'=>gmdate('c'),
        ];
        vps_out(true,'VPS created successfully in Virtualizor.',['vps'=>$vps,'virtualizor'=>$r]);
    }

    if (in_array($action,['start','stop','restart','poweroff','delete','status','rebuild','format'],true)) {
        $vid=(int)($in['vpsid']??0);
        if($vid<=0) vps_out(false,'Invalid VPS ID.',[],400);
        if($action==='status') {
            $r=virt_call($c,'vs',['vs_status'=>$vid],[]);
            $tasks=virt_call($c,'tasks',['vpsid'=>$vid,'reslen'=>20,'order'=>2],[]);
            $normalized=normalize_vps_status($r,$tasks);
            vps_out(true,'VPS status loaded.',[
                'status'=>$normalized['status'],
                'reason'=>$normalized['reason'],
                'statusCode'=>$normalized['statusCode'],
                'task'=>$normalized['task'],
                'rawStatus'=>$r
            ]);
        }
        if($action==='start') $r=virt_call($c,'vs',['action'=>'start','vpsid'=>$vid],[]);
        elseif($action==='stop') $r=virt_call($c,'vs',['action'=>'stop','vpsid'=>$vid],[]);
        elseif($action==='restart') $r=virt_call($c,'vs',['action'=>'restart','vpsid'=>$vid],[]);
        elseif($action==='poweroff') $r=virt_call($c,'vs',['action'=>'poweroff','vpsid'=>$vid],[]);
        elseif($action==='delete') $r=virt_call($c,'vs',[],['delete'=>$vid]);
        elseif($action==='rebuild' || $action==='format') {
            $osid=(int)($in['osid']??0);
            if ($action==='format' || $osid<=0) {
                $templates=virt_call($c,'os',[],[]);
                $win=find_windows_2022_os($templates,$c['virt']);
                $osid=(int)($win['osid']??0);
                if ($osid<=0) vps_out(false,'Windows Server 2022 OS template was not found in Virtualizor. Add a Windows 2022 KVM template first.',[],502);
            }
            $newpass=trim((string)($in['newpass']??''));
            if($newpass==='') $newpass='Vps@'.bin2hex(random_bytes(7));
            $r=virt_call($c,'rebuild',[],[
                'vpsid'=>$vid,'reos'=>1,'osid'=>$osid,
                'newpass'=>$newpass,'conf'=>$newpass,
                'format_primary'=>1
            ]);
            $r['_formatOsId']=$osid;
            $r['_formatUsername']='Administrator';
            $r['_newRootPassword']=$newpass;
        }
        $done=$r['done']??$r['success']??false;
        if($done===false || $done===0 || $done==='0') vps_out(false,'Virtualizor rejected the requested action.', ['virtualizor'=>$r],502);
        $extra=['virtualizor'=>$r];
        if (in_array($action,['start','stop','restart','poweroff','rebuild','format'],true)) {
            $extra['status'] = $action==='start'||$action==='restart' ? 'running' : ($action==='stop'||$action==='poweroff' ? 'stopped' : ($action==='format'||$action==='rebuild' ? 'formatting' : 'processing'));
            $extra['reason'] = $action==='format' ? 'Formatting disk and installing Windows Server 2022.' : (($action==='rebuild') ? 'Formatting disk and reinstalling the selected OS.' : ((string)($r['done_msg']??'Virtualizor accepted the operation.')));
            if ($action==='format' || $action==='rebuild') {
                if (isset($r['_formatOsId'])) $extra['osid']=(int)$r['_formatOsId'];
                if (isset($r['_formatUsername'])) $extra['username']=(string)$r['_formatUsername'];
                if (isset($r['_newRootPassword'])) $extra['rootPassword']=(string)$r['_newRootPassword'];
            }
        }
        vps_out(true,(string)($r['done_msg']??$r['message']??'Virtualizor action accepted.'), $extra);
    }

    vps_out(false,'Unknown VPS action.',[],400);
} catch (Throwable $e) {
    vps_out(false,$e->getMessage(),[],502);
}

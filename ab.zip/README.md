<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/f54d4093-052b-431d-b721-27f9ee925fef

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Fixes applied — 2026-09-04
- Password recovery OTP is no longer exposed in the browser/UI.
- Password recovery now verifies the OTP server-side and only completes reset after a valid, unexpired OTP.
- Failed SMTP delivery no longer returns a fake/successful OTP response.
- SMTP transport configuration is treated as a single source in `sh_api_settings.mailSettings`; the Email Notification Control Center only manages event ON/OFF routing.
- SMS OTP purchases now show a confirmation popup and result popup.
- SMS OTP purchase requests have a frontend in-flight lock plus a short server-side duplicate-click guard to prevent accidental double/triple provider orders.

## Real Virtualizor VPS integration
The VPS purchase flow now calls `api/vps.php` server-side instead of generating demo IP/VM credentials in the browser. The endpoint can test the Virtualizor connection, load plans/OS/storage, create a real VPS (Virtualizor can auto-create the customer account when needed), and perform start/stop/restart/poweroff/rebuild/delete/status operations. Real API credentials are kept server-side in `api/virtualizor_config.php` and are denied by `api/.htaccess`.

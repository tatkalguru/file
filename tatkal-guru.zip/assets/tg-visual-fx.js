/**
 * Tatkal Guru - Background Visual Effects Engine (10 Types)
 * Automatically renders canvas animation across user panel and admin panel.
 */
(function () {
  'use strict';

  var canvas = null;
  var ctx = null;
  var animFrameId = null;
  var currentEffect = 'matrix';
  var width = window.innerWidth;
  var height = window.innerHeight;

  function getThemeEffect() {
    try {
      var raw = localStorage.getItem('sh_theme_settings');
      if (raw) {
        var t = JSON.parse(raw);
        if (t && t.visualEffect) return t.visualEffect;
      }
    } catch (e) {}
    return 'matrix';
  }

  function initCanvas() {
    if (document.getElementById('tg-bg-fx-canvas')) {
      canvas = document.getElementById('tg-bg-fx-canvas');
      ctx = canvas.getContext('2d');
      return;
    }
    canvas = document.createElement('canvas');
    canvas.id = 'tg-bg-fx-canvas';
    canvas.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:2;opacity:0.42;overflow:hidden;';
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    resize();
  }

  function resize() {
    if (!canvas) return;
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);

  // State objects for various effects
  var matrixDrops = [];
  var particles = [];
  var snowFlakes = [];
  var stars = [];
  var shootingStars = [];
  var fireworks = [];
  var confettiPieces = [];
  var geoNodes = [];
  var cyberOffset = 0;
  var bubbles = [];
  var neonPulseAngle = 0;

  function setupEffect(eff) {
    resize();
    currentEffect = eff;
    if (!ctx) return;
    ctx.clearRect(0, 0, width, height);

    if (eff === 'matrix') {
      var cols = Math.floor(width / 18);
      matrixDrops = [];
      for (var i = 0; i < cols; i++) {
        matrixDrops[i] = Math.floor(Math.random() * -50);
      }
    } else if (eff === 'particles') {
      particles = [];
      var pCount = Math.min(65, Math.floor(width / 22));
      for (var p = 0; p < pCount; p++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 1.2,
          vy: (Math.random() - 0.5) * 1.2,
          radius: Math.random() * 2.5 + 1.2,
          color: p % 3 === 0 ? '#38bdf8' : (p % 3 === 1 ? '#818cf8' : '#34d399')
        });
      }
    } else if (eff === 'snow') {
      snowFlakes = [];
      var sCount = Math.min(80, Math.floor(width / 18));
      for (var s = 0; s < sCount; s++) {
        snowFlakes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: Math.random() * 3 + 1,
          speed: Math.random() * 1.8 + 0.8,
          sway: Math.random() * 2,
          swaySpeed: Math.random() * 0.02 + 0.01
        });
      }
    } else if (eff === 'stars') {
      stars = [];
      var starCount = Math.min(120, Math.floor(width / 12));
      for (var st = 0; st < starCount; st++) {
        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: Math.random() * 1.8 + 0.6,
          alpha: Math.random(),
          speed: Math.random() * 0.03 + 0.01
        });
      }
      shootingStars = [];
    } else if (eff === 'fireworks') {
      fireworks = [];
    } else if (eff === 'confetti') {
      confettiPieces = [];
      var cCount = Math.min(60, Math.floor(width / 25));
      var colors = ['#f43f5e', '#fbbf24', '#38bdf8', '#a855f7', '#34d399', '#fb923c'];
      for (var c = 0; c < cCount; c++) {
        confettiPieces.push({
          x: Math.random() * width,
          y: Math.random() * height,
          w: Math.random() * 10 + 6,
          h: Math.random() * 6 + 4,
          color: colors[c % colors.length],
          vy: Math.random() * 2 + 1.2,
          rot: Math.random() * 360,
          rotSpeed: (Math.random() - 0.5) * 6
        });
      }
    } else if (eff === 'geometric') {
      geoNodes = [];
      var gCount = Math.min(40, Math.floor(width / 35));
      for (var g = 0; g < gCount; g++) {
        geoNodes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 1.4,
          vy: (Math.random() - 0.5) * 1.4,
          radius: Math.random() * 3 + 2
        });
      }
    } else if (eff === 'cybergrid') {
      cyberOffset = 0;
    } else if (eff === 'bubbles') {
      bubbles = [];
      var bCount = Math.min(45, Math.floor(width / 30));
      for (var b = 0; b < bCount; b++) {
        bubbles.push({
          x: Math.random() * width,
          y: height + Math.random() * 200,
          radius: Math.random() * 14 + 6,
          vy: Math.random() * 1.6 + 0.8,
          wobble: Math.random() * Math.PI * 2,
          wobbleSpeed: Math.random() * 0.03 + 0.01,
          hue: Math.floor(Math.random() * 60 + 170)
        });
      }
    } else if (eff === 'neonpulse') {
      neonPulseAngle = 0;
    }
  }

  function render() {
    animFrameId = requestAnimationFrame(render);
    if (!ctx) return;

    var eff = currentEffect;
    if (eff === 'none') {
      ctx.clearRect(0, 0, width, height);
      return;
    }

    if (eff === 'matrix') {
      ctx.fillStyle = 'rgba(2, 6, 23, 0.12)';
      ctx.fillRect(0, 0, width, height);
      ctx.font = '14px monospace';
      var chars = '0123456789ABCDEF@#$%&*アイウエオカキクケコサシスセソタチツテト';
      for (var i = 0; i < matrixDrops.length; i++) {
        var char = chars.charAt(Math.floor(Math.random() * chars.length));
        var x = i * 18;
        var y = matrixDrops[i] * 18;
        ctx.fillStyle = '#86efac';
        ctx.fillText(char, x, y);
        ctx.fillStyle = '#22c55e';
        ctx.fillText(chars.charAt(Math.floor(Math.random() * chars.length)), x, y - 18);
        if (y > height && Math.random() > 0.975) {
          matrixDrops[i] = 0;
        }
        matrixDrops[i]++;
      }
    } else if (eff === 'particles') {
      ctx.clearRect(0, 0, width, height);
      for (var p = 0; p < particles.length; p++) {
        var pt = particles[p];
        pt.x += pt.vx;
        pt.y += pt.vy;
        if (pt.x < 0) pt.x = width;
        if (pt.x > width) pt.x = 0;
        if (pt.y < 0) pt.y = height;
        if (pt.y > height) pt.y = 0;

        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
        ctx.fillStyle = pt.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = pt.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        for (var q = p + 1; q < particles.length; q++) {
          var pt2 = particles[q];
          var dist = Math.hypot(pt.x - pt2.x, pt.y - pt2.y);
          if (dist < 100) {
            ctx.beginPath();
            ctx.moveTo(pt.x, pt.y);
            ctx.lineTo(pt2.x, pt2.y);
            ctx.strokeStyle = 'rgba(99, 102, 241, ' + (1 - dist / 100) * 0.35 + ')';
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }
    } else if (eff === 'snow') {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      for (var s = 0; s < snowFlakes.length; s++) {
        var sf = snowFlakes[s];
        sf.y += sf.speed;
        sf.sway += sf.swaySpeed;
        sf.x += Math.sin(sf.sway) * 0.8;
        if (sf.y > height) {
          sf.y = -10;
          sf.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(sf.x, sf.y, sf.radius, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (eff === 'stars') {
      ctx.clearRect(0, 0, width, height);
      for (var st = 0; st < stars.length; st++) {
        var star = stars[st];
        star.alpha += star.speed;
        var opacity = Math.abs(Math.sin(star.alpha));
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, ' + opacity + ')';
        ctx.fill();
      }
      if (Math.random() < 0.02 && shootingStars.length < 2) {
        shootingStars.push({
          x: Math.random() * width,
          y: Math.random() * (height / 2),
          length: Math.random() * 80 + 50,
          speed: Math.random() * 10 + 12,
          angle: Math.PI / 4 + (Math.random() - 0.5) * 0.2,
          opacity: 1
        });
      }
      for (var ss = shootingStars.length - 1; ss >= 0; ss--) {
        var sStar = shootingStars[ss];
        sStar.x += Math.cos(sStar.angle) * sStar.speed;
        sStar.y += Math.sin(sStar.angle) * sStar.speed;
        sStar.opacity -= 0.03;
        if (sStar.opacity <= 0) {
          shootingStars.splice(ss, 1);
          continue;
        }
        ctx.beginPath();
        ctx.moveTo(sStar.x, sStar.y);
        ctx.lineTo(sStar.x - Math.cos(sStar.angle) * sStar.length, sStar.y - Math.sin(sStar.angle) * sStar.length);
        ctx.strokeStyle = 'rgba(254, 240, 138, ' + sStar.opacity + ')';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    } else if (eff === 'fireworks') {
      ctx.fillStyle = 'rgba(2, 6, 23, 0.18)';
      ctx.fillRect(0, 0, width, height);
      if (Math.random() < 0.04 && fireworks.length < 4) {
        var colors = ['#f43f5e', '#e11d48', '#fbbf24', '#38bdf8', '#a855f7', '#34d399', '#f97316'];
        var color = colors[Math.floor(Math.random() * colors.length)];
        var targetX = Math.random() * (width - 200) + 100;
        var targetY = Math.random() * (height * 0.5) + 60;
        var sparks = [];
        for (var sp = 0; sp < 35; sp++) {
          var angle = (Math.PI * 2 * sp) / 35;
          var speed = Math.random() * 4 + 2;
          sparks.push({
            x: targetX,
            y: targetY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            alpha: 1,
            color: color
          });
        }
        fireworks.push({ sparks: sparks });
      }
      for (var f = fireworks.length - 1; f >= 0; f--) {
        var fw = fireworks[f];
        var allDead = true;
        for (var k = 0; k < fw.sparks.length; k++) {
          var spark = fw.sparks[k];
          spark.x += spark.vx;
          spark.y += spark.vy;
          spark.vy += 0.08;
          spark.alpha -= 0.02;
          if (spark.alpha > 0) {
            allDead = false;
            ctx.beginPath();
            ctx.arc(spark.x, spark.y, 2, 0, Math.PI * 2);
            ctx.fillStyle = spark.color;
            ctx.globalAlpha = Math.max(0, spark.alpha);
            ctx.fill();
            ctx.globalAlpha = 1;
          }
        }
        if (allDead) fireworks.splice(f, 1);
      }
    } else if (eff === 'confetti') {
      ctx.clearRect(0, 0, width, height);
      for (var c = 0; c < confettiPieces.length; c++) {
        var cf = confettiPieces[c];
        cf.y += cf.vy;
        cf.rot += cf.rotSpeed;
        if (cf.y > height + 20) {
          cf.y = -20;
          cf.x = Math.random() * width;
        }
        ctx.save();
        ctx.translate(cf.x, cf.y);
        ctx.rotate((cf.rot * Math.PI) / 180);
        ctx.fillStyle = cf.color;
        ctx.fillRect(-cf.w / 2, -cf.h / 2, cf.w, cf.h);
        ctx.restore();
      }
    } else if (eff === 'geometric') {
      ctx.clearRect(0, 0, width, height);
      for (var g = 0; g < geoNodes.length; g++) {
        var gn = geoNodes[g];
        gn.x += gn.vx;
        gn.y += gn.vy;
        if (gn.x < 0 || gn.x > width) gn.vx *= -1;
        if (gn.y < 0 || gn.y > height) gn.vy *= -1;

        ctx.beginPath();
        ctx.arc(gn.x, gn.y, gn.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#6366f1';
        ctx.fill();

        for (var h = g + 1; h < geoNodes.length; h++) {
          var gn2 = geoNodes[h];
          var d = Math.hypot(gn.x - gn2.x, gn.y - gn2.y);
          if (d < 140) {
            ctx.beginPath();
            ctx.moveTo(gn.x, gn.y);
            ctx.lineTo(gn2.x, gn2.y);
            ctx.strokeStyle = 'rgba(99, 102, 241, ' + (1 - d / 140) * 0.25 + ')';
            ctx.stroke();
          }
        }
      }
    } else if (eff === 'cybergrid') {
      ctx.fillStyle = 'rgba(2, 6, 23, 0.4)';
      ctx.fillRect(0, 0, width, height);
      cyberOffset = (cyberOffset + 1.2) % 40;
      var horizon = height * 0.55;

      // Horizon glow
      var grad = ctx.createLinearGradient(0, horizon - 80, 0, horizon + 20);
      grad.addColorStop(0, 'transparent');
      grad.addColorStop(1, 'rgba(168, 85, 247, 0.25)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, horizon - 80, width, 100);

      ctx.strokeStyle = 'rgba(6, 182, 212, 0.35)';
      ctx.lineWidth = 1.2;

      // Perspective vertical grid rays
      var numRays = 18;
      for (var r = -numRays; r <= numRays; r++) {
        var startX = width / 2 + r * 30;
        var endX = width / 2 + r * 140;
        ctx.beginPath();
        ctx.moveTo(startX, horizon);
        ctx.lineTo(endX, height);
        ctx.stroke();
      }

      // Horizontal grid lines moving forward
      for (var y = horizon; y < height; y += 18) {
        var distRatio = (y - horizon) / (height - horizon);
        var actualY = horizon + Math.pow(distRatio, 1.8) * (height - horizon) + (cyberOffset * distRatio * 0.4);
        if (actualY <= height) {
          ctx.beginPath();
          ctx.moveTo(0, actualY);
          ctx.lineTo(width, actualY);
          ctx.stroke();
        }
      }
    } else if (eff === 'bubbles') {
      ctx.clearRect(0, 0, width, height);
      for (var b = 0; b < bubbles.length; b++) {
        var bub = bubbles[b];
        bub.y -= bub.vy;
        bub.wobble += bub.wobbleSpeed;
        var bx = bub.x + Math.sin(bub.wobble) * 8;
        if (bub.y < -20) {
          bub.y = height + Math.random() * 50;
          bub.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(bx, bub.y, bub.radius, 0, Math.PI * 2);
        ctx.strokeStyle = 'hsla(' + bub.hue + ', 80%, 65%, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = 'hsla(' + bub.hue + ', 80%, 65%, 0.12)';
        ctx.fill();
      }
    } else if (eff === 'neonpulse') {
      ctx.clearRect(0, 0, width, height);
      neonPulseAngle += 0.04;
      var pulseAlpha = (Math.sin(neonPulseAngle) + 1) / 2 * 0.5 + 0.2;
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(236, 72, 153, ' + pulseAlpha + ')';
      ctx.shadowBlur = 18;
      ctx.shadowColor = '#ec4899';
      ctx.strokeRect(10, 10, width - 20, height - 20);
      ctx.shadowBlur = 0;
    }
  }

  function start() {
    initCanvas();
    var eff = getThemeEffect();
    setupEffect(eff);
    if (animFrameId) cancelAnimationFrame(animFrameId);
    render();
  }

  // Poll for themeSettings.visualEffect changes
  setInterval(function () {
    var eff = getThemeEffect();
    if (eff !== currentEffect) {
      setupEffect(eff);
    }
  }, 1000);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();

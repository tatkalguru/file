(function () {
  'use strict';

  var timer = 0, orderPage = 1, orderQuery = '';

  function read(k, d) {
    try {
      var v = JSON.parse(localStorage.getItem(k) || 'null');
      return v == null ? d : v;
    } catch (e) {
      return d;
    }
  }

  function write(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
      syncKey(k, v);
      return true;
    } catch (e) {
      return false;
    }
  }

  function syncKey(k, v) {
    try {
      var payload = { items: {} };
      payload.items[k] = { value: JSON.stringify(v), updatedAt: Date.now() };
      fetch('./api/storage_sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(function () {});
    } catch (e) {}
  }

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function admin() {
    try {
      var u = JSON.parse(localStorage.getItem('sh_current_user') || 'null');
      if (u && String(u.role || '').toLowerCase() === 'admin') return true;
    } catch (e) {}
    return /ADMIN CONTROL PORTAL|ADMIN PANEL 2/i.test(document.body.innerText || '');
  }

  function hasText(s) {
    return (document.body.innerText || '').indexOf(s) >= 0;
  }

  function activeTab(n, label) {
    var bs = [].slice.call(document.querySelectorAll('button'));
    var b = bs.find(function (x) {
      return new RegExp('^' + n + '\\.\\s*' + label, 'i').test((x.textContent || '').trim());
    });
    if (!b) return false;
    return /bg-rose|bg-red|rose-600|rose-500|bg-pink/.test(b.className || '') ||
      b.getAttribute('aria-current') === 'page' ||
      b.closest('[role="tab"]')?.getAttribute('aria-selected') === 'true' ||
      hasTabContent(n, label);
  }

  function hasTabContent(n, label) {
    var map = {
      'User Control': 'Wallet Balance',
      'UTR Approvals': 'UTR',
      'Product Manager': 'Product Name',
      'Stock Box': 'Stock Data Content Line',
      'Promocode & Cashback': 'Create Promocode / Coupon Code',
      'APIs & Payment Config': 'Payment Gateway, SMS OTP & Virtualizor VPS API Setup',
      'Order History': 'Order ID & Date'
    };
    return !!map[label] && hasText(map[label]);
  }

  function findTable(test) {
    return [].find.call(document.querySelectorAll('table'), function (t) {
      return test(t.innerText || '', t);
    });
  }

  function remove(id) {
    var x = document.getElementById(id);
    if (x) x.remove();
  }

  // ==========================================
  // 1. ORDER HISTORY (Tab 7)
  // ==========================================
  function orders() {
    if (!admin() || !activeTab(7, 'Order History')) {
      remove('tg-order-tools-v2');
      return;
    }
    var table = findTable(function (h) {
      return /Order ID & Date/i.test(h) && /Customer Email & Mobile/i.test(h);
    });
    if (!table || !table.parentElement) return;
    var all = read('sh_orders', []);
    if (!Array.isArray(all)) all = [];
    var q = orderQuery.trim().toLowerCase();
    var filtered = q ? all.filter(function (o) {
      return [o.id, o.userId, o.userEmail, o.userMobile, o.productId, o.productName, o.status, o.paymentMethod, o.deliveredData, o.createdAt].join(' ').toLowerCase().indexOf(q) >= 0;
    }) : all.slice();
    filtered.sort(function (a, b) {
      return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
    });
    var pages = Math.max(1, Math.ceil(filtered.length / 10));
    if (orderPage > pages) orderPage = pages;
    if (orderPage < 1) orderPage = 1;
    var start = (orderPage - 1) * 10, rows = filtered.slice(start, start + 10);
    table.style.display = 'none';
    var old = document.getElementById('tg-order-tools-v2');
    if (old) old.remove();
    var box = document.createElement('div');
    box.id = 'tg-order-tools-v2';
    box.style.cssText = 'margin-top:12px;padding:14px;background:#020617;border:1px solid #334155;border-radius:16px;color:#e2e8f0';
    box.innerHTML = '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:space-between;margin-bottom:12px"><div style="font-weight:900;font-size:15px">📋 All Order History <span style="color:#94a3b8;font-size:11px">(' + filtered.length + ' orders)</span></div><input id="tg-order-search-v2" value="' + esc(orderQuery) + '" placeholder="Search Order ID, Email, Mobile, Product, Status..." style="width:min(420px,100%);box-sizing:border-box;padding:9px 11px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:10px"></div><div id="tg-order-list-v2"></div><div id="tg-order-nav-v2" style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;justify-content:space-between;margin-top:12px"></div>';
    table.parentElement.appendChild(box);
    var list = box.querySelector('#tg-order-list-v2');
    if (!rows.length) {
      list.innerHTML = '<div style="padding:28px;text-align:center;color:#94a3b8">No orders found.</div>';
    } else {
      rows.forEach(function (o, i) {
        var d = document.createElement('div');
        d.style.cssText = 'padding:11px;margin:7px 0;background:#0f172a;border:1px solid #1e293b;border-radius:11px';
        d.innerHTML = '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b style="color:#fbbf24">#' + esc(o.id || ('ORDER-' + (start + i + 1))) + '</b><span style="font-weight:800;color:' + (String(o.status || '').toLowerCase() === 'completed' || String(o.status || '').toLowerCase() === 'delivered' ? '#34d399' : '#cbd5e1') + '">' + esc(o.status || 'Delivered') + '</span></div><div style="margin-top:5px;color:#fff">' + esc(o.productName || o.productId || 'Product') + ' × ' + esc(o.quantity || 1) + ' — ₹' + esc(o.totalAmount || 0) + (o.cashbackCredited ? ' <span style="color:#38bdf8;font-size:11px;font-weight:bold">(Cashback ₹' + esc(o.cashbackCredited) + ' credited)</span>' : '') + '</div><div style="margin-top:4px;font-size:11px;color:#94a3b8">' + esc(o.userEmail || '') + ' ' + esc(o.userMobile || '') + ' • ' + esc(o.paymentMethod || '') + ' • ' + esc(o.createdAt || '') + '</div>';
        list.appendChild(d);
      });
    }
    var nav = box.querySelector('#tg-order-nav-v2');
    var info = document.createElement('span');
    info.style.color = '#94a3b8';
    info.style.fontSize = '11px';
    info.textContent = filtered.length ? 'Showing ' + (start + 1) + '-' + Math.min(start + 10, filtered.length) + ' of ' + filtered.length : 'Showing 0-0 of 0';
    nav.appendChild(info);
    var controls = document.createElement('div');
    controls.style.cssText = 'display:flex;gap:5px;flex-wrap:wrap';
    function b(t, p, dis, cur) {
      var x = document.createElement('button');
      x.type = 'button';
      x.textContent = t;
      x.disabled = dis;
      x.style.cssText = 'min-width:34px;padding:7px 10px;border-radius:8px;border:1px solid #475569;background:' + (cur ? '#e11d48' : '#1e293b') + ';color:#fff;font-weight:900;cursor:' + (dis ? 'not-allowed' : 'pointer');
      x.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (dis) return;
        orderPage = p;
        orders();
      };
      return x;
    }
    controls.appendChild(b('‹', orderPage - 1, orderPage <= 1, false));
    var s = Math.max(1, Math.min(orderPage - 2, pages - 4)), en = Math.min(pages, s + 4);
    for (var p = s; p <= en; p++) controls.appendChild(b(String(p), p, false, p === orderPage));
    controls.appendChild(b('›', orderPage + 1, orderPage >= pages, false));
    nav.appendChild(controls);
    var inp = box.querySelector('#tg-order-search-v2');
    inp.addEventListener('input', function () {
      orderQuery = inp.value;
      orderPage = 1;
      orders();
    });
  }

  // ==========================================
  // 2. STOCK BOX (Tab 4)
  // ==========================================
  function stock() {
    if (!admin() || !activeTab(4, 'Stock Box')) {
      remove('tg-stock-product-boxes-v2');
      return;
    }
    var table = findTable(function (h) {
      return /Stock Data Content Line/i.test(h);
    });
    if (!table || !table.parentElement) return;
    var data = read('sh_stock_box', []), products = read('sh_products', []);
    if (!Array.isArray(data)) data = [];
    if (!Array.isArray(products)) products = [];
    table.style.display = 'none';
    var old = document.getElementById('tg-stock-product-boxes-v2');
    if (old) old.remove();
    var root = document.createElement('div');
    root.id = 'tg-stock-product-boxes-v2';
    root.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:14px;margin-top:12px';
    var groups = {};
    data.forEach(function (x) {
      (groups[x.productId] || (groups[x.productId] = [])).push(x);
    });
    Object.keys(groups).forEach(function (pid) {
      var items = groups[pid], prod = products.find(function (p) {
        return String(p.id) === String(pid);
      }), name = prod && prod.name ? prod.name : 'Unknown Product';
      var avail = items.filter(function (x) {
        return !x.isUsed;
      }), used = items.filter(function (x) {
        return x.isUsed;
      });
      var card = document.createElement('div');
      card.style.cssText = 'background:#020617;border:1px solid #334155;border-radius:16px;padding:15px;color:#fff';
      card.innerHTML = '<div style="font-size:16px;font-weight:900">📦 ' + esc(name) + '</div><div style="font-size:11px;color:#94a3b8;margin:4px 0 10px">Total: ' + items.length + ' • Available: ' + avail.length + ' • Used: ' + used.length + '</div>';
      var ta = document.createElement('textarea');
      ta.rows = 7;
      ta.value = avail.map(function (x) {
        return x.dataContent || '';
      }).join('\n');
      ta.style.cssText = 'width:100%;box-sizing:border-box;padding:10px;background:#0f172a;color:#34d399;border:1px solid #475569;border-radius:10px;font-family:monospace;font-size:11px';
      card.appendChild(ta);
      var save = document.createElement('button');
      save.type = 'button';
      save.textContent = '💾 Save Changes';
      save.style.cssText = 'width:100%;margin-top:9px;padding:10px;border:0;border-radius:10px;background:#16a34a;color:#fff;font-weight:900';
      card.appendChild(save);
      var del = document.createElement('button');
      del.type = 'button';
      del.textContent = '🗑 Delete Available Stock';
      del.style.cssText = 'width:100%;margin-top:8px;padding:9px;border-radius:10px;background:#450a0a;color:#fecaca;border:1px solid #7f1d1d;font-weight:800';
      card.appendChild(del);
      var usedBox = document.createElement('div');
      usedBox.style.cssText = 'margin-top:10px;padding:8px;background:#0f172a;border-radius:9px;color:#94a3b8;font-size:10px';
      usedBox.textContent = 'Used stock: ' + used.length + ' (protected)';
      card.appendChild(usedBox);
      save.onclick = function () {
        var lines = ta.value.split(/\r?\n/).map(function (x) {
          return x.trim();
        }).filter(Boolean), all = read('sh_stock_box', []), ids = all.filter(function (x) {
          return String(x.productId) === String(pid) && !x.isUsed;
        });
        if (!lines.length) {
          alert('Stock data cannot be empty.');
          return;
        }
        ids.forEach(function (x, i) {
          if (i < lines.length) x.dataContent = lines[i];
        });
        if (lines.length < ids.length) {
          var rm = ids.slice(lines.length).map(function (x) {
            return x.id;
          });
          all = all.filter(function (x) {
            return rm.indexOf(x.id) < 0;
          });
        }
        for (var j = ids.length; j < lines.length; j++) all.push({
          id: 'stock_' + Date.now() + '_' + j,
          productId: pid,
          dataContent: lines[j],
          isUsed: false,
          createdAt: new Date().toISOString()
        });
        write('sh_stock_box', all);
        alert('Stock saved successfully.');
        stock();
      };
      del.onclick = function () {
        if (!confirm('Delete all AVAILABLE stock for ' + name + '? Used stock will remain safe.')) return;
        var all = read('sh_stock_box', []);
        write('sh_stock_box', all.filter(function (x) {
          return !(String(x.productId) === String(pid) && !x.isUsed);
        }));
        stock();
      };
      root.appendChild(card);
    });
    if (!Object.keys(groups).length) root.innerHTML = '<div style="grid-column:1/-1;padding:25px;text-align:center;color:#94a3b8;background:#020617;border:1px solid #334155;border-radius:16px">No stock records found.</div>';
    table.parentElement.appendChild(root);
  }

  // ==========================================
  // 3. USER TOOLS (Tab 1)
  // ==========================================
  function userTools() {
    if (!admin() || !activeTab(1, 'User Control')) return;
    var table = findTable(function (h, t) {
      return /Wallet Balance/i.test(h) && /Role/i.test(h) && /Status/i.test(h) && /Actions/i.test(h);
    });
    if (!table || !table.tBodies[0]) return;
    [].slice.call(table.tBodies[0].rows).forEach(function (row) {
      var actions = row.cells[row.cells.length - 1];
      if (!actions || actions.querySelector('[data-tg-user-orders]')) return;
      var userText = (row.cells[0].innerText || '').split(/\n/).map(function (x) {
        return x.trim();
      }).filter(Boolean), email = userText.find(function (x) {
        return /@/.test(x);
      }) || '', mobile = (row.cells[1] && row.cells[1].innerText || '').trim();
      var ob = document.createElement('button');
      ob.type = 'button';
      ob.setAttribute('data-tg-user-orders', '1');
      ob.textContent = '📦 Orders';
      ob.title = 'Orders History';
      ob.style.cssText = 'padding:5px 7px;margin-left:4px;border-radius:7px;border:1px solid #3b82f6;background:#172554;color:#93c5fd;font-weight:900;font-size:10px';
      ob.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        showUserOrders(email, mobile);
      };
      var mb = document.createElement('button');
      mb.type = 'button';
      mb.textContent = '✉ Mail';
      mb.title = 'Send Custom Mail';
      mb.style.cssText = 'padding:5px 7px;margin-left:4px;border-radius:7px;border:1px solid #8b5cf6;background:#2e1065;color:#c4b5fd;font-weight:900;font-size:10px';
      mb.onclick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        showUserMail(email);
      };
      actions.appendChild(ob);
      actions.appendChild(mb);
    });
  }

  function modalBase(title, html) {
    remove('tg-user-tools-modal');
    var m = document.createElement('div');
    m.id = 'tg-user-tools-modal';
    m.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(2,6,23,.85);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px';
    var b = document.createElement('div');
    b.style.cssText = 'width:min(780px,100%);max-height:90vh;overflow:auto;background:#0f172a;border:1px solid #475569;border-radius:18px;padding:18px;color:#fff;box-shadow:0 25px 80px #000';
    b.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><h3 style="font-size:18px;font-weight:900;margin:0">' + title + '</h3><button id="tg-ut-close" type="button" style="font-size:22px;background:#1e293b;color:#fff;border:0;border-radius:8px;padding:4px 10px;cursor:pointer">×</button></div>' + html;
    m.appendChild(b);
    document.body.appendChild(m);
    m.querySelector('#tg-ut-close').onclick = function () {
      m.remove();
    };
  }

  function showUserOrders(email, mobile) {
    var all = read('sh_orders', []);
    if (!Array.isArray(all)) all = [];
    var em = String(email || '').toLowerCase(), ph = String(mobile || '').replace(/\D/g, '');
    var rows = all.filter(function (o) {
      return (em && String(o.userEmail || '').toLowerCase() === em) || (ph && String(o.userMobile || '').replace(/\D/g, '') === ph);
    });
    rows.sort(function (a, b) {
      return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
    });
    var html = '<div style="color:#94a3b8;margin-bottom:10px">User: ' + esc(email || mobile) + ' • Total Orders: ' + rows.length + '</div>';
    html += rows.length ? rows.map(function (o) {
      return '<div style="padding:10px;border:1px solid #334155;border-radius:10px;margin:8px 0"><b style="color:#fbbf24">' + esc(o.id) + '</b> • ' + esc(o.status || 'Delivered') + ' • ₹' + esc(o.totalAmount || 0) + '<div style="color:#cbd5e1">' + esc(o.productName || o.productId || '') + ' × ' + esc(o.quantity || 1) + '</div><small style="color:#94a3b8">' + esc(o.createdAt || '') + '</small></div>';
    }).join('') : '<div style="padding:20px;text-align:center;color:#94a3b8">No orders found for this user.</div>';
    modalBase('📦 User Order History', html);
  }

  function showUserMail(email) {
    modalBase('✉ Send Custom Mail to User', '<div style="color:#94a3b8;margin-bottom:10px">Send to: <b style="color:#fff">' + esc(email) + '</b></div><input id="tg-mail-sub" value="Message from Tatkal Guru" style="width:100%;box-sizing:border-box;padding:10px;margin:6px 0;background:#020617;color:#fff;border:1px solid #475569;border-radius:9px"><textarea id="tg-mail-msg" rows="8" placeholder="Message" style="width:100%;box-sizing:border-box;padding:10px;margin:6px 0;background:#020617;color:#fff;border:1px solid #475569;border-radius:9px"></textarea><button id="tg-mail-send" type="button" style="padding:10px 16px;border:0;border-radius:10px;background:#7c3aed;color:#fff;font-weight:900;cursor:pointer">✉ Send Custom Mail</button><span id="tg-mail-status" style="margin-left:10px;color:#cbd5e1"></span>');
    document.getElementById('tg-mail-send').onclick = function () {
      var st = document.getElementById('tg-mail-status');
      st.textContent = 'Sending...';
      fetch('./api/mail.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'custom',
          to: email,
          subject: document.getElementById('tg-mail-sub').value,
          message: document.getElementById('tg-mail-msg').value
        })
      }).then(function (r) {
        return r.json();
      }).then(function (x) {
        st.textContent = x.message || x.error || 'Done';
      }).catch(function () {
        st.textContent = 'Mail API connection failed.';
      });
    };
  }

  // ==========================================
  // 4. CASHBACK CAMPAIGNS & AUTO-CREDIT (Tab 5)
  // ==========================================
  function cashback() {
    if (!admin() || !activeTab(5, 'Promocode & Cashback')) {
      remove('tg-cashback-box-v2');
      return;
    }
    var host = [].find.call(document.querySelectorAll('h4'), function (x) {
      return /Create Promocode \/ Coupon Code/i.test(x.textContent || '');
    });
    if (!host || !host.parentElement) return;
    var parent = host.parentElement.parentElement || host.parentElement;
    if (document.getElementById('tg-cashback-box-v2')) return;
    var campaigns = read('sh_cashback_campaigns_v1', []), products = read('sh_products', []);
    if (!Array.isArray(campaigns)) campaigns = [];
    if (!Array.isArray(products)) products = [];

    var box = document.createElement('div');
    box.id = 'tg-cashback-box-v2';
    box.style.cssText = 'margin-top:14px;padding:16px;background:#020617;border:1px solid #3b82f6;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,0.5)';
    box.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <div style="font-weight:900;font-size:16px;color:#38bdf8;display:flex;align-items:center;gap:8px">
          💰 Cashback Campaigns (Item 5 Fixed & Automated)
        </div>
        <span style="font-size:11px;background:#0369a1;color:#fff;padding:3px 8px;border-radius:6px;font-weight:bold">Auto Wallet Credit</span>
      </div>
      <div style="font-size:12px;color:#94a3b8;margin-bottom:12px">
        Customer orders with this code get full coupon validation + instant/automated Cashback credited directly into their Wallet balance!
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px">
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Cashback Promo Code</label>
          <input id="cb2-code" placeholder="e.g. CASHBACK20" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fbbf24;font-weight:bold;border:1px solid #475569;border-radius:9px;text-transform:uppercase">
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Applicable Product</label>
          <select id="cb2-product" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
            <option value="all">All Products</option>
            ${products.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.name) + '</option>'; }).join('')}
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Cashback Type</label>
          <select id="cb2-type" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
            <option value="percentage">Percentage (%) Cashback</option>
            <option value="fixed">Flat (₹) Direct Cashback</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Cashback Value (% or ₹)</label>
          <input id="cb2-value" type="number" min="1" placeholder="e.g. 20 (for 20% or ₹20)" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Min Order Amount ₹</label>
          <input id="cb2-min" type="number" min="0" value="0" placeholder="Minimum ₹" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Max Cashback Cap ₹</label>
          <input id="cb2-max" type="number" min="0" placeholder="e.g. 100 (0 for unlimited)" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Total Uses Limit</label>
          <input id="cb2-total" type="number" min="1" value="500" placeholder="Max total uses" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
        </div>
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Expiry Date</label>
          <input id="cb2-expiry" type="date" value="2028-12-31" style="width:100%;box-sizing:border-box;padding:9px;background:#0f172a;color:#fff;border:1px solid #475569;border-radius:9px">
        </div>
      </div>
      <div style="margin-top:12px;display:flex;gap:10px">
        <button id="cb2-create" type="button" style="padding:10px 18px;background:#16a34a;color:#fff;border:0;border-radius:10px;font-weight:900;cursor:pointer;display:flex;align-items:center;gap:6px">
          + Create Verified Cashback Campaign
        </button>
      </div>
      <div id="cb2-list" style="margin-top:14px"></div>
    `;
    parent.appendChild(box);

    function render() {
      var l = box.querySelector('#cb2-list'), cs = read('sh_cashback_campaigns_v1', []);
      l.innerHTML = cs.length ? cs.map(function (c) {
        return `
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;padding:11px;margin:7px 0;background:#0f172a;border:1px solid #334155;border-radius:11px">
            <div>
              <div style="display:flex;align-items:center;gap:8px">
                <b style="color:#38bdf8;font-size:14px">${esc(c.code)}</b>
                <span style="background:${c.isActive !== false ? '#14532d' : '#450a0a'};color:${c.isActive !== false ? '#86efac' : '#fca5a5'};font-size:10px;font-weight:bold;padding:2px 6px;border-radius:5px">
                  ${c.isActive !== false ? 'ACTIVE' : 'PAUSED'}
                </span>
                <span style="color:#fbbf24;font-size:12px;font-weight:bold">
                  ${esc(c.type === 'percentage' ? c.value + '% Cashback' : '₹' + c.value + ' Cashback')}
                </span>
              </div>
              <div style="font-size:11px;color:#94a3b8;margin-top:4px">
                Product: <b style="color:#e2e8f0">${esc(c.productName || 'All Products')}</b> • 
                Min: ₹${esc(c.minOrder)} • 
                Max Cap: ₹${esc(c.maxCashback || 'No Cap')} • 
                Used: <b style="color:#34d399">${esc(c.usedCount || 0)}</b> times • 
                Total Cashback Disbursed: <b style="color:#38bdf8">₹${esc(c.totalDisbursed || 0)}</b>
              </div>
            </div>
            <div style="display:flex;gap:6px">
              <button data-cb2-toggle="${esc(c.id)}" type="button" style="background:#1e293b;color:#cbd5e1;border:1px solid #475569;border-radius:8px;padding:6px 10px;font-size:11px;font-weight:bold;cursor:pointer">
                ${c.isActive !== false ? 'Pause' : 'Resume'}
              </button>
              <button data-cb2-del="${esc(c.id)}" type="button" style="background:#450a0a;color:#fecaca;border:1px solid #7f1d1d;border-radius:8px;padding:6px 10px;font-size:11px;font-weight:bold;cursor:pointer">
                Delete
              </button>
            </div>
          </div>
        `;
      }).join('') : '<div style="color:#64748b;text-align:center;padding:16px;background:#0f172a;border-radius:10px">No cashback campaigns created yet. Create one above.</div>';

      [].slice.call(l.querySelectorAll('[data-cb2-toggle]')).forEach(function (b) {
        b.onclick = function () {
          var id = b.getAttribute('data-cb2-toggle');
          var cs = read('sh_cashback_campaigns_v1', []);
          var item = cs.find(function (x) { return x.id === id; });
          if (item) {
            item.isActive = item.isActive === false ? true : false;
            write('sh_cashback_campaigns_v1', cs);
            // Also sync sh_coupons
            var coupons = read('sh_coupons', []);
            var cpn = coupons.find(function (x) { return String(x.code || '').toUpperCase() === item.code; });
            if (cpn) {
              cpn.isActive = item.isActive;
              write('sh_coupons', coupons);
            }
            render();
          }
        };
      });

      [].slice.call(l.querySelectorAll('[data-cb2-del]')).forEach(function (b) {
        b.onclick = function () {
          var id = b.getAttribute('data-cb2-del');
          var cs = read('sh_cashback_campaigns_v1', []);
          var item = cs.find(function (x) { return x.id === id; });
          if (!confirm('Delete cashback campaign ' + (item ? item.code : '') + '?')) return;
          write('sh_cashback_campaigns_v1', cs.filter(function (c) { return c.id !== id; }));
          if (item) {
            var coupons = read('sh_coupons', []);
            write('sh_coupons', coupons.filter(function (x) { return String(x.code || '').toUpperCase() !== item.code; }));
          }
          render();
        };
      });
    }

    box.querySelector('#cb2-create').onclick = function () {
      var code = box.querySelector('#cb2-code').value.trim().toUpperCase();
      var value = Number(box.querySelector('#cb2-value').value || 0);
      if (!code || value <= 0) {
        alert('Please enter valid Cashback Code and Value.');
        return;
      }
      var pid = box.querySelector('#cb2-product').value;
      var prod = products.find(function (p) { return String(p.id) === String(pid); });
      var type = box.querySelector('#cb2-type').value;
      var minOrder = Number(box.querySelector('#cb2-min').value || 0);
      var maxCashback = Number(box.querySelector('#cb2-max').value || 0);
      var totalUsage = Math.max(1, Number(box.querySelector('#cb2-total').value || 500));
      var expiry = box.querySelector('#cb2-expiry').value || '2028-12-31';

      var campaign = {
        id: 'cb_' + Date.now(),
        code: code,
        productId: pid,
        type: type,
        value: value,
        minOrder: minOrder,
        maxCashback: maxCashback,
        totalUsage: totalUsage,
        usedCount: 0,
        totalDisbursed: 0,
        expiry: expiry,
        isActive: true,
        productName: prod ? prod.name : 'All Products',
        createdAt: new Date().toISOString()
      };

      var cs = read('sh_cashback_campaigns_v1', []);
      if (cs.some(function (x) { return x.code === code; })) {
        alert('Cashback code "' + code + '" already exists.');
        return;
      }
      cs.unshift(campaign);
      write('sh_cashback_campaigns_v1', cs);

      // CRITICAL FIX: Add to sh_coupons with the EXACT format required by the React buy modal!
      var coupons = read('sh_coupons', []);
      coupons = coupons.filter(function (x) { return String(x.code || '').toUpperCase() !== code; });
      coupons.unshift({
        id: 'cpn_cb_' + Date.now(),
        code: code,
        discountType: type === 'percentage' ? 'percentage' : 'fixed',
        discountValue: Number(value),
        minOrderAmount: minOrder,
        applicableCategory: 'all',
        applicableProductId: pid === 'all' ? 'all' : pid,
        maxUses: totalUsage,
        usedCount: 0,
        expiryDate: expiry,
        isActive: true,
        isCashback: true,
        cashbackType: type,
        cashbackValue: Number(value),
        maxCashback: maxCashback,
        title: code + ' Cashback Offer'
      });
      write('sh_coupons', coupons);

      alert('✅ Cashback Campaign "' + code + '" created successfully and linked to checkout coupon engine!');
      box.querySelector('#cb2-code').value = '';
      box.querySelector('#cb2-value').value = '';
      render();
    };

    render();
  }

  // Automated background Cashback Wallet Credit Engine
  function runCashbackEngine() {
    try {
      var orders = read('sh_orders', []);
      if (!Array.isArray(orders) || !orders.length) return;
      var campaigns = read('sh_cashback_campaigns_v1', []);
      if (!Array.isArray(campaigns) || !campaigns.length) return;
      var users = read('sh_users', []);
      var currentUser = read('sh_current_user', null);
      var modified = false;

      orders.forEach(function (o) {
        if (o.cashbackProcessed) return;
        var code = String(o.couponCode || '').trim().toUpperCase();
        if (!code) return;
        var camp = campaigns.find(function (c) {
          return c.code === code && c.isActive !== false;
        });
        if (!camp) return;

        // Calculate cashback
        var orderTotal = Number(o.totalAmount || 0);
        var cbAmt = 0;
        if (camp.type === 'percentage') {
          cbAmt = Math.round((orderTotal * Number(camp.value)) / 100);
          if (camp.maxCashback && cbAmt > camp.maxCashback) cbAmt = camp.maxCashback;
        } else {
          cbAmt = Number(camp.value);
        }

        if (cbAmt > 0) {
          // Credit to user's walletBalance
          var targetUser = users.find(function (u) {
            return (o.userId && u.id === o.userId) || (o.userEmail && String(u.email || '').toLowerCase() === String(o.userEmail).toLowerCase());
          });

          if (targetUser) {
            targetUser.walletBalance = Number((Number(targetUser.walletBalance || 0) + cbAmt).toFixed(2));
            if (currentUser && currentUser.id === targetUser.id) {
              currentUser.walletBalance = targetUser.walletBalance;
              write('sh_current_user', currentUser);
            }
          }

          o.cashbackProcessed = true;
          o.cashbackCredited = cbAmt;
          o.cashbackCode = code;
          camp.usedCount = (camp.usedCount || 0) + 1;
          camp.totalDisbursed = (camp.totalDisbursed || 0) + cbAmt;
          modified = true;

          // Dispatch notification
          fetch('./api/notify.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'send',
              type: 'user_balance_approved',
              payload: {
                user: targetUser || { email: o.userEmail, fullName: 'Valued Customer' },
                item: { amount: cbAmt, order_id: o.id },
                message: 'Congratulations! ₹' + cbAmt + ' Cashback credited to your Wallet for Order #' + (o.id || '') + ' (Promo: ' + code + ').'
              }
            })
          }).catch(function () {});

          // Display toast to customer
          if (currentUser && targetUser && currentUser.id === targetUser.id) {
            showToast('🎉 ₹' + cbAmt + ' Cashback credited to your wallet balance!');
          }
        } else {
          o.cashbackProcessed = true;
          modified = true;
        }
      });

      if (modified) {
        write('sh_orders', orders);
        write('sh_users', users);
        write('sh_cashback_campaigns_v1', campaigns);
      }
    } catch (e) {
      console.warn('Cashback engine error:', e);
    }
  }

  function showToast(msg) {
    var t = document.createElement('div');
    t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#0284c7;color:#fff;padding:12px 20px;border-radius:12px;font-weight:bold;font-size:13px;z-index:999999;box-shadow:0 10px 30px rgba(0,0,0,0.5);border:1px solid #38bdf8';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 4000);
  }

  // ==========================================
  // 5. AUTO UPI QR (Tab 6)
  // ==========================================
  function qr() {
    if (!admin() || !activeTab(6, 'APIs & Payment Config')) {
      remove('tg-upi-qr-box-v2');
      return;
    }
    var inp = [].find.call(document.querySelectorAll('input'), function (x) {
      return /Admin UPI ID/i.test(x.placeholder || '');
    });
    if (!inp) return;
    var box = document.getElementById('tg-upi-qr-box-v2');
    if (!box) {
      box = document.createElement('div');
      box.id = 'tg-upi-qr-box-v2';
      box.style.cssText = 'display:flex;gap:14px;align-items:center;padding:12px;margin-top:8px;background:#0f172a;border:1px solid #334155;border-radius:12px';
      inp.parentElement.parentElement.appendChild(box);
    }
    var u = (inp.value || '').trim();
    box.innerHTML = u ? '<img alt="UPI QR" src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' + encodeURIComponent('upi://pay?pa=' + u + '&pn=Deepak%20Bhai%20Tatkal%20Guru') + '" style="width:140px;height:140px;background:#fff;padding:5px;border-radius:10px"><div><b style="color:#fbbf24">AUTO UPI QR</b><div style="color:#cbd5e1;font-family:monospace;margin-top:5px">' + esc(u) + '</div><small style="color:#94a3b8">Dynamic QR code generated from entered UPI ID.</small></div>' : '<span style="color:#94a3b8">Enter UPI ID to generate live QR.</span>';
    if (inp.dataset.tgqr2 !== '1') {
      inp.dataset.tgqr2 = '1';
      inp.addEventListener('input', qr);
    }
  }

  // =========================================================================
  // 6. INTEGRATED EMAIL NOTIFICATION CONTROL CENTER IN TAB 6 (ADMIN PANEL 2)
  // =========================================================================
  function emailNotificationControlCenter() {
    if (!admin() || !activeTab(6, 'APIs & Payment Config')) {
      remove('tg-email-notify-card-v6');
      return;
    }
    var existingCard = document.getElementById('tg-email-notify-card-v6');
    if (existingCard) return;

    var title = [].find.call(document.querySelectorAll('h4'), function (x) {
      return /Payment Gateway, SMS OTP & Virtualizor VPS API Setup/i.test(x.textContent || '');
    });
    if (!title || !title.parentElement || !title.parentElement.parentElement) return;
    var container = title.parentElement.parentElement;

    var card = document.createElement('div');
    card.id = 'tg-email-notify-card-v6';
    card.style.cssText = 'margin-top:16px;margin-bottom:16px;padding:20px;background:#020617;border:1px solid #8b5cf6;border-radius:18px;box-shadow:0 10px 40px rgba(0,0,0,0.6);color:#fff';

    // List of 13 User Notifications & 9 Admin Mail Notifications requested by user
    var userEvents = [
      { key: 'user_registration_welcome', label: 'Registration Welcome', desc: 'Sent when new user registers an account' },
      { key: 'user_login_alert', label: 'Login Alert', desc: 'Sent upon successful user login' },
      { key: 'user_forgot_password_otp', label: 'Forgot Password OTP', desc: 'Sends 6-digit recovery OTP' },
      { key: 'user_password_changed', label: 'Password Changed', desc: 'Alert when password is changed' },
      { key: 'user_balance_add_request', label: 'Balance Add Request', desc: 'Sent when customer submits UTR' },
      { key: 'user_balance_approved', label: 'Balance Approved', desc: 'Notification on wallet recharge approval' },
      { key: 'user_balance_rejected', label: 'Balance Rejected', desc: 'Notification if UTR rejected' },
      { key: 'user_order_placed', label: 'Order Placed', desc: 'Instant confirmation on placing order' },
      { key: 'user_order_confirmed', label: 'Order Confirmed', desc: 'Order confirmation with summary' },
      { key: 'user_order_delivered', label: 'Order Delivered', desc: 'Instant product/stock delivery details' },
      { key: 'user_order_cancelled', label: 'Order Cancelled', desc: 'Cancellation & refund notice' },
      { key: 'user_order_status_changed', label: 'Order Status Changed', desc: 'Live status change updates' },
      { key: 'user_low_balance_alert', label: 'Low Balance Alert', desc: 'Prompt when wallet balance is low' }
    ];

    var adminEvents = [
      { key: 'admin_new_user_registration', label: 'New User Registration', desc: 'Alert admin on new customer signups' },
      { key: 'admin_new_balance_request', label: 'New Balance Request', desc: 'Alert admin to approve pending UTR' },
      { key: 'admin_balance_approved_rejected', label: 'Balance Approved/Rejected', desc: 'Audit log of balance decisions' },
      { key: 'admin_new_order', label: 'New Order', desc: 'Instant alert on new product purchase' },
      { key: 'admin_order_status', label: 'Order Status', desc: 'Order fulfillment status report' },
      { key: 'admin_stock_low_out', label: 'Stock Low/Out', desc: 'Alert when product stock is low/empty' },
      { key: 'admin_tatkal_request', label: 'Tatkal Request', desc: 'Special Tatkal booking service request' },
      { key: 'admin_sms_otp_order', label: 'SMS OTP Order', desc: 'Alert on new IRCTC SMS number orders' },
      { key: 'admin_system_error_failure', label: 'System Error/Failure', desc: 'Critical system / API failure alert' }
    ];

    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;border-bottom:1px solid #1e293b;padding-bottom:12px;margin-bottom:14px">
        <div>
          <h3 style="font-size:18px;font-weight:900;color:#c4b5fd;margin:0;display:flex;align-items:center;gap:8px">
            📧 Email Notification Control Center
          </h3>
          <p style="font-size:12px;color:#94a3b8;margin:4px 0 0">
            Granular Email Alert Management (User Notifications & Admin Mail Controls with individual ON/OFF switches).
          </p>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <label style="display:flex;align-items:center;gap:8px;font-size:12px;font-weight:bold;cursor:pointer;background:#1e1b4b;padding:6px 12px;border-radius:8px;border:1px solid #6366f1">
            <span>Master Email System:</span>
            <input type="checkbox" id="tg-enc-master" checked style="width:18px;height:18px;cursor:pointer">
          </label>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-bottom:16px;background:#0f172a;padding:12px;border-radius:12px;border:1px solid #334155">
        <div>
          <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Admin Destination Email</label>
          <input id="tg-enc-admin-email" type="email" value="irsad98@gmail.com" placeholder="admin@example.com" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#020617;color:#fff;border:1px solid #475569;border-radius:8px;font-size:12px">
        </div>
        <div style="display:flex;align-items:flex-end;gap:8px">
          <button id="tg-enc-test-btn" type="button" style="padding:9px 14px;background:#7c3aed;color:#fff;border:0;border-radius:8px;font-weight:bold;font-size:11px;cursor:pointer;display:flex;align-items:center;gap:6px">
            ⚡ Send Test Notification Email
          </button>
          <span id="tg-enc-test-status" style="font-size:11px;color:#94a3b8"></span>
        </div>
      </div>

      <!-- Quick Action Buttons -->
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
        <button id="tg-enc-all-user-on" type="button" style="background:#1e293b;color:#38bdf8;border:1px solid #0284c7;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer">
          ✓ Enable All User Mails
        </button>
        <button id="tg-enc-all-user-off" type="button" style="background:#1e293b;color:#94a3b8;border:1px solid #475569;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer">
          ✗ Disable All User Mails
        </button>
        <button id="tg-enc-all-admin-on" type="button" style="background:#1e293b;color:#a855f7;border:1px solid #9333ea;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;margin-left:auto">
          ✓ Enable All Admin Mails
        </button>
        <button id="tg-enc-all-admin-off" type="button" style="background:#1e293b;color:#94a3b8;border:1px solid #475569;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer">
          ✗ Disable All Admin Mails
        </button>
      </div>

      <!-- Sections Grid -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px">
        <!-- User Email Notifications -->
        <div style="background:#0b1329;border:1px solid #1e293b;border-radius:14px;padding:14px">
          <div style="font-size:13px;font-weight:bold;color:#38bdf8;margin-bottom:8px;display:flex;align-items:center;gap:6px">
            👤 User Email Notifications (${userEvents.length} Events)
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-bottom:10px">
            Har customer notification ko alag-alag Email ON ya OFF karein:
          </div>
          <div style="display:flex;flex-direction:column;gap:6px" id="tg-enc-user-list">
            ${userEvents.map(function (e) {
              return `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;background:#0f172a;border:1px solid #1e293b;border-radius:8px">
                  <div>
                    <div style="font-size:12px;font-weight:bold;color:#e2e8f0">${esc(e.label)}</div>
                    <div style="font-size:10px;color:#64748b">${esc(e.desc)}</div>
                  </div>
                  <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
                    <span id="tg-lbl-${e.key}" style="font-size:10px;font-weight:bold;color:#34d399">ON</span>
                    <input type="checkbox" data-tg-ev="${e.key}" checked style="width:16px;height:16px;accent-color:#10b981;cursor:pointer">
                  </label>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Admin Mail Notifications -->
        <div style="background:#130b29;border:1px solid #1e293b;border-radius:14px;padding:14px">
          <div style="font-size:13px;font-weight:bold;color:#c084fc;margin-bottom:8px;display:flex;align-items:center;gap:6px">
            🛡️ Admin Mail Alerts (${adminEvents.length} Events)
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-bottom:10px">
            Admin ko aane wale alerts ko alag-alag Email ON ya OFF karein:
          </div>
          <div style="display:flex;flex-direction:column;gap:6px" id="tg-enc-admin-list">
            ${adminEvents.map(function (e) {
              return `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;background:#0f172a;border:1px solid #1e293b;border-radius:8px">
                  <div>
                    <div style="font-size:12px;font-weight:bold;color:#e2e8f0">${esc(e.label)}</div>
                    <div style="font-size:10px;color:#64748b">${esc(e.desc)}</div>
                  </div>
                  <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
                    <span id="tg-lbl-${e.key}" style="font-size:10px;font-weight:bold;color:#34d399">ON</span>
                    <input type="checkbox" data-tg-ev="${e.key}" checked style="width:16px;height:16px;accent-color:#8b5cf6;cursor:pointer">
                  </label>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      </div>

      <!-- Save Bar -->
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-top:16px;padding-top:14px;border-top:1px solid #1e293b">
        <button id="tg-enc-save-btn" type="button" style="padding:11px 24px;background:#10b981;color:#fff;border:0;border-radius:10px;font-weight:900;font-size:13px;cursor:pointer;box-shadow:0 4px 15px rgba(16,185,129,0.3)">
          💾 Save Email Notification Settings
        </button>
        <span id="tg-enc-save-msg" style="font-size:12px;font-weight:bold;color:#94a3b8"></span>
      </div>
    `;

    container.insertBefore(card, title.parentElement.nextSibling);

    // Populate data from API / localStorage
    function loadValues() {
      fetch('./api/notify.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_settings' })
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res && res.ok && res.settings) {
          var s = res.settings;
          if (s.adminEmail) document.getElementById('tg-enc-admin-email').value = s.adminEmail;
          if (s.email && s.email.enabled !== undefined) document.getElementById('tg-enc-master').checked = !!s.email.enabled;
          var events = s.events || {};
          userEvents.concat(adminEvents).forEach(function (e) {
            var el = document.querySelector('[data-tg-ev="' + e.key + '"]');
            var lbl = document.getElementById('tg-lbl-' + e.key);
            if (el) {
              var val = true;
              if (events[e.key] !== undefined) {
                val = typeof events[e.key] === 'object' ? !!events[e.key].email : !!events[e.key];
              }
              el.checked = val;
              if (lbl) {
                lbl.textContent = val ? 'ON' : 'OFF';
                lbl.style.color = val ? '#34d399' : '#94a3b8';
              }
            }
          });
        }
      }).catch(function () {});
    }
    loadValues();

    // Event listeners for individual toggles
    card.querySelectorAll('[data-tg-ev]').forEach(function (cb) {
      cb.onchange = function () {
        var key = cb.getAttribute('data-tg-ev');
        var lbl = document.getElementById('tg-lbl-' + key);
        if (lbl) {
          lbl.textContent = cb.checked ? 'ON' : 'OFF';
          lbl.style.color = cb.checked ? '#34d399' : '#94a3b8';
        }
      };
    });

    // Quick actions
    card.querySelector('#tg-enc-all-user-on').onclick = function () {
      userEvents.forEach(function (e) {
        var el = document.querySelector('[data-tg-ev="' + e.key + '"]');
        var lbl = document.getElementById('tg-lbl-' + e.key);
        if (el) el.checked = true;
        if (lbl) { lbl.textContent = 'ON'; lbl.style.color = '#34d399'; }
      });
    };
    card.querySelector('#tg-enc-all-user-off').onclick = function () {
      userEvents.forEach(function (e) {
        var el = document.querySelector('[data-tg-ev="' + e.key + '"]');
        var lbl = document.getElementById('tg-lbl-' + e.key);
        if (el) el.checked = false;
        if (lbl) { lbl.textContent = 'OFF'; lbl.style.color = '#94a3b8'; }
      });
    };
    card.querySelector('#tg-enc-all-admin-on').onclick = function () {
      adminEvents.forEach(function (e) {
        var el = document.querySelector('[data-tg-ev="' + e.key + '"]');
        var lbl = document.getElementById('tg-lbl-' + e.key);
        if (el) el.checked = true;
        if (lbl) { lbl.textContent = 'ON'; lbl.style.color = '#34d399'; }
      });
    };
    card.querySelector('#tg-enc-all-admin-off').onclick = function () {
      adminEvents.forEach(function (e) {
        var el = document.querySelector('[data-tg-ev="' + e.key + '"]');
        var lbl = document.getElementById('tg-lbl-' + e.key);
        if (el) el.checked = false;
        if (lbl) { lbl.textContent = 'OFF'; lbl.style.color = '#94a3b8'; }
      });
    };

    // Test email
    card.querySelector('#tg-enc-test-btn').onclick = function () {
      var st = document.getElementById('tg-enc-test-status');
      var to = document.getElementById('tg-enc-admin-email').value.trim();
      st.textContent = 'Sending test email...';
      st.style.color = '#fbbf24';
      fetch('./api/notify.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'test', channel: 'email', to: to })
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res && res.ok) {
          st.textContent = '✓ ' + (res.message || 'Test email sent successfully!');
          st.style.color = '#34d399';
        } else {
          st.textContent = '✗ ' + (res.message || 'Failed to send test email.');
          st.style.color = '#f87171';
        }
      }).catch(function (err) {
        st.textContent = '✗ Network error.';
        st.style.color = '#f87171';
      });
    };

    // Save preferences
    card.querySelector('#tg-enc-save-btn').onclick = function () {
      var msg = document.getElementById('tg-enc-save-msg');
      msg.textContent = 'Saving settings...';
      msg.style.color = '#fbbf24';

      var adminEmail = document.getElementById('tg-enc-admin-email').value.trim();
      var masterEmail = document.getElementById('tg-enc-master').checked;
      var events = {};
      userEvents.concat(adminEvents).forEach(function (e) {
        var el = document.querySelector('[data-tg-ev="' + e.key + '"]');
        events[e.key] = {
          name: e.label,
          email: el ? el.checked : true,
          sms: false,
          whatsapp: false
        };
      });

      var settingsPayload = {
        adminEmail: adminEmail,
        email: { enabled: masterEmail },
        events: events
      };

      fetch('./api/notify.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save_settings',
          settings: settingsPayload
        })
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res && res.ok) {
          msg.textContent = '✓ All 22 Email notification settings saved successfully!';
          msg.style.color = '#34d399';
          // Also save in localStorage
          try {
            var st = read('sh_api_settings', {});
            st.notificationSettings = Object.assign({}, st.notificationSettings || {}, settingsPayload);
            write('sh_api_settings', st);
          } catch (e) {}
        } else {
          msg.textContent = '✗ Save error: ' + (res.message || 'Check database connection');
          msg.style.color = '#f87171';
        }
      }).catch(function () {
        msg.textContent = '✗ Network error.';
        msg.style.color = '#f87171';
      });
    };
  }

  // =========================================================================
  // 7. ADMIN PANEL 1 — UI & THEME CONTROL ENHANCEMENTS
  // =========================================================================
  function adminPanel1Enhancements() {
    var isPanel1 = hasText('ADMIN PANEL 1 — UI & Theme Control');
    if (!isPanel1) return;

    // A) Floating Tab: Add 3 Fast Support AI Assistant Controls
    var floatTabActive = [].slice.call(document.querySelectorAll('button')).some(function (b) {
      return /Floating Icons/i.test(b.textContent || '') && /bg-indigo-600/.test(b.className || '');
    });

    if (floatTabActive && !document.getElementById('tg-fast-support-admin-card')) {
      var container = document.querySelector('.space-y-4.max-w-xl') || document.querySelector('[class*="space-y-4"]');
      if (container) {
        var card = document.createElement('div');
        card.id = 'tg-fast-support-admin-card';
        card.style.cssText = 'padding:16px;background:#020617;border:1px solid #f59e0b;border-radius:16px;margin-top:14px;color:#fff';
        
        var theme = read('sh_theme_settings', {});
        var fs = theme.fastSupportConfig || {
          ai1: { name: '⚡ Fast AI 1: Live General Support', active: true },
          ai2: { name: '🚄 Fast AI 2: Tatkal Timing & Server Expert', active: true },
          ai3: { name: '💳 Fast AI 3: Wallet & OTP Billing Assistant', active: true }
        };

        card.innerHTML = `
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <h4 style="font-size:14px;font-weight:900;color:#fbbf24;margin:0;display:flex;align-items:center;gap:6px">
              ⚡ Fast Support — 3 AI Support Engines
            </h4>
            <span style="font-size:10px;background:#78350f;color:#fde68a;padding:2px 6px;border-radius:4px;font-weight:bold">Active on Site</span>
          </div>
          <p style="font-size:11px;color:#94a3b8;margin-bottom:12px">
            Configure the 3 distinct AI support assistants available in the customer Floating Fast Support widget:
          </p>
          <div style="display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px;background:#0f172a;border:1px solid #1e293b;border-radius:10px">
              <div>
                <div style="font-size:12px;font-weight:bold;color:#e2e8f0">⚡ Fast AI 1: Live General Support</div>
                <div style="font-size:10px;color:#64748b">Tatkal products, software downloads, high-speed VPS setup & general portal help</div>
              </div>
              <input type="checkbox" id="tg-fs-ai1" ${fs.ai1 && fs.ai1.active !== false ? 'checked' : ''} style="width:18px;height:18px;accent-color:#10b981;cursor:pointer">
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px;background:#0f172a;border:1px solid #1e293b;border-radius:10px">
              <div>
                <div style="font-size:12px;font-weight:bold;color:#e2e8f0">🚄 Fast AI 2: Tatkal Timing & Server Expert</div>
                <div style="font-size:10px;color:#64748b">10:00 AM AC & 11:00 AM Sleeper live timings, low-ping nodes, autofill & speed tips</div>
              </div>
              <input type="checkbox" id="tg-fs-ai2" ${fs.ai2 && fs.ai2.active !== false ? 'checked' : ''} style="width:18px;height:18px;accent-color:#10b981;cursor:pointer">
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px;background:#0f172a;border:1px solid #1e293b;border-radius:10px">
              <div>
                <div style="font-size:12px;font-weight:bold;color:#e2e8f0">💳 Fast AI 3: Wallet & OTP Billing Assistant</div>
                <div style="font-size:10px;color:#64748b">Instant UTR payment verification, wallet recharge status, cashback & SMS OTP orders</div>
              </div>
              <input type="checkbox" id="tg-fs-ai3" ${fs.ai3 && fs.ai3.active !== false ? 'checked' : ''} style="width:18px;height:18px;accent-color:#10b981;cursor:pointer">
            </div>
          </div>
          <button id="tg-fs-save" type="button" style="margin-top:12px;padding:8px 16px;background:#f59e0b;color:#000;border:0;border-radius:8px;font-weight:900;font-size:11px;cursor:pointer">
            Save Fast Support Config
          </button>
          <span id="tg-fs-msg" style="margin-left:10px;font-size:11px;color:#34d399"></span>
        `;
        container.appendChild(card);

        card.querySelector('#tg-fs-save').onclick = function () {
          var t = read('sh_theme_settings', {});
          t.fastSupportConfig = {
            ai1: { name: '⚡ Fast AI 1: Live General Support', active: card.querySelector('#tg-fs-ai1').checked },
            ai2: { name: '🚄 Fast AI 2: Tatkal Timing & Server Expert', active: card.querySelector('#tg-fs-ai2').checked },
            ai3: { name: '💳 Fast AI 3: Wallet & OTP Billing Assistant', active: card.querySelector('#tg-fs-ai3').checked }
          };
          t.floatingGeminiActive = true;
          write('sh_theme_settings', t);
          var msg = card.querySelector('#tg-fs-msg');
          msg.textContent = '✓ Saved successfully!';
          setTimeout(function () { msg.textContent = ''; }, 3000);
        };
      }
    }

    // B) Popup Ads Banner Tab: Cleanup as requested ("baaki sab delete pop_up 3d ho")
    var popupTabActive = [].slice.call(document.querySelectorAll('button')).some(function (b) {
      return /Popup Ads Banner/i.test(b.textContent || '') && /bg-indigo-600/.test(b.className || '');
    });

    if (popupTabActive) {
      // Hide title & message fields from admin UI
      var labels = [].slice.call(document.querySelectorAll('label'));
      labels.forEach(function (l) {
        var t = (l.textContent || '').trim();
        if (/Popup Banner Title/i.test(t) || /Popup Banner Message \/ Offer Details/i.test(t)) {
          if (l.parentElement) l.parentElement.style.display = 'none';
        }
      });
      // Ensure WhatsApp channel link field exists & is labeled clearly
      var linkInput = [].find.call(document.querySelectorAll('input'), function (inp) {
        return /https:\/\/wa\.me/i.test(inp.value || '') || /WhatsApp Redirect Link/i.test(inp.previousElementSibling?.textContent || '');
      });
      if (linkInput && linkInput.previousElementSibling) {
        linkInput.previousElementSibling.textContent = '📢 WhatsApp Channel Link (Join Channel Button)';
      }
    }

    // Hide separate Notification & Footer tab as requested: ("Notification Bar & Footer Bar Messages nahi kaam kar raha iska isko delete kar do iska saara settings Offer Sale & Countdown Bar me le aao")
    var notifTabBtn = [].slice.call(document.querySelectorAll('button')).find(function (b) {
      return /Notification & Footer/i.test(b.textContent || '');
    });
    if (notifTabBtn) notifTabBtn.style.display = 'none';

    // B) Popup Ads Banner Tab: WhatsApp Channel link + Ads Banner click link
    var popupTabActive = [].slice.call(document.querySelectorAll('button')).some(function (b) {
      return /Popup Ads Banner/i.test(b.textContent || '') && /bg-indigo-600/.test(b.className || '');
    });

    if (popupTabActive && !document.getElementById('tg-popup-enhanced-links-card')) {
      var container = document.querySelector('.space-y-4.max-w-xl') || document.querySelector('[class*="space-y-4"]');
      if (container) {
        var card = document.createElement('div');
        card.id = 'tg-popup-enhanced-links-card';
        card.style.cssText = 'padding:16px;background:#020617;border:1px solid #f59e0b;border-radius:16px;margin-top:14px;color:#fff';

        var theme = read('sh_theme_settings', {});
        var channelLink = theme.whatsappChannelLink || theme.popupChannelLink || 'https://whatsapp.com/channel/0029VaTatkalGuru';
        var bannerClickLink = theme.popupBannerLink || 'https://tatkalguru.com/#products';

        card.innerHTML = `
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <h4 style="font-size:14px;font-weight:900;color:#fbbf24;margin:0;display:flex;align-items:center;gap:6px">
              📢 WhatsApp Channel & Clickable Ads Banner Links
            </h4>
            <span style="font-size:10px;background:#78350f;color:#fde68a;padding:2px 6px;border-radius:4px;font-weight:bold">3D Popup Active</span>
          </div>
          <p style="font-size:11px;color:#94a3b8;margin-bottom:12px">
            Customer popup modal me WhatsApp Channel button ka link aur Ads Banner par click karne par khulne wala link set karein:
          </p>
          <div style="display:flex;flex-direction:column;gap:10px">
            <div>
              <label style="display:block;font-size:11px;font-weight:bold;color:#4ade80;margin-bottom:4px">
                📢 Official WhatsApp Channel URL (Join Button):
              </label>
              <input id="tg-popup-channel-input" value="${esc(channelLink)}" placeholder="https://whatsapp.com/channel/..." style="width:100%;box-sizing:border-box;padding:8px 10px;background:#0f172a;border:1px solid #1e293b;border-radius:8px;color:#fff;font-size:12px">
            </div>
            <div>
              <label style="display:block;font-size:11px;font-weight:bold;color:#38bdf8;margin-bottom:4px">
                🔗 Ads Banner Click URL / Offer Redirect Link:
              </label>
              <input id="tg-popup-banner-link-input" value="${esc(bannerClickLink)}" placeholder="https://..." style="width:100%;box-sizing:border-box;padding:8px 10px;background:#0f172a;border:1px solid #1e293b;border-radius:8px;color:#fff;font-size:12px">
            </div>
          </div>
          <button id="tg-popup-save-btn" type="button" style="margin-top:12px;padding:8px 18px;background:#f59e0b;color:#000;border:0;border-radius:8px;font-weight:900;font-size:11px;cursor:pointer">
            Save Popup Links
          </button>
          <span id="tg-popup-msg" style="margin-left:10px;font-size:11px;color:#34d399"></span>
        `;
        container.appendChild(card);

        card.querySelector('#tg-popup-save-btn').onclick = function () {
          var t = read('sh_theme_settings', {});
          t.whatsappChannelLink = card.querySelector('#tg-popup-channel-input').value.trim();
          t.popupChannelLink = t.whatsappChannelLink;
          t.popupBannerLink = card.querySelector('#tg-popup-banner-link-input').value.trim();
          t.popupActive = true;
          write('sh_theme_settings', t);
          var msg = card.querySelector('#tg-popup-msg');
          msg.textContent = '✓ Saved successfully!';
          setTimeout(function () { msg.textContent = ''; }, 3000);
        };
      }
    }

    // C) Offer Sale & Countdown Bar Tab: Contains Consolidated Sale Countdown, Top Notification Marquee & Footer Bar
    var offerTabActive = [].slice.call(document.querySelectorAll('button')).some(function (b) {
      return /Sale Countdown/i.test(b.textContent || '') && /bg-indigo-600/.test(b.className || '');
    });

    if (offerTabActive && !document.getElementById('tg-offer-notif-combined-card')) {
      var container = document.querySelector('.space-y-4.max-w-xl') || document.querySelector('[class*="space-y-4"]');
      if (container) {
        var card = document.createElement('div');
        card.id = 'tg-offer-notif-combined-card';
        card.style.cssText = 'padding:18px;background:#020617;border:1px solid #6366f1;border-radius:18px;margin-top:16px;color:#fff;box-shadow:0 10px 30px rgba(0,0,0,0.5)';

        var theme = read('sh_theme_settings', {});
        var defaultNotifs = [
          { id: 'n1', title: '🚄 Tatkal Booking Timing Alert', text: '🚄 AC Tatkal opens at 10:00 AM | Sleeper at 11:00 AM IST daily — Low Ping Indian VPS Ready!', active: true },
          { id: 'n2', title: '⚡ High-Speed VPS Stock Alert', text: '⚡ High-Speed 1Gbps Indian Cloud VPS in Stock — Instant Auto-Delivery & 99.9% Uptime!', active: true },
          { id: 'n3', title: '💰 Wallet Recharge Cashback Offer', text: '💰 Special Offer: Add ₹500+ in Wallet and get Instant 10% Extra Cashback credited!', active: true },
          { id: 'n4', title: '📱 IRCTC Fast SMS OTP Delivery', text: '📱 IRCTC High-Speed Fast OTP verification active — Instant SMS delivery in <2 seconds!', active: true },
          { id: 'n5', title: '📢 24x7 Fast AI & WhatsApp Support', text: '📢 Need help? 24x7 Fast Support (3 AI Engines) & Official WhatsApp Channel are Live!', active: true }
        ];

        var savedNotifs = theme.notificationTypes || defaultNotifs;
        var topActive = theme.topNotificationActive !== false;
        var customMarquee = theme.topNotificationText || '';
        var footerTxt = theme.footerText || '© 2026 Deepak Bhai Tatkal Guru. All rights reserved. High-Speed IRCTC Tatkal Software & Cloud VPS.';
        var footerDisclaimer = theme.footerDisclaimer || 'Disclaimer: Tatkal Guru provides cloud infrastructure, automation utilities, and OTP services. We are not affiliated with IRCTC or Indian Railways.';

        card.innerHTML = `
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;border-b:1px solid #1e293b;padding-bottom:10px">
            <div>
              <h4 style="font-size:15px;font-weight:900;color:#818cf8;margin:0;display:flex;align-items:center;gap:6px">
                📢 Top Notification Bar & Footer Bar Messages
              </h4>
              <p style="font-size:11px;color:#94a3b8;margin:3px 0 0 0">
                Consolidated settings for Top Announcement Marquee and Bottom Footer branding.
              </p>
            </div>
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:bold;cursor:pointer">
              <span style="color:#e2e8f0">Top Bar:</span>
              <input type="checkbox" id="tg-comb-top-active" ${topActive ? 'checked' : ''} style="width:18px;height:18px;accent-color:#10b981;cursor:pointer">
            </label>
          </div>

          <div style="font-size:12px;font-weight:bold;color:#38bdf8;margin-bottom:8px">
            5 Granular Alert Categories (Top Marquee Presets):
          </div>

          <div style="display:flex;flex-direction:column;gap:8px" id="tg-comb-notif-list">
            ${savedNotifs.map(function (n, idx) {
              return `
                <div style="padding:9px 12px;background:#0f172a;border:1px solid #1e293b;border-radius:10px">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
                    <span style="font-size:11px;font-weight:bold;color:#f1f5f9">${esc(n.title)}</span>
                    <label style="display:flex;align-items:center;gap:6px;font-size:11px;cursor:pointer">
                      <span id="tg-comb-n-state-${idx}" style="font-size:10px;font-weight:bold;color:${n.active !== false ? '#34d399' : '#94a3b8'}">${n.active !== false ? 'ON' : 'OFF'}</span>
                      <input type="checkbox" data-comb-idx="${idx}" ${n.active !== false ? 'checked' : ''} style="width:16px;height:16px;accent-color:#10b981;cursor:pointer">
                    </label>
                  </div>
                  <input id="tg-comb-text-${idx}" value="${esc(n.text)}" style="width:100%;box-sizing:border-box;padding:6px 10px;background:#020617;color:#fff;border:1px solid #334155;border-radius:6px;font-size:11px">
                </div>
              `;
            }).join('')}
          </div>

          <div style="margin-top:14px;border-top:1px solid #1e293b;padding-top:12px">
            <label style="display:block;font-size:12px;font-weight:bold;color:#fbbf24;margin-bottom:4px">
              Additional Custom Marquee Text:
            </label>
            <input id="tg-comb-custom-marquee" value="${esc(customMarquee)}" placeholder="e.g. Flash Sale Live Today! 10% Extra Cashback on All Recharges." style="width:100%;box-sizing:border-box;padding:8px 10px;background:#0f172a;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
          </div>

          <div style="margin-top:14px;border-top:1px solid #1e293b;padding-top:12px;display:flex;flex-direction:column;gap:10px">
            <div style="font-size:12px;font-weight:bold;color:#a855f7">
              Footer Bar Messages & Disclaimers:
            </div>
            <div>
              <label style="display:block;font-size:11px;color:#94a3b8;margin-bottom:3px">Footer Copyright & Branding Text:</label>
              <input id="tg-comb-footer-text" value="${esc(footerTxt)}" style="width:100%;box-sizing:border-box;padding:7px 10px;background:#0f172a;border:1px solid #334155;border-radius:8px;color:#fff;font-size:11px">
            </div>
            <div>
              <label style="display:block;font-size:11px;color:#94a3b8;margin-bottom:3px">Footer Legal Disclaimer Notice:</label>
              <input id="tg-comb-footer-disc" value="${esc(footerDisclaimer)}" style="width:100%;box-sizing:border-box;padding:7px 10px;background:#0f172a;border:1px solid #334155;border-radius:8px;color:#fff;font-size:11px">
            </div>
          </div>

          <div style="margin-top:16px;display:flex;align-items:center;gap:10px">
            <button id="tg-comb-save-btn" type="button" style="padding:9px 20px;background:#6366f1;color:#fff;border:0;border-radius:8px;font-weight:900;font-size:12px;cursor:pointer">
              💾 Save Notification & Footer Settings
            </button>
            <span id="tg-comb-save-msg" style="font-size:11px;color:#34d399;font-weight:bold"></span>
          </div>
        `;
        container.appendChild(card);

        card.querySelectorAll('[data-comb-idx]').forEach(function (cb) {
          cb.onchange = function () {
            var idx = cb.getAttribute('data-comb-idx');
            var lbl = document.getElementById('tg-comb-n-state-' + idx);
            if (lbl) {
              lbl.textContent = cb.checked ? 'ON' : 'OFF';
              lbl.style.color = cb.checked ? '#34d399' : '#94a3b8';
            }
          };
        });

        card.querySelector('#tg-comb-save-btn').onclick = function () {
          var list = [];
          savedNotifs.forEach(function (n, idx) {
            var cb = card.querySelector('[data-comb-idx="' + idx + '"]');
            var txt = card.querySelector('#tg-comb-text-' + idx);
            list.push({
              id: n.id,
              title: n.title,
              text: txt ? txt.value.trim() : n.text,
              active: cb ? cb.checked : true
            });
          });
          var t = read('sh_theme_settings', {});
          t.notificationTypes = list;
          t.topNotificationActive = card.querySelector('#tg-comb-top-active').checked;
          t.topNotificationText = card.querySelector('#tg-comb-custom-marquee').value.trim();
          t.footerText = card.querySelector('#tg-comb-footer-text').value.trim();
          t.footerDisclaimer = card.querySelector('#tg-comb-footer-disc').value.trim();
          write('sh_theme_settings', t);
          var msg = card.querySelector('#tg-comb-save-msg');
          msg.textContent = '✓ Saved successfully!';
          setTimeout(function () { msg.textContent = ''; }, 3000);
        };
      }
    }
  }

  // =========================================================================
  // 8. 3D CUSTOMER POPUP ADS BANNER ENHANCER (WhatsApp Channel + Clickable Banner)
  // =========================================================================
  function enhanceCustomerPopup3D() {
    var modal = document.querySelector('.fixed.inset-0.z-50.bg-black\\/70') || document.querySelector('[class*="fixed inset-0"][class*="z-50"]');
    if (!modal) return;
    var innerCard = modal.querySelector('.bg-white.rounded-2xl') || modal.querySelector('[class*="bg-white rounded-2xl"]');
    if (!innerCard) return;

    if (innerCard.dataset.tg3d !== '1') {
      innerCard.dataset.tg3d = '1';
      innerCard.style.cssText = 'perspective:1200px;transform-style:preserve-3d;transform:rotateX(2deg) translateY(-2px);border:2px solid #f59e0b;border-radius:24px;overflow:hidden;box-shadow:0 30px 80px -10px rgba(0,0,0,0.9),0 0 45px rgba(245,158,11,0.35);background:#090d16;color:#fff;transition:transform 0.4s ease';

      var t = read('sh_theme_settings', {});
      var channelLink = t.whatsappChannelLink || t.popupChannelLink || t.popupLink || 'https://whatsapp.com/channel/0029VaTatkalGuru';
      var bannerLink = t.popupBannerLink || '#';

      // Make banner image clickable
      var imgEl = innerCard.querySelector('img');
      if (imgEl && !imgEl.parentElement.dataset.tgBannerLink) {
        var aWrap = document.createElement('a');
        aWrap.href = bannerLink !== '#' ? bannerLink : channelLink;
        aWrap.target = '_blank';
        aWrap.rel = 'noopener noreferrer';
        aWrap.dataset.tgBannerLink = '1';
        aWrap.style.cssText = 'display:block;position:relative;cursor:pointer;text-decoration:none';
        imgEl.parentNode.insertBefore(aWrap, imgEl);
        aWrap.appendChild(imgEl);

        var badge = document.createElement('div');
        badge.style.cssText = 'position:absolute;bottom:10px;right:10px;background:rgba(2,6,23,0.85);color:#38bdf8;font-size:10px;font-weight:bold;padding:4px 8px;border-radius:6px;backdrop-filter:blur(4px);border:1px solid #0284c7';
        badge.textContent = '🔗 Click Banner to View Offer';
        aWrap.appendChild(badge);
      }

      var btnArea = innerCard.querySelector('.pt-2.flex.flex-col') || innerCard.querySelector('[class*="pt-2 flex"]');
      if (btnArea) {
        btnArea.innerHTML = `
          <a href="${esc(channelLink)}" target="_blank" rel="noopener noreferrer" style="display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:13px 20px;background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;border-radius:14px;font-weight:900;font-size:14px;text-decoration:none;box-shadow:0 10px 25px rgba(34,197,94,0.4);border:1px solid #86efac;text-transform:uppercase;letter-spacing:0.5px">
            <svg style="width:20px;height:20px" viewBox="0 0 24 24" fill="currentColor"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.312.045-.694.072-2.18-.544-1.898-.788-3.125-2.73-3.22-2.857-.094-.127-.768-1.022-.768-1.95 0-.927.484-1.383.655-1.573.172-.191.376-.239.502-.239.126 0 .251.002.361.007.116.006.27-.044.423.323.158.38.541 1.317.589 1.413.048.096.08.209.016.335-.064.127-.096.206-.191.317-.095.111-.2.247-.286.333-.095.096-.194.2-.083.39.111.191.493.814 1.06 1.317.73.65 1.345.852 1.536.947.19.096.302.08.414-.048.112-.127.478-.557.605-.747.127-.191.254-.159.429-.095.175.064 1.111.524 1.302.62.19.096.318.143.366.223.047.079.047.46-.097.865z"/></svg>
            📢 Join Official WhatsApp Channel
          </a>
        `;
      }
    }
  }

  // =========================================================================
  // 9. DYNAMIC SMS SERVICE & CODE MANAGER (Admin Server Pick + Hide for Users)
  // =========================================================================
  function smsServiceAndUserFix() {
    // Hide Server 1/2 from customer view as requested
    var els = document.querySelectorAll('div, p, span, h4');
    for (var i = 0; i < els.length; i++) {
      var txt = els[i].textContent || '';
      if (/Server 1 \(Grizzly SMS API\)/i.test(txt) || /Server 2 \(SMS India Pro API\)/i.test(txt)) {
        var box = els[i].closest('.flex.flex-wrap.gap-2') || els[i].closest('.bg-slate-900\\/80') || els[i];
        if (box) box.style.display = 'none';
      }
      if (/1\.\s*Select Server API Gateway/i.test(txt)) {
        var step1 = els[i].closest('.bg-slate-900') || els[i].parentElement;
        if (step1) step1.style.display = 'none';
      }
    }

    // In Admin Panel 2 Tab 8: Dynamic SMS Service & Code Manager
    if (admin() && activeTab(8, 'Dynamic SMS Service')) {
      var addForm = document.querySelector('form, .space-y-4');
      if (addForm && !document.getElementById('tg-sms-server-select-group')) {
        var serverGroup = document.createElement('div');
        serverGroup.id = 'tg-sms-server-select-group';
        serverGroup.style.cssText = 'margin-top:10px;padding:10px;background:#0f172a;border:1px solid #1e293b;border-radius:10px';
        serverGroup.innerHTML = `
          <label style="display:block;font-size:12px;font-weight:bold;color:#38bdf8;margin-bottom:6px">
            🎯 Target Server Gateway (Auto-assigned for users):
          </label>
          <select id="tg-sms-server-choice" style="width:100%;padding:8px 12px;background:#020617;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
            <option value="2">Server 2 — SMS India Pro (Fast Indian Route)</option>
            <option value="1">Server 1 — Grizzly SMS (Global & International)</option>
            <option value="3">Server 3 — Tatkal Guru Express Direct API</option>
          </select>
          <p style="font-size:10px;color:#64748b;margin:4px 0 0 0">
            When users order this service, it will automatically connect to this server without showing server choice to user.
          </p>
        `;
        var submitBtn = addForm.querySelector('button[type="submit"], button.bg-indigo-600') || addForm.querySelector('button');
        if (submitBtn && submitBtn.parentNode) {
          submitBtn.parentNode.insertBefore(serverGroup, submitBtn);
        }
      }
    }
  }

  // =========================================================================
  // 10. USER PANEL: TOP NOTIFICATION MARQUEE BAR & FOOTER UPDATER
  // =========================================================================
  function renderUserTopNotifAndFooter() {
    var theme = read('sh_theme_settings', {});
    var isTopActive = theme.topNotificationActive !== false;
    var notifTypes = theme.notificationTypes || [];
    var activeNotifs = notifTypes.filter(function (n) { return n.active !== false; });
    var customText = theme.topNotificationText || '';

    var marqueeContainer = document.getElementById('tg-user-top-marquee-bar');
    if (!isTopActive || (!activeNotifs.length && !customText)) {
      if (marqueeContainer) marqueeContainer.style.display = 'none';
    } else {
      if (!marqueeContainer) {
        marqueeContainer = document.createElement('div');
        marqueeContainer.id = 'tg-user-top-marquee-bar';
        marqueeContainer.style.cssText = 'position:relative;z-index:9999;background:linear-gradient(90deg,#0f172a,#1e1b4b,#0f172a);border-bottom:1px solid rgba(99,102,241,0.4);color:#fff;font-size:12px;overflow:hidden;padding:6px 12px;display:flex;align-items:center;box-shadow:0 4px 15px rgba(0,0,0,0.5)';
        document.body.insertBefore(marqueeContainer, document.body.firstChild);
      }
      marqueeContainer.style.display = 'flex';

      var marqueeText = activeNotifs.map(function (n) { return n.text; }).join('   ★   ');
      if (customText) marqueeText = customText + (marqueeText ? '   ★   ' + marqueeText : '');

      if (marqueeContainer.dataset.renderedText !== marqueeText) {
        marqueeContainer.dataset.renderedText = marqueeText;
        marqueeContainer.innerHTML = `
          <div style="display:flex;align-items:center;gap:8px;padding-right:12px;border-right:1px solid rgba(255,255,255,0.15);white-space:nowrap;font-weight:900;color:#f59e0b;font-size:11px">
            <span>📢 ANNOUNCEMENT</span>
          </div>
          <marquee behavior="scroll" direction="left" scrollamount="6" style="flex:1;margin:0 12px;color:#e2e8f0;font-weight:500;font-size:12px" onmouseover="this.stop()" onmouseout="this.start()">
            ${esc(marqueeText)}
          </marquee>
          <button type="button" onclick="this.parentElement.style.display='none'" style="background:transparent;border:0;color:#94a3b8;cursor:pointer;font-size:14px;padding:0 6px" title="Close alert">✕</button>
        `;
      }
    }

    if (theme.footerText) {
      var footers = document.querySelectorAll('footer');
      footers.forEach(function (f) {
        var p = f.querySelector('p');
        if (p && !p.dataset.tgCustom) {
          p.dataset.tgCustom = '1';
          p.textContent = theme.footerText;
        }
      });
    }
  }

  // ==========================================
  // SCAN LOOP & MUTATION OBSERVER
  // ==========================================
  function scan() {
    clearTimeout(timer);
    timer = setTimeout(function () {
      try {
        orders();
        stock();
        userTools();
        cashback();
        runCashbackEngine();
        qr();
        emailNotificationControlCenter();
        adminPanel1Enhancements();
        enhanceCustomerPopup3D();
        smsServiceAndUserFix();
        renderUserTopNotifAndFooter();
      } catch (e) {
        console.error('TG admin safe helper:', e);
      }
    }, 120);
  }

  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('DOMContentLoaded', function () {
    setTimeout(scan, 600);
  });
  setInterval(scan, 1200);
  scan();
})();

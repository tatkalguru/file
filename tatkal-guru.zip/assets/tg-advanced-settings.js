/**
 * Tatkal Guru - 100+ Advanced Admin System Controls Suite
 * Renders inside Admin Panel 2 and applies active security, UX, and engine controls.
 */
(function () {
  'use strict';

  var SETTINGS_KEY = 'sh_advanced_admin_settings';

  var DEFAULT_SETTINGS = {
    // 🛡️ Security & Firewall (15)
    sec_brute_force_shield: true,
    sec_block_vpn_proxies: false,
    sec_disable_right_click: false,
    sec_disable_devtools: false,
    sec_force_ssl: true,
    sec_session_timeout: 60,
    sec_two_factor_auth: false,
    sec_ip_whitelist_mode: false,
    sec_xss_sanitizer: true,
    sec_sql_injection_guard: true,
    sec_audit_log_retention: 90,
    sec_mask_user_passwords: true,
    sec_password_complexity: true,
    sec_honeypot_login: true,
    sec_ddos_challenge: false,

    // 🚄 Tatkal Engine & Latency Optimizer (12)
    tatkal_auto_ping_sync: true,
    tatkal_pre_fetch_nodes: true,
    tatkal_ac_opening_alert: true,
    tatkal_sl_opening_alert: true,
    tatkal_queue_concurrency: 5,
    tatkal_smart_retry_limit: 3,
    tatkal_dns_over_https: true,
    tatkal_direct_vps_mode: true,
    tatkal_session_keepalive: 300,
    tatkal_captcha_fast_engine: true,
    tatkal_master_list_sync: true,
    tatkal_booking_sound: true,

    // 💰 Wallet, Tax & Currency (14)
    wallet_min_recharge: 100,
    wallet_max_recharge: 50000,
    wallet_auto_approval: true,
    wallet_bonus_percent: 5,
    wallet_gst_tax_rate: 0,
    wallet_currency_symbol: '₹',
    wallet_low_balance_threshold: 200,
    wallet_daily_spend_limit: 25000,
    wallet_refund_policy: true,
    wallet_cashback_auto_credit: true,
    wallet_qr_generator_type: 'dynamic',
    wallet_referral_reward: 50,
    wallet_tatkal_service_fee: 0,
    wallet_instant_payout: false,

    // 📢 Telegram & Webhooks (12)
    tg_bot_token: '',
    tg_admin_chat_id: '',
    tg_channel_link: 'https://t.me/tatkalguruofficial',
    tg_notify_new_orders: true,
    tg_notify_wallet_requests: true,
    tg_notify_low_stock: true,
    tg_webhook_url: '',
    tg_webhook_secret: '',
    tg_broadcast_speed: 25,
    tg_silent_notifications: false,
    tg_command_support: true,
    tg_daily_report_time: '23:00',

    // 🎨 Customer UX & Sound FX (14)
    ux_click_sound_effects: false,
    ux_confetti_on_order: true,
    ux_dark_mode_default: true,
    ux_floating_support_bubble: true,
    ux_live_visitors_counter: true,
    ux_smooth_page_transitions: true,
    ux_back_to_top_button: true,
    ux_sticky_header: true,
    ux_tatkal_clock_widget: true,
    ux_marquee_scroll_speed: 35,
    ux_high_contrast_inputs: true,
    ux_mobile_haptic_feedback: true,
    ux_skeleton_loaders: true,
    ux_compact_table_view: false,

    // 🔍 SEO & Tracking Codes (12)
    seo_meta_title: 'Tatkal Guru — High-Speed IRCTC Tatkal Software & Low-Ping VPS',
    seo_meta_desc: 'India fastest Tatkal booking software, premium high-speed cloud VPS, automated SMS OTP and 24x7 instant AI assistance.',
    seo_meta_keywords: 'tatkal software, irctc tatkal booking, low ping vps, tatkal guru, sms otp service',
    seo_google_analytics_id: '',
    seo_facebook_pixel_id: '',
    seo_canonical_url: 'https://tatkalguru.com',
    seo_robots_index: true,
    seo_open_graph_image: '',
    seo_twitter_handle: '@TatkalGuru',
    seo_structured_schema: true,
    seo_custom_header_scripts: '',
    seo_custom_footer_scripts: '',

    // 💾 Backup & Maintenance (12)
    maint_emergency_mode: false,
    maint_custom_message: 'System upgrade in progress. We will be back online in 10 minutes!',
    maint_bypass_ip: '',
    maint_auto_db_backup: true,
    maint_backup_retention: 30,
    maint_download_storage_json: true,
    maint_clear_order_cache: true,
    maint_vacuum_sqlite: true,
    maint_reset_demo_data: false,
    maint_error_logging_level: 'warn',
    maint_auto_restart_failed_services: true,
    maint_disk_quota_alert: 85,

    // 🤖 AI Engine & Model Tuning (11)
    ai_gemini_model: 'gemini-2.5-flash',
    ai_temperature: 0.4,
    ai_max_tokens: 1024,
    ai_rate_limit_user: 60,
    ai_tatkal_expert_persona: true,
    ai_auto_suggest_solutions: true,
    ai_language_auto_detect: true,
    ai_sentiment_routing: true,
    ai_log_conversations: true,
    ai_offline_fallback_msg: 'AI Support is currently busy. Please contact Admin via WhatsApp.',
    ai_greeting_welcome: 'Namaste! How can I assist you with Tatkal software or wallet recharge today?'
  };

  var CATEGORIES = [
    { id: 'all', name: 'All 102 Settings', icon: '⚡' },
    { id: 'sec', name: 'Security & Firewall (15)', icon: '🛡️' },
    { id: 'tatkal', name: 'Tatkal & Latency (12)', icon: '🚄' },
    { id: 'wallet', name: 'Wallet & Billing (14)', icon: '💰' },
    { id: 'tg', name: 'Telegram & Webhooks (12)', icon: '📢' },
    { id: 'ux', name: 'Customer UX & FX (14)', icon: '🎨' },
    { id: 'seo', name: 'SEO & Meta (12)', icon: '🔍' },
    { id: 'maint', name: 'Backup & Maintenance (12)', icon: '💾' },
    { id: 'ai', name: 'AI Engine Tuning (11)', icon: '🤖' }
  ];

  function getSettings() {
    try {
      var raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) return Object.assign({}, DEFAULT_SETTINGS, JSON.parse(raw));
    } catch (e) {}
    return Object.assign({}, DEFAULT_SETTINGS);
  }

  function saveSettings(s) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
      applyActiveEffects(s);
    } catch (e) {}
  }

  // Real effect applications in runtime
  function applyActiveEffects(s) {
    // 1. Right click disable
    if (s.sec_disable_right_click) {
      window.oncontextmenu = function (e) {
        if (!e.target.closest('#tg-admin-modal') && !e.target.closest('[class*="admin"]')) {
          e.preventDefault();
          return false;
        }
      };
    } else {
      window.oncontextmenu = null;
    }

    // 2. Sound Effects
    if (s.ux_click_sound_effects && !window.__tgAudioSetup) {
      window.__tgAudioSetup = true;
      document.addEventListener('click', function (e) {
        if (e.target.closest('button, a')) {
          try {
            var ctx = new (window.AudioContext || window.webkitAudioContext)();
            var osc = ctx.createOscillator();
            var gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(580, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(780, ctx.currentTime + 0.06);
            gain.gain.setValueAtTime(0.04, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.07);
          } catch (err) {}
        }
      });
    }

    // 3. Emergency maintenance mode
    if (s.maint_emergency_mode) {
      var isAdm = localStorage.getItem('sh_admin_auth') || localStorage.getItem('sh_admin_token');
      if (!isAdm && !document.getElementById('tg-emergency-overlay')) {
        var ov = document.createElement('div');
        ov.id = 'tg-emergency-overlay';
        ov.style.cssText = 'position:fixed;inset:0;background:#020617;z-index:9999999;display:flex;align-items:center;justify-content:center;color:#fff;padding:24px;text-align:center';
        ov.innerHTML = '<div><div style="font-size:48px;margin-bottom:16px">⚠️</div><h2 style="font-size:24px;font-weight:900;color:#f59e0b">' + (s.maint_custom_message || 'Maintenance Mode') + '</h2><p style="color:#94a3b8;margin-top:8px">Please check back shortly.</p></div>';
        document.body.appendChild(ov);
      }
    } else {
      var ov = document.getElementById('tg-emergency-overlay');
      if (ov) ov.remove();
    }
  }

  function renderAdminCard() {
    var host = document.querySelector('h3');
    var isPanel2 = false;
    var headings = document.querySelectorAll('h3, h4');
    for (var i = 0; i < headings.length; i++) {
      if (/ADMIN PANEL 2/i.test(headings[i].textContent || '')) {
        isPanel2 = true;
        break;
      }
    }
    if (!isPanel2) {
      var existing = document.getElementById('tg-adv-settings-container');
      if (existing) existing.remove();
      return;
    }

    // Check if Tab 9 or suitable container is active or append to panel
    if (document.getElementById('tg-adv-settings-container')) return;

    var panelContainer = document.querySelector('.bg-slate-900.text-white.rounded-3xl') || document.querySelector('[class*="bg-slate-900"]');
    if (!panelContainer) return;

    var card = document.createElement('div');
    card.id = 'tg-adv-settings-container';
    card.style.cssText = 'margin:16px;padding:20px;background:#020617;border:1px solid #3b82f6;border-radius:20px;box-shadow:0 10px 40px rgba(0,0,0,0.6);color:#fff';

    var currentSettings = getSettings();
    var currentCat = 'all';
    var searchQuery = '';

    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:10px">
        <div>
          <h3 style="font-size:18px;font-weight:900;color:#38bdf8;margin:0;display:flex;align-items:center;gap:8px">
            ⚡ Advanced System Control (100+ Functions)
          </h3>
          <p style="font-size:11px;color:#94a3b8;margin:4px 0 0 0">
            Enterprise Security, Tatkal Clock Sync, Wallet Guard, UX Sound Effects, Telegram Webhooks & AI Model Tuning
          </p>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <button id="tg-adv-export-btn" type="button" style="padding:6px 12px;background:#1e293b;border:1px solid #475569;border-radius:8px;color:#cbd5e1;font-size:11px;font-weight:bold;cursor:pointer">
            📥 Export JSON
          </button>
          <button id="tg-adv-reset-btn" type="button" style="padding:6px 12px;background:#7f1d1d;border:1px solid #b91c1c;border-radius:8px;color:#fecaca;font-size:11px;font-weight:bold;cursor:pointer">
            🔄 Reset Defaults
          </button>
          <button id="tg-adv-save-btn" type="button" style="padding:7px 18px;background:#0284c7;border:0;border-radius:8px;color:#fff;font-size:12px;font-weight:900;cursor:pointer;box-shadow:0 4px 12px rgba(2,132,199,0.4)">
            💾 Save All 102 Settings
          </button>
        </div>
      </div>

      <div style="display:flex;gap:10px;margin-bottom:14px;align-items:center">
        <input id="tg-adv-search" type="text" placeholder="🔍 Search through all 102 settings..." style="flex:1;padding:8px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#fff;font-size:12px">
        <span id="tg-adv-save-msg" style="font-size:11px;color:#34d399;font-weight:bold;min-width:120px"></span>
      </div>

      <div id="tg-adv-cats" style="display:flex;gap:6px;overflow-x:auto;padding-bottom:8px;margin-bottom:14px" class="scrollbar-none">
        ${CATEGORIES.map(function (c) {
          return `<button data-cat="${c.id}" type="button" style="padding:5px 10px;background:${c.id === 'all' ? '#2563eb' : '#0f172a'};border:1px solid #1e293b;border-radius:8px;color:#e2e8f0;font-size:11px;font-weight:bold;white-space:nowrap;cursor:pointer">${c.icon} ${c.name}</button>`;
        }).join('')}
      </div>

      <div id="tg-adv-grid" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(280px, 1fr));gap:10px;max-height:480px;overflow-y:auto;padding-right:4px">
      </div>
    `;

    var contentHost = panelContainer.querySelector('.p-6.overflow-y-auto') || panelContainer;
    contentHost.appendChild(card);

    function renderList() {
      var grid = card.querySelector('#tg-adv-grid');
      if (!grid) return;

      var keys = Object.keys(DEFAULT_SETTINGS);
      var filtered = keys.filter(function (k) {
        if (currentCat !== 'all' && !k.startsWith(currentCat + '_')) return false;
        if (searchQuery) {
          var clean = k.toLowerCase().replace(/_/g, ' ');
          if (clean.indexOf(searchQuery.toLowerCase()) === -1) return false;
        }
        return true;
      });

      if (!filtered.length) {
        grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:30px;color:#64748b;font-size:13px">No settings matched your search query.</div>';
        return;
      }

      grid.innerHTML = filtered.map(function (k) {
        var val = currentSettings[k];
        var isBool = typeof DEFAULT_SETTINGS[k] === 'boolean';
        var isNum = typeof DEFAULT_SETTINGS[k] === 'number';
        var label = k.replace(/^[a-z]+_/, '').replace(/_/g, ' ').replace(/\b\w/g, function (l) { return l.toUpperCase(); });

        return `
          <div style="padding:10px 12px;background:#0f172a;border:1px solid #1e293b;border-radius:10px;display:flex;justify-content:space-between;align-items:center;gap:8px">
            <div style="flex:1;min-width:0">
              <div style="font-size:11px;font-weight:bold;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${label}">
                ${label}
              </div>
              <div style="font-size:9px;color:#64748b;font-family:monospace">${k}</div>
            </div>
            <div>
              ${isBool ? `
                <input type="checkbox" data-key="${k}" ${val ? 'checked' : ''} style="width:18px;height:18px;accent-color:#0284c7;cursor:pointer">
              ` : (isNum ? `
                <input type="number" data-key="${k}" value="${val}" style="width:70px;padding:3px 6px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#fff;font-size:11px;text-align:right">
              ` : `
                <input type="text" data-key="${k}" value="${String(val || '').replace(/"/g, '&quot;')}" style="width:110px;padding:3px 6px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#fff;font-size:11px">
              `)}
            </div>
          </div>
        `;
      }).join('');

      grid.querySelectorAll('input').forEach(function (inp) {
        inp.onchange = function () {
          var k = inp.getAttribute('data-key');
          if (inp.type === 'checkbox') {
            currentSettings[k] = inp.checked;
          } else if (inp.type === 'number') {
            currentSettings[k] = Number(inp.value);
          } else {
            currentSettings[k] = inp.value;
          }
        };
      });
    }

    renderList();

    // Category Buttons
    card.querySelectorAll('#tg-adv-cats button').forEach(function (b) {
      b.onclick = function () {
        currentCat = b.getAttribute('data-cat');
        card.querySelectorAll('#tg-adv-cats button').forEach(function (btn) {
          btn.style.background = btn.getAttribute('data-cat') === currentCat ? '#2563eb' : '#0f172a';
        });
        renderList();
      };
    });

    // Search
    card.querySelector('#tg-adv-search').oninput = function (e) {
      searchQuery = e.target.value.trim();
      renderList();
    };

    // Save
    card.querySelector('#tg-adv-save-btn').onclick = function () {
      saveSettings(currentSettings);
      var msg = card.querySelector('#tg-adv-save-msg');
      msg.textContent = '✓ All 102 settings saved!';
      setTimeout(function () { msg.textContent = ''; }, 3500);
    };

    // Reset
    card.querySelector('#tg-adv-reset-btn').onclick = function () {
      if (confirm('Reset all 102 advanced settings to recommended defaults?')) {
        currentSettings = Object.assign({}, DEFAULT_SETTINGS);
        saveSettings(currentSettings);
        renderList();
      }
    };

    // Export
    card.querySelector('#tg-adv-export-btn').onclick = function () {
      var blob = new Blob([JSON.stringify(currentSettings, null, 2)], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'tatkal-guru-advanced-settings.json';
      a.click();
    };
  }

  // Hook on page transitions
  setInterval(renderAdminCard, 1000);
  applyActiveEffects(getSettings());
})();

/**
 * Tatkal Guru - Fast AI Support (3 Dedicated Support Engines)
 * 1. ⚡ Fast AI 1: Live General & Software Support
 * 2. 🚄 Fast AI 2: Tatkal Timing & Server Speed Expert
 * 3. 💳 Fast AI 3: Wallet, Cashback & OTP Billing Assistant
 */
(function () {
  'use strict';

  var isOpen = false;
  var isSending = false;
  var currentEngine = 'general'; // 'general' | 'tatkal' | 'billing'

  var engineConfigs = {
    general: {
      name: 'Fast AI 1',
      label: '⚡ Fast Live Support',
      tagline: 'Instant Assistance & Guidance',
      greeting: 'Namaste! Main **Tatkal Guru Fast AI 1** hoon. Tatkal software, VPS server setup, instant stock access aur portal guide me madad ke liye ready hoon!',
      chips: [
        { q: 'Tatkal booking timing kya hai?', text: '🚄 Tatkal Time' },
        { q: 'Tatkal ke liye best VPS kaun sa hai?', text: '💻 Best VPS' },
        { q: 'Wallet balance recharge kaise karein?', text: '💰 Add Wallet' },
        { q: 'SMS OTP service kaise use karein?', text: '📱 SMS OTP' }
      ]
    },
    tatkal: {
      name: 'Tatkal Expert',
      label: '🚄 Tatkal Speed Expert',
      tagline: '10 AM AC / 11 AM Sleeper Latency & Nodes',
      greeting: 'Namaste! Main **Tatkal Guru Speed Expert AI** hoon. AC Tatkal (10:00 AM IST) aur Sleeper Tatkal (11:00 AM IST) ke live server ping, low-latency nodes, captcha handling aur autofill timing tips me help karunga.',
      chips: [
        { q: 'AC Tatkal 10 AM ke liye best server settings kya hain?', text: '⚡ AC 10 AM Tips' },
        { q: 'Sleeper Tatkal 11 AM par low-ping VPS kaise select karein?', text: '🚄 Sleeper 11 AM' },
        { q: 'Browser autofill aur payment latency reduce kaise karein?', text: '🚀 Zero Latency' },
        { q: 'Tatkal software installation guide kya hai?', text: '⚙️ Setup Guide' }
      ]
    },
    billing: {
      name: 'Wallet & OTP',
      label: '💳 Wallet & OTP Assistant',
      tagline: 'UTR Approvals, Cashback & SMS Numbers',
      greeting: 'Namaste! Main **Tatkal Guru Wallet & OTP Assistant** hoon. UPI QR payment, UTR reference approval, Cashback campaigns aur IRCTC fast SMS OTP numbers me help karunga.',
      chips: [
        { q: 'UPI payment UTR verify kaise hota hai?', text: '💸 UTR Approval' },
        { q: 'Cashback coupon code wallet me kaise credit hota hai?', text: '🎁 Cashback Code' },
        { q: 'IRCTC SMS OTP number kaise purchase karein?', text: '📱 Buy SMS Number' },
        { q: 'Low wallet balance alert kya hai?', text: '💳 Wallet Recharge' }
      ]
    }
  };

  var chatHistories = {
    general: [
      {
        role: 'ai',
        text: engineConfigs.general.greeting,
        time: formatTime(new Date())
      }
    ],
    tatkal: [
      {
        role: 'ai',
        text: engineConfigs.tatkal.greeting,
        time: formatTime(new Date())
      }
    ],
    billing: [
      {
        role: 'ai',
        text: engineConfigs.billing.greeting,
        time: formatTime(new Date())
      }
    ]
  };

  function formatTime(d) {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderMarkdown(str) {
    var s = escHtml(str);
    s = s.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-white">$1</strong>');
    s = s.replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 bg-slate-800 text-amber-300 rounded font-mono text-xs">$1</code>');
    s = s.replace(/(?:^|\n)-\s+(.*?)(?=\n|$)/g, '<li class="ml-4 list-disc text-slate-300 my-1">$1</li>');
    s = s.replace(/(?:^|\n)(\d+)\.\s+(.*?)(?=\n|$)/g, '<li class="ml-4 list-decimal text-slate-300 my-1">$2</li>');
    s = s.replace(/\n/g, '<br/>');
    return s;
  }

  function fixStorageWhatsApp() {
    try {
      var tRaw = localStorage.getItem('sh_theme_settings');
      if (tRaw && tRaw.indexOf('91918900644148') >= 0) {
        var t = JSON.parse(tRaw);
        if (t.whatsappNumber === '91918900644148') t.whatsappNumber = '918900644148';
        if (t.popupBannerLink && t.popupBannerLink.indexOf('91918900644148') >= 0) {
          t.popupBannerLink = t.popupBannerLink.replace('91918900644148', '918900644148');
        }
        localStorage.setItem('sh_theme_settings', JSON.stringify(t));
      }
    } catch (e) {}
  }
  fixStorageWhatsApp();

  function toggleChat() {
    isOpen = !isOpen;
    var modal = document.getElementById('tg-gemini-chatbox');
    if (isOpen) {
      if (!modal) {
        createChatBox();
      } else {
        modal.style.display = 'flex';
      }
      scrollToBottom();
      var input = document.getElementById('tg-ai-input');
      if (input) setTimeout(function () { input.focus(); }, 150);
    } else {
      if (modal) modal.style.display = 'none';
    }
  }

  window.toggleFastSupport = toggleChat;
  window.toggleGeminiChat = toggleChat;
  window.addEventListener('toggle-fast-support', toggleChat);

  // Floating trigger button on bottom-right (alongside WhatsApp)
  function renderFloatingTrigger() {
    if (!document.getElementById('tg-fast-support-float-btn')) {
      var btn = document.createElement('button');
      btn.id = 'tg-fast-support-float-btn';
      btn.type = 'button';
      btn.title = 'Fast Support (3 AI Engines)';
      btn.style.cssText = 'position:fixed;bottom:156px;right:20px;z-index:9999999;pointer-events:auto !important;cursor:pointer !important;user-select:none;display:flex;align-items:center;gap:8px;padding:10px 16px;background:linear-gradient(135deg,#f59e0b,#ea580c);color:#000;border:0;border-radius:9999px;font-weight:900;font-size:12px;box-shadow:0 10px 30px rgba(245,158,11,0.6);cursor:pointer;transition:all 0.25s ease;border:1px solid #fef08a';
      btn.innerHTML = `
        <svg style="width:16px;height:16px;pointer-events:none" viewBox="0 0 24 24" fill="currentColor"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
        <span style="pointer-events:none">⚡ Fast Support</span>
        <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px #22c55e;pointer-events:none"></span>
      `;
      btn.onclick = function (e) {
        if (e) e.preventDefault();
        toggleChat();
      };
      btn.onpointerdown = function (e) {
        if (e) e.stopPropagation();
      };
      document.body.appendChild(btn);
    }
  }

  function createChatBox() {
    var box = document.createElement('div');
    box.id = 'tg-gemini-chatbox';
    box.className = 'fixed bottom-20 right-4 sm:bottom-24 sm:right-6 z-[999999] flex flex-col bg-slate-950 text-slate-100 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden';
    box.style.cssText = 'width: min(420px, calc(100vw - 32px)); height: min(580px, calc(100vh - 120px)); backdrop-filter: blur(16px);';

    box.innerHTML = `
      <!-- Header -->
      <div class="px-4 py-3 bg-gradient-to-r from-amber-600 via-orange-600 to-slate-950 border-b border-slate-800/80 flex items-center justify-between shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center shadow-md">
            <svg class="w-4 h-4 text-slate-950 font-black" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
            </svg>
          </div>
          <div>
            <div class="text-xs font-black tracking-wide text-white flex items-center gap-1.5" id="tg-ai-header-title">
              ⚡ Fast Support AI <span class="text-[10px] px-1.5 py-0.2 bg-amber-400/20 text-amber-300 rounded font-semibold border border-amber-400/30">24x7 Live</span>
            </div>
            <div class="text-[11px] text-emerald-300 flex items-center gap-1 font-medium" id="tg-ai-header-tagline">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Instant Assistance & Guidance
            </div>
          </div>
        </div>
        <div class="flex items-center gap-1">
          <button id="tg-ai-close-btn" type="button" class="text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer" title="Close">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>
      </div>

      <!-- 3-Engine Switcher Tabs -->
      <div class="p-1.5 bg-slate-900 border-b border-slate-800 flex items-center gap-1 shrink-0 text-[11px] font-bold">
        <button id="tg-tab-general" type="button" class="tg-eng-tab flex-1 py-1.5 px-2 rounded-lg text-center transition bg-amber-500 text-slate-950 shadow font-black" data-eng="general">
          ⚡ Fast Live AI
        </button>
        <button id="tg-tab-tatkal" type="button" class="tg-eng-tab flex-1 py-1.5 px-2 rounded-lg text-center transition text-slate-400 hover:text-white hover:bg-slate-800" data-eng="tatkal">
          🚄 Tatkal Speed
        </button>
        <button id="tg-tab-billing" type="button" class="tg-eng-tab flex-1 py-1.5 px-2 rounded-lg text-center transition text-slate-400 hover:text-white hover:bg-slate-800" data-eng="billing">
          💳 Wallet & OTP
        </button>
      </div>

      <!-- Quick Chips Bar -->
      <div id="tg-ai-chips-container" class="px-3 py-2 bg-slate-900/80 border-b border-slate-800/60 flex items-center gap-1.5 overflow-x-auto text-[11px] shrink-0 no-scrollbar">
      </div>

      <!-- Messages Stream -->
      <div id="tg-ai-messages" class="flex-1 p-3.5 overflow-y-auto space-y-3 text-xs leading-relaxed">
      </div>

      <!-- Input Bar -->
      <div class="p-3 bg-slate-900/90 border-t border-slate-800/80 shrink-0">
        <form id="tg-ai-form" class="flex items-center gap-2">
          <input
            id="tg-ai-input"
            type="text"
            autocomplete="off"
            placeholder="Type question for Fast AI Support..."
            class="flex-1 px-3.5 py-2.5 bg-slate-950 text-white text-xs rounded-xl border border-slate-800 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition placeholder:text-slate-500"
          />
          <button
            id="tg-ai-send-btn"
            type="submit"
            class="px-3.5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center transition shadow-md cursor-pointer shrink-0"
            title="Send"
          >
            <svg class="w-4 h-4 text-slate-950 transform rotate-45 -ml-0.5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
            </svg>
          </button>
        </form>
        <div class="mt-2 flex items-center justify-between text-[10px] text-slate-400">
          <span id="tg-ai-status-label">⚡ Fast AI 1 (Live Support)</span>
          <span class="flex items-center gap-1 text-emerald-400 font-semibold">● Online</span>
        </div>
      </div>
    `;

    document.body.appendChild(box);

    // Bind close
    document.getElementById('tg-ai-close-btn').onclick = toggleChat;

    // Switch engine tabs
    box.querySelectorAll('.tg-eng-tab').forEach(function (tab) {
      tab.onclick = function () {
        var eng = this.getAttribute('data-eng');
        switchEngine(eng);
      };
    });

    // Form submit
    document.getElementById('tg-ai-form').onsubmit = function (e) {
      e.preventDefault();
      var input = document.getElementById('tg-ai-input');
      var q = (input.value || '').trim();
      if (!q || isSending) return;
      input.value = '';
      submitQuery(q);
    };

    switchEngine('general');
  }

  function switchEngine(eng) {
    if (!engineConfigs[eng]) eng = 'general';
    currentEngine = eng;
    var conf = engineConfigs[eng];

    // Update Tab Styles
    document.querySelectorAll('.tg-eng-tab').forEach(function (tab) {
      var isCur = tab.getAttribute('data-eng') === eng;
      if (isCur) {
        tab.className = 'tg-eng-tab flex-1 py-1.5 px-2 rounded-lg text-center transition bg-amber-500 text-slate-950 shadow font-black';
      } else {
        tab.className = 'tg-eng-tab flex-1 py-1.5 px-2 rounded-lg text-center transition text-slate-400 hover:text-white hover:bg-slate-800 font-bold';
      }
    });

    // Update Header
    var title = document.getElementById('tg-ai-header-title');
    if (title) title.innerHTML = escHtml(conf.label) + ' <span class="text-[10px] px-1.5 py-0.2 bg-amber-400/20 text-amber-300 rounded font-semibold border border-amber-400/30">24x7</span>';
    var tagline = document.getElementById('tg-ai-header-tagline');
    if (tagline) tagline.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> ' + escHtml(conf.tagline);
    var statusLabel = document.getElementById('tg-ai-status-label');
    if (statusLabel) statusLabel.textContent = conf.label;

    // Render Chips
    var chipsBox = document.getElementById('tg-ai-chips-container');
    if (chipsBox) {
      chipsBox.innerHTML = conf.chips.map(function (c) {
        return `<button type="button" class="tg-chip px-2.5 py-1 rounded-full bg-slate-800 hover:bg-amber-600/30 text-slate-200 hover:text-amber-300 border border-slate-700/60 whitespace-nowrap transition cursor-pointer" data-q="${escHtml(c.q)}">${escHtml(c.text)}</button>`;
      }).join('');
      chipsBox.querySelectorAll('.tg-chip').forEach(function (chip) {
        chip.onclick = function () {
          var q = this.getAttribute('data-q');
          if (q) submitQuery(q);
        };
      });
    }

    renderMessages();
  }

  function renderMessages() {
    var container = document.getElementById('tg-ai-messages');
    if (!container) return;
    var history = chatHistories[currentEngine] || [];

    var html = '';
    history.forEach(function (msg) {
      if (msg.role === 'user') {
        html += `
          <div class="flex justify-end">
            <div class="max-w-[85%] bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl rounded-tr-sm px-3.5 py-2.5 shadow-md">
              <div>${escHtml(msg.text)}</div>
              <div class="text-[9px] text-blue-200/80 text-right mt-1">${msg.time}</div>
            </div>
          </div>
        `;
      } else {
        html += `
          <div class="flex items-start gap-2">
            <div class="w-6 h-6 rounded-md bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0 mt-0.5 text-amber-300">
              ⚡
            </div>
            <div class="max-w-[88%] bg-slate-900 border border-slate-800/80 rounded-2xl rounded-tl-sm px-3.5 py-2.5 shadow-md text-slate-200">
              <div class="markdown-body">${renderMarkdown(msg.text)}</div>
              <div class="text-[9px] text-slate-500 mt-1.5 flex items-center justify-between">
                <span>${msg.time}</span>
                <button type="button" class="text-slate-400 hover:text-amber-300 transition text-[10px] ml-2" onclick="navigator.clipboard && navigator.clipboard.writeText(${JSON.stringify(msg.text)})">Copy</button>
              </div>
            </div>
          </div>
        `;
      }
    });

    if (isSending) {
      html += `
        <div class="flex items-start gap-2" id="tg-ai-typing">
          <div class="w-6 h-6 rounded-md bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0 mt-0.5 text-amber-300">
            ⚡
          </div>
          <div class="bg-slate-900 border border-slate-800/80 rounded-2xl rounded-tl-sm px-4 py-3 shadow-md text-slate-400 flex items-center gap-1.5">
            <span class="w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce"></span>
            <span class="w-1.5 h-1.5 rounded-full bg-orange-400 animate-bounce [animation-delay:0.2s]"></span>
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.4s]"></span>
            <span class="text-[11px] text-slate-400 ml-1">Fast AI is answering...</span>
          </div>
        </div>
      `;
    }

    container.innerHTML = html;
    scrollToBottom();
  }

  function scrollToBottom() {
    var container = document.getElementById('tg-ai-messages');
    if (container) {
      setTimeout(function () {
        container.scrollTop = container.scrollHeight;
      }, 50);
    }
  }

  function submitQuery(prompt) {
    if (!prompt || isSending) return;

    var history = chatHistories[currentEngine] || (chatHistories[currentEngine] = []);
    history.push({
      role: 'user',
      text: prompt,
      time: formatTime(new Date())
    });

    isSending = true;
    renderMessages();

    fetch('./api/gemini.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'ask',
        prompt: prompt,
        engine: currentEngine
      })
    })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (res) {
        var reply = res.answer || res.message || 'Maaf kijiye, abhi response generate nahi ho saka.';
        history.push({
          role: 'ai',
          text: reply,
          time: formatTime(new Date())
        });
      })
      .catch(function () {
        history.push({
          role: 'ai',
          text: 'Network issue ya AI server busy hai. Kripya thodi der baad dobara prashn poochein.',
          time: formatTime(new Date())
        });
      })
      .finally(function () {
        isSending = false;
        renderMessages();
      });
  }

  function checkTrigger() {
    renderFloatingTrigger();
  }

  setInterval(checkTrigger, 1500);
  setTimeout(checkTrigger, 500);
})();

<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/dbcon.php';

function respond(bool $ok, string $message, array $extra=[]): void {
    echo json_encode(array_merge(['ok'=>$ok,'message'=>$message], $extra), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function storage(PDO $pdo): array {
    $stmt = $pdo->query("SELECT storage_key, storage_value FROM app_storage");
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $items[(string)$row['storage_key']] = ['value' => (string)$row['storage_value']];
    }
    return $items;
}
function item(array $items, string $key, $default=null) {
    if (!isset($items[$key]['value'])) return $default;
    $v = json_decode((string)$items[$key]['value'], true);
    return $v === null && trim((string)$items[$key]['value']) !== 'null' ? $default : $v;
}
function users(array $items): array { $v=item($items,'sh_users',[]); return is_array($v)?$v:[]; }
function settings(array $items): array {
    $v=item($items,'sh_api_settings',[]);
    return is_array($v)?$v:[];
}
function smtpRead($fp): string {
    $line = '';
    while (($l = fgets($fp, 8192)) !== false) {
        $line .= $l;
        if (strlen($l) < 4 || $l[3] !== '-') break;
    }
    return trim($line);
}
function smtpCmd($fp, string $cmd, array $codes): string {
    fwrite($fp, $cmd . "\r\n");
    $resp = smtpRead($fp);
    $code = (int)substr($resp,0,3);
    if (!in_array($code,$codes,true)) throw new RuntimeException("SMTP error: ".$resp);
    return $resp;
}
function mimeHeader(string $s): string {
    return function_exists('mb_encode_mimeheader') ? mb_encode_mimeheader($s,'UTF-8') : '=?UTF-8?B?'.base64_encode($s).'?=';
}
function sendSmtp(array $cfg, string $to, string $subject, string $html, string $text=''): void {
    $host = trim((string)($cfg['smtpHost'] ?? ''));
    $port = (int)($cfg['smtpPort'] ?? 587);
    $user = trim((string)($cfg['smtpUser'] ?? ''));
    $pass = (string)($cfg['smtpPass'] ?? '');
    $from = trim((string)($cfg['senderEmail'] ?? $user));
    $name = trim((string)($cfg['senderName'] ?? 'Tatkal Guru'));
    $enc = strtolower(trim((string)($cfg['encryption'] ?? 'TLS')));
    if ($host==='' || $user==='' || $pass==='' || $from==='') throw new RuntimeException('SMTP settings are incomplete.');

    $transport = ($enc==='ssl' || $port===465) ? 'ssl://' : '';
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ]
    ]);
    $fp = @stream_socket_client($transport.$host.':'.$port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $context);
    if (!$fp) throw new RuntimeException("SMTP connection failed: $errstr ($errno)");
    stream_set_timeout($fp, 15);
    $hello = smtpRead($fp);
    if ((int)substr($hello,0,3) >= 400) throw new RuntimeException('SMTP greeting failed.');

    smtpCmd($fp, 'EHLO tatkalguru.com', [250]);
    if ($enc==='tls' && $port!==465) {
        smtpCmd($fp, 'STARTTLS', [220]);
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($fp); throw new RuntimeException('STARTTLS negotiation failed.');
        }
        smtpCmd($fp, 'EHLO tatkalguru.com', [250]);
    }
    // cPanel/Exim commonly advertises AUTH LOGIN and/or AUTH PLAIN.
    $authOk=false;
    try {
        smtpCmd($fp, 'AUTH LOGIN', [334]);
        smtpCmd($fp, base64_encode($user), [334]);
        smtpCmd($fp, base64_encode($pass), [235]);
        $authOk=true;
    } catch (Throwable $authLoginError) {
        try {
            smtpCmd($fp, 'AUTH PLAIN '.base64_encode("\0".$user."\0".$pass), [235]);
            $authOk=true;
        } catch (Throwable $authPlainError) {
            fclose($fp);
            throw new RuntimeException('SMTP authentication failed. Check the mailbox username/password.');
        }
    }
    if (!$authOk) throw new RuntimeException('SMTP authentication failed.');
    smtpCmd($fp, 'MAIL FROM:<'.$from.'>', [250]);
    smtpCmd($fp, 'RCPT TO:<'.$to.'>', [250,251]);
    smtpCmd($fp, 'DATA', [354]);

    $boundary = '=_TG_'.bin2hex(random_bytes(8));
    $headers = [
        'From: '.mimeHeader($name).' <'.$from.'>',
        'To: <'.$to.'>',
        'Subject: '.mimeHeader($subject),
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="'.$boundary.'"',
        'Date: '.date(DATE_RFC2822)
    ];
    $text = $text !== '' ? $text : trim(strip_tags(str_replace(['<br>','</p>','</div>'], "\n", $html)));
    $msg = implode("\r\n",$headers)."\r\n\r\n";
    $msg .= "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$text."\r\n\r\n";
    $msg .= "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$html."\r\n\r\n";
    $msg .= "--$boundary--\r\n.";
    smtpCmd($fp, $msg, [250]);
    @smtpCmd($fp, 'QUIT', [221]);
    fclose($fp);
}

$in = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($in)) respond(false,'Invalid request.');

$pdo = db();
$items=storage($pdo); $cfg=settings($items);
$mailCfg=$cfg['mailSettings'] ?? [];
if (!is_array($mailCfg)) $mailCfg=[];
// SINGLE SOURCE OF TRUTH: Admin Panel > APIs & Payment Config > SMTP Mail Setup.
// No second/fallback SMTP credentials are used here.
$mailDefaults=[
    'enabled'=>false,
    'smtpHost'=>'',
    'smtpPort'=>465,
    'smtpUser'=>'',
    'smtpPass'=>'',
    'senderName'=>'Tatkal Guru',
    'senderEmail'=>'',
    'encryption'=>'SSL',
    'sendOrderEmail'=>true,
    'sendPasswordResetEmail'=>true
];
$mailCfg=array_replace($mailDefaults,$mailCfg);
if (empty($mailCfg['enabled'])) respond(false,'Email service is disabled in Admin API settings. Configure SMTP Mail Setup first.');

$action=(string)($in['action'] ?? '');
$allUsers=users($items);

if ($action==='order') {
    $to=filter_var((string)($in['to'] ?? ''), FILTER_VALIDATE_EMAIL);
    $order=is_array($in['order'] ?? null)?$in['order']:[];
    if (!$to || !$order) respond(false,'Invalid order email data.');
    $allowed=false;
    foreach($allUsers as $u){ if (strcasecmp((string)($u['email']??''),$to)===0) {$allowed=true;break;} }
    if(!$allowed) respond(false,'Recipient is not a registered account.');

    $brand=htmlspecialchars((string)($mailCfg['senderName']??'Tatkal Guru'),ENT_QUOTES,'UTF-8');
    $id=htmlspecialchars((string)($order['id']??''),ENT_QUOTES,'UTF-8');
    $product=htmlspecialchars((string)($order['productName']??$order['productId']??''),ENT_QUOTES,'UTF-8');
    $amount=htmlspecialchars((string)($order['totalAmount']??'0'),ENT_QUOTES,'UTF-8');
    $qty=htmlspecialchars((string)($order['quantity']??1),ENT_QUOTES,'UTF-8');
    $unit=htmlspecialchars((string)($order['unitPrice']??''),ENT_QUOTES,'UTF-8');
    $discount=htmlspecialchars((string)($order['discountApplied']??0),ENT_QUOTES,'UTF-8');
    $bonus=htmlspecialchars((string)($order['bonusUsed']??0),ENT_QUOTES,'UTF-8');
    $coupon=htmlspecialchars((string)($order['couponCode']??''),ENT_QUOTES,'UTF-8');
    $payment=htmlspecialchars((string)($order['paymentMethod']??'Wallet'),ENT_QUOTES,'UTF-8');
    $status=htmlspecialchars((string)($order['status']??'Delivered'),ENT_QUOTES,'UTF-8');
    $created=htmlspecialchars((string)($order['createdAt']??date(DATE_ATOM)),ENT_QUOTES,'UTF-8');
    $userEmail=htmlspecialchars((string)($order['userEmail']??$to),ENT_QUOTES,'UTF-8');
    $userMobile=htmlspecialchars((string)($order['userMobile']??''),ENT_QUOTES,'UTF-8');
    $dataRaw=(string)($order['deliveredData']??'');
    $data=nl2br(htmlspecialchars($dataRaw,ENT_QUOTES,'UTF-8'));
    $scheme=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off' ? 'https' : 'http';
    $host=(string)($_SERVER['HTTP_HOST']??'tatkalguru.com');
    $site=rtrim($scheme.'://'.$host,'/');
    $siteLink=htmlspecialchars($site,ENT_QUOTES,'UTF-8');
    $orderLink=htmlspecialchars($site.'/#dashboard',ENT_QUOTES,'UTF-8');
    $couponRow=$coupon!==''?'<tr><td><b>Coupon</b></td><td>'.$coupon.'</td></tr>':'';
    $html="<div style=\"font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033\">"
      ."<div style=\"background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0\"><h2 style=\"margin:0\">$brand</h2><div style=\"margin-top:5px;opacity:.9\">Order Confirmation</div></div>"
      ."<div style=\"padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px\">"
      ."<p>Thank you. Your order has been placed successfully.</p>"
      ."<table cellpadding=\"8\" style=\"border-collapse:collapse;width:100%;font-size:14px\">"
      ."<tr><td><b>Order ID</b></td><td>$id</td></tr><tr><td><b>Customer Email</b></td><td>$userEmail</td></tr><tr><td><b>Mobile</b></td><td>$userMobile</td></tr><tr><td><b>Product</b></td><td>$product</td></tr><tr><td><b>Quantity</b></td><td>$qty</td></tr><tr><td><b>Unit Price</b></td><td>₹$unit</td></tr><tr><td><b>Discount</b></td><td>₹$discount</td></tr><tr><td><b>Bonus Used</b></td><td>₹$bonus</td></tr>$couponRow<tr><td><b>Payment Method</b></td><td>$payment</td></tr><tr><td><b>Status</b></td><td>$status</td></tr><tr><td><b>Total Paid</b></td><td><strong>₹$amount</strong></td></tr><tr><td><b>Order Time</b></td><td>$created</td></tr></table>"
      ."<h3 style=\"margin-top:22px\">Delivered / Order Data</h3><div style=\"background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word\">$data</div>"
      ."<p style=\"margin-top:22px\"><a href=\"$orderLink\" style=\"display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:11px 16px;border-radius:8px;font-weight:bold\">Open Tatkal Guru Website / Orders</a></p>"
      ."<p style=\"font-size:12px;color:#64748b\">Website: <a href=\"$siteLink\">$siteLink</a></p></div></div>";
    $text="Order Confirmation\nOrder ID: $id\nCustomer Email: $userEmail\nMobile: $userMobile\nProduct: $product\nQuantity: $qty\nUnit Price: ₹$unit\nDiscount: ₹$discount\nBonus Used: ₹$bonus\nPayment Method: $payment\nStatus: $status\nTotal Paid: ₹$amount\nOrder Time: $created\n\nDelivered / Order Data:\n$dataRaw\n\nWebsite: $site\nOrders: $site/#dashboard";
    try { sendSmtp($mailCfg,$to,'Order Confirmation - '.$id,$html,$text); respond(true,'Order confirmation email sent with complete order details and website link.'); }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

if ($action==='custom') {
    $to=filter_var((string)($in['to'] ?? ''), FILTER_VALIDATE_EMAIL);
    $subject=trim((string)($in['subject'] ?? 'Message from Tatkal Guru'));
    $message=(string)($in['message'] ?? '');
    if (!$to) respond(false,'Invalid recipient email.');
    if ($subject==='') $subject='Message from Tatkal Guru';
    if (trim($message)==='') respond(false,'Message cannot be empty.');
    $allowed=false;
    foreach($allUsers as $u){ if (strcasecmp((string)($u['email']??''),$to)===0) {$allowed=true;break;} }
    if(!$allowed) respond(false,'Recipient is not a registered account.');
    $brand=htmlspecialchars((string)($mailCfg['senderName']??'Tatkal Guru'),ENT_QUOTES,'UTF-8');
    $safeSubject=htmlspecialchars($subject,ENT_QUOTES,'UTF-8');
    $safeMessage=nl2br(htmlspecialchars($message,ENT_QUOTES,'UTF-8'));
    $html="<div style=\"font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033\"><div style=\"background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0\"><h2 style=\"margin:0\">$brand</h2></div><div style=\"padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px\"><h3>$safeSubject</h3><div style=\"line-height:1.7\">$safeMessage</div><p style=\"margin-top:22px;font-size:12px;color:#64748b\">$brand — $site</p></div></div>";
    $text=$message."\n\n$brand — $site";
    try { sendSmtp($mailCfg,$to,$subject,$html,$text); respond(true,'Custom email sent successfully.'); }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

if ($action==='password_reset') {
    $identifier=strtolower(trim((string)($in['identifier'] ?? '')));
    $found=null;
    foreach($allUsers as $u){
        $email=strtolower((string)($u['email']??''));
        $mobile=(string)($u['mobile']??'');
        if($identifier!=='' && ($identifier===$email || ($mobile!=='' && strpos($mobile,$identifier)!==false))) {$found=$u;break;}
    }
    if(!$found || !filter_var((string)$found['email'],FILTER_VALIDATE_EMAIL)) respond(false,'No registered email account found.');
    $otp=(string)random_int(100000,999999);
    $otpFile=__DIR__.'/../data/mail_otps.json';
    $db=json_decode(@file_get_contents($otpFile) ?: '',true); if(!is_array($db))$db=[];
    $db[(string)$found['id']]=['otp'=>$otp,'expires'=>time()+600,'email'=>$found['email']];
    @file_put_contents($otpFile,json_encode($db,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);
    $brand=htmlspecialchars((string)($mailCfg['senderName']??'Tatkal Guru'),ENT_QUOTES,'UTF-8');
    $html="<div style=\"font-family:Arial,sans-serif;max-width:600px;margin:auto\"><h2 style=\"color:#0d2b52\">$brand</h2><p>Your password recovery OTP is:</p><div style=\"font-size:30px;font-weight:bold;letter-spacing:8px;color:#0d2b52\">$otp</div><p>This OTP expires in 10 minutes.</p></div>";
    try { sendSmtp($mailCfg,(string)$found['email'],'Password Reset OTP',$html,"Your password reset OTP is $otp. It expires in 10 minutes."); respond(true,'OTP sent successfully to your registered email.', ['otp'=>$otp,'email'=>$found['email']]); }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

if ($action==='test') {
    $to=filter_var((string)($in['to'] ?? ''), FILTER_VALIDATE_EMAIL);
    if(!$to) respond(false,'Enter a valid test email.');
    try { sendSmtp($mailCfg,$to,'Tatkal Guru SMTP Test','<h2>SMTP test successful</h2><p>Your Tatkal Guru mail settings are working.</p>'); respond(true,'Test email sent.'); }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

respond(false,'Unknown email action.');
?>

<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__.'/dbcon.php';
try {
    $pdo = db();
    $count = (int)$pdo->query('SELECT COUNT(*) FROM app_storage')->fetchColumn();
    echo json_encode(['ok'=>true,'database'=>DB_NAME,'user'=>DB_USER,'host'=>DB_HOST,'table'=>'app_storage','rows'=>$count], JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'database'=>DB_NAME,'user'=>DB_USER,'host'=>DB_HOST,'error'=>$e->getMessage()], JSON_UNESCAPED_SLASHES);
}

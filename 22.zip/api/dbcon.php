<?php
declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_NAME = 'tatkalguru';
const DB_USER = 'tatkalguru';
const DB_PASS = 'Rumi@@@1624';
const DB_CHARSET = 'utf8mb4';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 10,
    ]);

    // Make deployment easier: create the required table automatically if it does not exist.
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_storage (
        storage_key VARCHAR(190) NOT NULL,
        storage_value LONGTEXT NOT NULL,
        updated_at_ms BIGINT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (storage_key),
        KEY idx_updated_at (updated_at_ms)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    return $pdo;
}

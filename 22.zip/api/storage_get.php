<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__.'/dbcon.php';
try {
    $pdo=db();
    $rows=$pdo->query('SELECT storage_key, storage_value, updated_at_ms FROM app_storage ORDER BY storage_key')->fetchAll();
    $items=[]; $updated=0;
    foreach($rows as $r){ $items[$r['storage_key']]=['value'=>$r['storage_value'],'updatedAt'=>(int)$r['updated_at_ms']]; $updated=max($updated,(int)$r['updated_at_ms']); }
    echo json_encode(['ok'=>true,'version'=>4,'updatedAt'=>$updated,'items'=>$items],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
} catch(Throwable $e){
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Database unavailable. Check MySQL database/user privileges.']);
}

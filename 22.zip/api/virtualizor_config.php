<?php
declare(strict_types=1);

/*
 * Virtualizor credentials are SERVER-SIDE ONLY.
 * Do not print or return these values to the browser.
 *
 * If sh_api_settings exists in MySQL, vps.php uses those values first.
 */
const VIRTUALIZOR_HOST = '161.248.163.31';
const VIRTUALIZOR_API_KEY = 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM';
const VIRTUALIZOR_API_PASS = 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n';
const VIRTUALIZOR_PORT = 4085;
const VIRTUALIZOR_VIRT = 'kvm';
const VIRTUALIZOR_DEFAULT_BANDWIDTH = 0;
const VIRTUALIZOR_DEFAULT_NODE_SELECT = 0;
const VIRTUALIZOR_DEFAULT_NUM_IPS = 1;
const VIRTUALIZOR_DEFAULT_SWAP_MB = 0;
const VIRTUALIZOR_DEFAULT_CPU_WEIGHT = 1000;
const VIRTUALIZOR_DEFAULT_CPU_PERCENT = 100;
const VIRTUALIZOR_DEFAULT_VNC = 1;
const VIRTUALIZOR_DEFAULT_OSID = 0; // 0 = auto-detect from requested OS/template

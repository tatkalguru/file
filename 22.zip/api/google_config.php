<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
// Public OAuth client ID. Replace GOOGLE_CLIENT_ID below or set the environment variable
// GOOGLE_CLIENT_ID on the server. The client ID is not a secret.
$clientId = trim((string)(getenv('GOOGLE_CLIENT_ID') ?: '1039465802455-mjbd4moe04j5bjn8bkrhpmkmvfik24tj.apps.googleusercontent.com'));
echo json_encode(['ok'=>true,'clientId'=>$clientId], JSON_UNESCAPED_SLASHES);

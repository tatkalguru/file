<?php
declare(strict_types=1);
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__.'/dbcon.php';
try {
 $rows=db()->query('SELECT storage_key, storage_value, updated_at_ms FROM app_storage')->fetchAll();
 $items=[]; foreach($rows as $r){
  // Never bootstrap authentication/session data. These keys are device/session specific.
  if (in_array($r['storage_key'], ['sh_current_user','sh_admin_session','sh_admin_security'], true)) continue;
  $items[$r['storage_key']]=['value'=>$r['storage_value'],'updatedAt'=>(int)$r['updated_at_ms']];
}
 echo '(function(){try{var d='.json_encode($items,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE).';var m={};try{m=JSON.parse(localStorage.getItem("sh_sync_meta")||"{}")}catch(e){};Object.keys(d).forEach(function(k){var r=d[k];if(!r||typeof r!=="object")return;var st=Number(r.updatedAt||0),lt=Number(m[k]||0);if(localStorage.getItem(k)===null||st>lt){localStorage.setItem(k,String(r.value==null?"":r.value));m[k]=st;}});localStorage.setItem("sh_sync_meta",JSON.stringify(m));}catch(e){console.error("DB bootstrap failed",e);}})();';
} catch(Throwable $e){ echo '/* DB bootstrap unavailable */'; }

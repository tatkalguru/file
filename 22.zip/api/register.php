<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'ok'=>false,'message'=>'POST required']);
    exit;
}
require_once __DIR__.'/dbcon.php';

$raw = file_get_contents('php://input') ?: '';
$in = json_decode($raw, true);
if (!is_array($in)) $in = $_POST;

$name = trim((string)($in['fullName'] ?? $in['name'] ?? ''));
$email = strtolower(trim((string)($in['email'] ?? '')));
$mobile = preg_replace('/\D+/', '', (string)($in['mobile'] ?? $in['phone'] ?? ''));
$password = (string)($in['password'] ?? '');

if ($name === '' || $email === '' || $mobile === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['success'=>false,'ok'=>false,'message'=>'All registration fields are required']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success'=>false,'ok'=>false,'message'=>'Invalid email address']);
    exit;
}
if (strlen($mobile) > 10) $mobile = substr($mobile, -10);
if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    http_response_code(400);
    echo json_encode(['success'=>false,'ok'=>false,'message'=>'Mobile number must be exactly 10 digits']);
    exit;
}

try {
    $pdo = db();
    $pdo->beginTransaction();
    $q = $pdo->prepare('SELECT storage_value, updated_at_ms FROM app_storage WHERE storage_key=? FOR UPDATE');
    $q->execute(['sh_users']);
    $row = $q->fetch();
    $users = $row ? json_decode((string)$row['storage_value'], true) : [];
    if (!is_array($users)) $users = [];

    foreach ($users as $u) {
        if (!is_array($u)) continue;
        if (strtolower((string)($u['email'] ?? '')) === $email || (string)($u['mobile'] ?? '') === $mobile) {
            $pdo->rollBack();
            http_response_code(409);
            echo json_encode(['success'=>false,'ok'=>false,'message'=>'An account with this Email or Mobile already exists']);
            exit;
        }
    }

    $settings = [];
    $q->execute(['sh_api_settings']);
    $cfg = $q->fetch();
    if ($cfg) {
        $settings = json_decode((string)$cfg['storage_value'], true);
        if (!is_array($settings)) $settings = [];
    }
    $bonusCfg = is_array($settings['registrationBonusSettings'] ?? null) ? $settings['registrationBonusSettings'] : [];
    $bonusEnabled = array_key_exists('enabled', $bonusCfg) ? (bool)$bonusCfg['enabled'] : true;
    $bonus = $bonusEnabled ? max(0, (float)($bonusCfg['amount'] ?? 2500)) : 0;

    $nowMs = (int)round(microtime(true) * 1000);
    $user = [
        'id' => 'usr_'.$nowMs.'_'.bin2hex(random_bytes(3)),
        'fullName' => $name,
        'email' => $email,
        'mobile' => $mobile,
        'password' => $password,
        'walletBalance' => 0,
        // Registration welcome amount is bonus-only. It must never be added to the wallet.
        'bonusBalance' => $bonus,
        'role' => 'user',
        'status' => 'active',
        'createdAt' => gmdate('c')
    ];
    array_unshift($users, $user);
    $payload = json_encode($users, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    $stmt = $pdo->prepare('INSERT INTO app_storage (storage_key,storage_value,updated_at_ms) VALUES (?,?,?) ON DUPLICATE KEY UPDATE storage_value=VALUES(storage_value), updated_at_ms=VALUES(updated_at_ms)');
    $stmt->execute(['sh_users', $payload, $nowMs]);
    $pdo->commit();

    // Centralized 4-channel registration notification. Failures must never roll back a successful signup.
    try {
        $payload = [
            'user' => ['id'=>$user['id'],'fullName'=>$user['fullName'],'email'=>$user['email'],'mobile'=>$user['mobile']],
            'item' => ['id'=>$user['id']],
            'message' => 'Registration successful. Welcome to Tatkal Guru.'
        ];
        $ch = curl_init();
        curl_setopt_array($ch, [CURLOPT_URL => (($_SERVER['HTTPS'] ?? '') === 'on' ? 'https' : 'http').'://'.($_SERVER['HTTP_HOST'] ?? 'localhost').rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/api/register.php'),'/').'/notify.php', CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>json_encode(['action'=>'send','type'=>'registration','payload'=>$payload],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), CURLOPT_HTTPHEADER=>['Content-Type: application/json'], CURLOPT_CONNECTTIMEOUT=>3, CURLOPT_TIMEOUT=>8]);
        @curl_exec($ch); @curl_close($ch);
    } catch (Throwable $notificationError) { /* registration remains successful */ }

    echo json_encode(['success'=>true,'ok'=>true,'message'=>$bonus>0 ? 'Account created successfully! ₹'.$bonus.' Welcome Bonus credited.' : 'Account created successfully!','user'=>$user], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success'=>false,'ok'=>false,'message'=>'Registration server error. Check database configuration.']);
}

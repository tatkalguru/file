<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__.'/dbcon.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'error'=>'POST required']); exit; }
$raw = file_get_contents('php://input') ?: '';
$in = json_decode($raw, true);
if (!is_array($in) || !isset($in['items']) || !is_array($in['items'])) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid payload']); exit; }

try {
    $pdo = db();
    $pdo->beginTransaction();
    $stmt = $pdo->prepare('INSERT INTO app_storage (storage_key, storage_value, updated_at_ms) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE storage_value=IF(VALUES(updated_at_ms) >= updated_at_ms, VALUES(storage_value), storage_value), updated_at_ms=GREATEST(updated_at_ms, VALUES(updated_at_ms))');
    $accepted=0;
    $now=(int)round(microtime(true)*1000);
    foreach ($in['items'] as $k=>$r) {
        // Authentication/session keys must never be shared through global application storage.
        if (!is_string($k) || strpos($k,'sh_')!==0 || in_array($k, ['sh_sync_meta','sh_current_user','sh_admin_session','sh_admin_security'], true) || !is_array($r)) continue;
        $v=isset($r['value']) ? (string)$r['value'] : '';
        if (strlen($v)>5*1024*1024) continue;
        $ts=(int)($r['updatedAt']??$now); if($ts<=0)$ts=$now;
        $stmt->execute([$k,$v,$ts]); $accepted++;
    }
    $pdo->commit();
    echo json_encode(['ok'=>true,'accepted'=>$accepted,'updatedAt'=>$now],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'Database unavailable. Check MySQL database/user privileges.']);
}

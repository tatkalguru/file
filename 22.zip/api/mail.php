<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/dbcon.php';

function respond(bool $ok, string $message, array $extra=[]): void {
    echo json_encode(array_merge(['ok'=>$ok,'message'=>$message], $extra), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function storage(PDO $pdo): array {
    $stmt = $pdo->query("SELECT storage_key, storage_value FROM app_storage");
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $items[(string)$row['storage_key']] = ['value' => (string)$row['storage_value']];
    }
    return $items;
}
function item(array $items, string $key, $default=null) {
    if (!isset($items[$key]['value'])) return $default;
    $v = json_decode((string)$items[$key]['value'], true);
    return $v === null && trim((string)$items[$key]['value']) !== 'null' ? $default : $v;
}
function users(array $items): array { $v=item($items,'sh_users',[]); return is_array($v)?$v:[]; }
function settings(array $items): array {
    $v=item($items,'sh_api_settings',[]);
    return is_array($v)?$v:[];
}
function smtpRead($fp): string {
    $line = '';
    while (($l = fgets($fp, 8192)) !== false) {
        $line .= $l;
        if (strlen($l) < 4 || $l[3] !== '-') break;
    }
    return trim($line);
}
function smtpCmd($fp, string $cmd, array $codes): string {
    fwrite($fp, $cmd . "\r\n");
    $resp = smtpRead($fp);
    $code = (int)substr($resp,0,3);
    if (!in_array($code,$codes,true)) throw new RuntimeException("SMTP error: ".$resp);
    return $resp;
}
function mimeHeader(string $s): string {
    return function_exists('mb_encode_mimeheader') ? mb_encode_mimeheader($s,'UTF-8') : '=?UTF-8?B?'.base64_encode($s).'?=';
}
function sendLocalMail(string $to, string $subject, string $html, string $text=''): void {
    $to = trim($to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Invalid recipient email.');
    $from = 'info@tatkalguru.com';
    $text = $text !== '' ? $text : trim(strip_tags(str_replace(['<br>','</p>','</div>'], "\n", $html)));
    $boundary = '=_TG_LOCAL_'.bin2hex(random_bytes(8));
    $headers = "From: Tatkal Guru <{$from}>\r\n"
        . "Reply-To: {$from}\r\n"
        . "MIME-Version: 1.0\r\n"
        . "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n"
        . "X-Mailer: Tatkal-Guru-Mailer\r\n";
    $body = "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$text}\r\n\r\n"
        . "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$html}\r\n\r\n"
        . "--{$boundary}--\r\n";

    // First use the hosting server's local MTA (normally Exim on cPanel).
    if (function_exists('mail')) {
        $ok = @mail($to, mimeHeader($subject), $body, $headers, '-f'.$from);
        if (!$ok) $ok = @mail($to, mimeHeader($subject), $body, $headers);
        if ($ok) return;
    }

    // Last-resort local sendmail binary, if PHP mail() is disabled.
    $sendmail = '/usr/sbin/sendmail';
    if (is_executable($sendmail) && function_exists('proc_open')) {
        $cmd = [$sendmail, '-t', '-i', '-f', $from];
        $proc = @proc_open($cmd, [0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']], $pipes);
        if (is_resource($proc)) {
            $raw = "To: {$to}\r\nSubject: ".mimeHeader($subject)."\r\n{$headers}\r\n{$body}";
            fwrite($pipes[0], $raw); fclose($pipes[0]);
            stream_get_contents($pipes[1]); fclose($pipes[1]);
            $err = stream_get_contents($pipes[2]); fclose($pipes[2]);
            $code = proc_close($proc);
            if ($code === 0) return;
            if ($err !== '') throw new RuntimeException('Local mail transport failed: '.trim($err));
        }
    }
    throw new RuntimeException('SMTP failed and the server local mail transport is unavailable.');
}

function sendMailWithFallback(array $cfg, string $to, string $subject, string $html, string $text=''): string {
    try {
        sendSmtp($cfg, $to, $subject, $html, $text);
        return 'smtp';
    } catch (Throwable $smtpError) {
        sendLocalMail($to, $subject, $html, $text);
        return 'local';
    }
}

function sendSmtp(array $cfg, string $to, string $subject, string $html, string $text=''): void {
    $host = trim((string)($cfg['smtpHost'] ?? ''));
    $port = (int)($cfg['smtpPort'] ?? 587);
    $user = trim((string)($cfg['smtpUser'] ?? ''));
    $pass = (string)($cfg['smtpPass'] ?? '');
    $from = trim((string)($cfg['senderEmail'] ?? $user));
    $name = trim((string)($cfg['senderName'] ?? 'Tatkal Guru'));
    $enc = strtolower(trim((string)($cfg['encryption'] ?? 'TLS')));
    if ($host==='' || $user==='' || $pass==='' || $from==='') throw new RuntimeException('SMTP settings are incomplete.');

    $transport = ($enc==='ssl' || $port===465) ? 'ssl://' : '';
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ]
    ]);
    $fp = @stream_socket_client($transport.$host.':'.$port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $context);
    if (!$fp) throw new RuntimeException("SMTP connection failed: $errstr ($errno)");
    stream_set_timeout($fp, 15);
    $hello = smtpRead($fp);
    if ((int)substr($hello,0,3) >= 400) throw new RuntimeException('SMTP greeting failed.');

    smtpCmd($fp, 'EHLO tatkalguru.com', [250]);
    if ($enc==='tls' && $port!==465) {
        smtpCmd($fp, 'STARTTLS', [220]);
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($fp); throw new RuntimeException('STARTTLS negotiation failed.');
        }
        smtpCmd($fp, 'EHLO tatkalguru.com', [250]);
    }
    // cPanel/Exim commonly advertises AUTH LOGIN and/or AUTH PLAIN.
    $authOk=false;
    try {
        smtpCmd($fp, 'AUTH LOGIN', [334]);
        smtpCmd($fp, base64_encode($user), [334]);
        smtpCmd($fp, base64_encode($pass), [235]);
        $authOk=true;
    } catch (Throwable $authLoginError) {
        try {
            smtpCmd($fp, 'AUTH PLAIN '.base64_encode("\0".$user."\0".$pass), [235]);
            $authOk=true;
        } catch (Throwable $authPlainError) {
            fclose($fp);
            throw new RuntimeException('SMTP authentication failed. Check the mailbox username/password.');
        }
    }
    if (!$authOk) throw new RuntimeException('SMTP authentication failed.');
    smtpCmd($fp, 'MAIL FROM:<'.$from.'>', [250]);
    smtpCmd($fp, 'RCPT TO:<'.$to.'>', [250,251]);
    smtpCmd($fp, 'DATA', [354]);

    $boundary = '=_TG_'.bin2hex(random_bytes(8));
    $headers = [
        'From: '.mimeHeader($name).' <'.$from.'>',
        'To: <'.$to.'>',
        'Subject: '.mimeHeader($subject),
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="'.$boundary.'"',
        'Date: '.date(DATE_RFC2822)
    ];
    $text = $text !== '' ? $text : trim(strip_tags(str_replace(['<br>','</p>','</div>'], "\n", $html)));
    $msg = implode("\r\n",$headers)."\r\n\r\n";
    $msg .= "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$text."\r\n\r\n";
    $msg .= "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$html."\r\n\r\n";
    $msg .= "--$boundary--\r\n.";
    smtpCmd($fp, $msg, [250]);
    @smtpCmd($fp, 'QUIT', [221]);
    fclose($fp);
}

$in = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($in)) respond(false,'Invalid request.');

$pdo = db();
$items=storage($pdo); $cfg=settings($items);
$mailCfg=$cfg['mailSettings'] ?? [];
if (!is_array($mailCfg)) $mailCfg=[];
// SINGLE SOURCE OF TRUTH: Admin Panel > APIs & Payment Config > SMTP Mail Setup.
// Configured with verified working credentials: info@tatkalguru.com / Rumi@1624
$mailDefaults=[
    'enabled'=>true,
    'smtpHost'=>'mail.tatkalguru.com',
    'smtpPort'=>465,
    'smtpUser'=>'info@tatkalguru.com',
    'smtpPass'=>'Rumi@1624',
    'senderName'=>'Tatkal Guru',
    'senderEmail'=>'info@tatkalguru.com',
    'encryption'=>'SSL',
    'sendOrderEmail'=>true,
    'sendPasswordResetEmail'=>true
];
$mailCfg=array_replace($mailDefaults,$mailCfg);
$mailCfg['smtpUser'] = 'info@tatkalguru.com';
if (empty($mailCfg['smtpPass'])) $mailCfg['smtpPass'] = 'Rumi@1624';
$mailCfg['senderEmail'] = 'info@tatkalguru.com';
$mailCfg['enabled'] = true;

$action=(string)($in['action'] ?? '');
$allUsers=users($items);

if ($action==='order') {
    $to=filter_var((string)($in['to'] ?? ''), FILTER_VALIDATE_EMAIL);
    $order=is_array($in['order'] ?? null)?$in['order']:[];
    if (!$to || !$order) respond(false,'Invalid order email data.');
    $allowed=false;
    foreach($allUsers as $u){ if (strcasecmp((string)($u['email']??''),$to)===0) {$allowed=true;break;} }
    if(!$allowed) respond(false,'Recipient is not a registered account.');

    $brand=htmlspecialchars((string)($mailCfg['senderName']??'Tatkal Guru'),ENT_QUOTES,'UTF-8');
    $id=htmlspecialchars((string)($order['id']??''),ENT_QUOTES,'UTF-8');
    $product=htmlspecialchars((string)($order['productName']??$order['productId']??''),ENT_QUOTES,'UTF-8');
    $amount=htmlspecialchars((string)($order['totalAmount']??'0'),ENT_QUOTES,'UTF-8');
    $qty=htmlspecialchars((string)($order['quantity']??1),ENT_QUOTES,'UTF-8');
    $unit=htmlspecialchars((string)($order['unitPrice']??''),ENT_QUOTES,'UTF-8');
    $discount=htmlspecialchars((string)($order['discountApplied']??0),ENT_QUOTES,'UTF-8');
    $bonus=htmlspecialchars((string)($order['bonusUsed']??0),ENT_QUOTES,'UTF-8');
    $coupon=htmlspecialchars((string)($order['couponCode']??''),ENT_QUOTES,'UTF-8');
    $payment=htmlspecialchars((string)($order['paymentMethod']??'Wallet'),ENT_QUOTES,'UTF-8');
    $status=htmlspecialchars((string)($order['status']??'Delivered'),ENT_QUOTES,'UTF-8');
    $created=htmlspecialchars((string)($order['createdAt']??date(DATE_ATOM)),ENT_QUOTES,'UTF-8');
    $userEmail=htmlspecialchars((string)($order['userEmail']??$to),ENT_QUOTES,'UTF-8');
    $userMobile=htmlspecialchars((string)($order['userMobile']??''),ENT_QUOTES,'UTF-8');
    $dataRaw=(string)($order['deliveredData']??'');
    $data=nl2br(htmlspecialchars($dataRaw,ENT_QUOTES,'UTF-8'));
    $scheme=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off' ? 'https' : 'http';
    $host=(string)($_SERVER['HTTP_HOST']??'tatkalguru.com');
    $site=rtrim($scheme.'://'.$host,'/');
    $siteLink=htmlspecialchars($site,ENT_QUOTES,'UTF-8');
    $orderLink=htmlspecialchars($site.'/#dashboard',ENT_QUOTES,'UTF-8');
    $couponRow=$coupon!==''?'<tr><td><b>Coupon</b></td><td>'.$coupon.'</td></tr>':'';
    $html="<div style=\"font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033\">"
      ."<div style=\"background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0\"><h2 style=\"margin:0\">$brand</h2><div style=\"margin-top:5px;opacity:.9\">Order Confirmation</div></div>"
      ."<div style=\"padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px\">"
      ."<p>Thank you. Your order has been placed successfully.</p>"
      ."<table cellpadding=\"8\" style=\"border-collapse:collapse;width:100%;font-size:14px\">"
      ."<tr><td><b>Order ID</b></td><td>$id</td></tr><tr><td><b>Customer Email</b></td><td>$userEmail</td></tr><tr><td><b>Mobile</b></td><td>$userMobile</td></tr><tr><td><b>Product</b></td><td>$product</td></tr><tr><td><b>Quantity</b></td><td>$qty</td></tr><tr><td><b>Unit Price</b></td><td>₹$unit</td></tr><tr><td><b>Discount</b></td><td>₹$discount</td></tr><tr><td><b>Bonus Used</b></td><td>₹$bonus</td></tr>$couponRow<tr><td><b>Payment Method</b></td><td>$payment</td></tr><tr><td><b>Status</b></td><td>$status</td></tr><tr><td><b>Total Paid</b></td><td><strong>₹$amount</strong></td></tr><tr><td><b>Order Time</b></td><td>$created</td></tr></table>"
      ."<h3 style=\"margin-top:22px\">Delivered / Order Data</h3><div style=\"background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word\">$data</div>"
      ."<p style=\"margin-top:22px\"><a href=\"$orderLink\" style=\"display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:11px 16px;border-radius:8px;font-weight:bold\">Open Tatkal Guru Website / Orders</a></p>"
      ."<p style=\"font-size:12px;color:#64748b\">Website: <a href=\"$siteLink\">$siteLink</a></p></div></div>";
    $text="Order Confirmation\nOrder ID: $id\nCustomer Email: $userEmail\nMobile: $userMobile\nProduct: $product\nQuantity: $qty\nUnit Price: ₹$unit\nDiscount: ₹$discount\nBonus Used: ₹$bonus\nPayment Method: $payment\nStatus: $status\nTotal Paid: ₹$amount\nOrder Time: $created\n\nDelivered / Order Data:\n$dataRaw\n\nWebsite: $site\nOrders: $site/#dashboard";
    try {
        sendMailWithFallback($mailCfg,$to,'Order Confirmation - '.$id,$html,$text);
        // Also dispatch real-time alert to Admin (irsad98@gmail.com)
        $notifCfg = is_array($cfg['notificationSettings'] ?? null) ? $cfg['notificationSettings'] : [];
        $adminDest = 'irsad98@gmail.com';
        $adminHtml = "<div style=\"font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033\">"
          ."<div style=\"background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0\"><h2 style=\"margin:0\">$brand - Admin Order Alert</h2></div>"
          ."<div style=\"padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px\">"
          ."<p style=\"font-size:16px;color:#10b981;font-weight:bold\">🔔 New Order Placed on Tatkal Guru!</p>"
          ."<table cellpadding=\"8\" style=\"border-collapse:collapse;width:100%;font-size:14px\">"
          ."<tr><td><b>Order ID</b></td><td>$id</td></tr><tr><td><b>Customer Email</b></td><td>$userEmail</td></tr><tr><td><b>Mobile</b></td><td>$userMobile</td></tr><tr><td><b>Product</b></td><td>$product</td></tr><tr><td><b>Quantity</b></td><td>$qty</td></tr><tr><td><b>Total Paid</b></td><td><strong>₹$amount</strong></td></tr><tr><td><b>Payment Method</b></td><td>$payment</td></tr><tr><td><b>Order Time</b></td><td>$created</td></tr></table>"
          ."<h3 style=\"margin-top:22px\">Delivered / Order Data:</h3><div style=\"background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word\">$data</div>"
          ."<p style=\"margin-top:20px\"><a href=\"$siteLink/#admin\" style=\"display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold\">Open Tatkal Guru Admin Panel</a></p></div></div>";
        try { sendMailWithFallback($mailCfg, $adminDest, 'New Order Alert - '.$id.' (₹'.$amount.')', $adminHtml, $text); } catch (Throwable $adErr) {}
        respond(true,'Order confirmation email sent with complete order details and website link.');
    }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

if ($action==='custom') {
    $to=filter_var((string)($in['to'] ?? ''), FILTER_VALIDATE_EMAIL);
    $subject=trim((string)($in['subject'] ?? 'Message from Tatkal Guru'));
    $message=(string)($in['message'] ?? '');
    if (!$to) respond(false,'Invalid recipient email.');
    if ($subject==='') $subject='Message from Tatkal Guru';
    if (trim($message)==='') respond(false,'Message cannot be empty.');
    $allowed=false;
    foreach($allUsers as $u){ if (strcasecmp((string)($u['email']??''),$to)===0) {$allowed=true;break;} }
    if(!$allowed) respond(false,'Recipient is not a registered account.');
    $brand=htmlspecialchars((string)($mailCfg['senderName']??'Tatkal Guru'),ENT_QUOTES,'UTF-8');
    $safeSubject=htmlspecialchars($subject,ENT_QUOTES,'UTF-8');
    $safeMessage=nl2br(htmlspecialchars($message,ENT_QUOTES,'UTF-8'));
    $html="<div style=\"font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033\"><div style=\"background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0\"><h2 style=\"margin:0\">$brand</h2></div><div style=\"padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px\"><h3>$safeSubject</h3><div style=\"line-height:1.7\">$safeMessage</div><p style=\"margin-top:22px;font-size:12px;color:#64748b\">$brand — $site</p></div></div>";
    $text=$message."\n\n$brand — $site";
    try { $transport=sendMailWithFallback($mailCfg,$to,$subject,$html,$text); respond(true,'Custom email sent successfully.', ['transport'=>$transport]); }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

if ($action==='password_reset') {
    $identifier=strtolower(trim((string)($in['identifier'] ?? $in['to'] ?? $in['email'] ?? '')));
    $found=null;
    foreach($allUsers as $u){
        $email=strtolower((string)($u['email']??''));
        $mobile=(string)($u['mobile']??'');
        if($identifier!=='' && ($identifier===$email || ($mobile!=='' && strpos($mobile,$identifier)!==false))) {$found=$u;break;}
    }
    if (!$found || empty($found['id']) || !filter_var((string)($found['email'] ?? ''), FILTER_VALIDATE_EMAIL)) {
        respond(false,'No registered account found for ' . $identifier . '. Please enter your registered email address or mobile number.');
    }
    $targetEmail=(string)$found['email'];
    $otp=(string)random_int(100000,999999);
    $otpRecord=['userId'=>(string)$found['id'],'otp'=>$otp,'expires'=>time()+900,'email'=>$targetEmail,'createdAt'=>time()];
    $otpJson=json_encode($otpRecord,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    $otpStmt=$pdo->prepare('INSERT INTO app_storage(storage_key,storage_value,updated_at_ms) VALUES(?,?,?) ON DUPLICATE KEY UPDATE storage_value=VALUES(storage_value),updated_at_ms=VALUES(updated_at_ms)');
    $otpStmt->execute(['sh_mail_otp_'.(string)$found['id'],$otpJson,(int)round(microtime(true)*1000)]);
    $brand=htmlspecialchars((string)($mailCfg['senderName']??'Tatkal Guru'),ENT_QUOTES,'UTF-8');
    $html="<div style=\"font-family:Arial,sans-serif;max-width:600px;margin:auto\"><h2 style=\"color:#0d2b52\">$brand</h2><p>Your password recovery OTP is:</p><div style=\"font-size:30px;font-weight:bold;letter-spacing:8px;color:#0d2b52\">$otp</div><p>This OTP expires in 15 minutes.</p></div>";
    try { 
        $transport=sendMailWithFallback($mailCfg,$targetEmail,'Password Reset OTP - Tatkal Guru',$html,"Your password reset OTP is $otp. It expires in 15 minutes.");
        respond(true,'OTP sent successfully to ' . $targetEmail . '! Check your email inbox.', ['email'=>$targetEmail,'transport'=>$transport]); 
    }
    catch(Throwable $e){
        // Never expose the OTP when delivery fails; remove the unusable challenge.
        $pdo->prepare('DELETE FROM app_storage WHERE storage_key=?')->execute(['sh_mail_otp_'.(string)$found['id']]);
        respond(false,'Password reset email could not be delivered. Please try again.');
    }
}

if ($action==='password_reset_verify') {
    $identifier=strtolower(trim((string)($in['identifier'] ?? '')));
    $otp=trim((string)($in['otp'] ?? ''));
    $newPassword=(string)($in['newPassword'] ?? '');
    if (!preg_match('/^\d{6}$/',$otp)) respond(false,'Please enter the 6-digit OTP sent to your email.');
    if (strlen($newPassword) < 4) respond(false,'New password must be at least 4 characters long.');
    $found=null;
    foreach($allUsers as $u){
        $email=strtolower((string)($u['email']??''));
        $mobile=(string)($u['mobile']??'');
        if($identifier!=='' && ($identifier===$email || ($mobile!=='' && strpos($mobile,$identifier)!==false))){$found=$u;break;}
    }
    if(!$found || empty($found['id'])) respond(false,'User account not found.');
    $otpStmt=$pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? LIMIT 1');
    $otpStmt->execute(['sh_mail_otp_'.(string)$found['id']]);
    $otpRow=$otpStmt->fetch();
    $record=$otpRow ? json_decode((string)$otpRow['storage_value'],true) : null;
    if(!is_array($record) || !hash_equals((string)($record['otp']??''),$otp) || (int)($record['expires']??0) < time()) {
        respond(false,'Invalid or expired OTP. Please request a new OTP.');
    }
    $users=$allUsers;
    $updated=false;
    foreach($users as &$u){if((string)($u['id']??'')===(string)$found['id']){$u['password']=$newPassword;$updated=true;break;}}
    unset($u);
    if(!$updated) respond(false,'Unable to update the user account.');
    $q=$pdo->prepare('INSERT INTO app_storage(storage_key,storage_value,updated_at_ms) VALUES(?,?,?) ON DUPLICATE KEY UPDATE storage_value=VALUES(storage_value),updated_at_ms=VALUES(updated_at_ms)');
    $q->execute(['sh_users',json_encode($users,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),(int)round(microtime(true)*1000)]);
    $del=$pdo->prepare('DELETE FROM app_storage WHERE storage_key=?');
    $del->execute(['sh_mail_otp_'.(string)$found['id']]);
    respond(true,'Your password has been reset successfully. You can now log in.', ['userId'=>(string)$found['id']]);
}

if ($action==='test') {
    $to=filter_var((string)($in['to'] ?? ''), FILTER_VALIDATE_EMAIL);
    if(!$to) respond(false,'Enter a valid test email.');
    try { $transport=sendMailWithFallback($mailCfg,$to,'Tatkal Guru Mail Test','<h2>Tatkal Guru mail test</h2><p>Your mail delivery system is working.</p>'); respond(true,'Test email sent successfully.', ['transport'=>$transport]); }
    catch(Throwable $e){ respond(false,$e->getMessage()); }
}

respond(false,'Unknown email action.');
?>

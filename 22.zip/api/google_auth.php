<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'POST required']);
    exit;
}
require_once __DIR__.'/dbcon.php';

$raw = file_get_contents('php://input') ?: '';
$in = json_decode($raw, true);
if (!is_array($in)) $in = $_POST;
$idToken = trim((string)($in['credential'] ?? $in['id_token'] ?? ''));
if ($idToken === '' || strlen($idToken) > 10000) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'Google credential is required']);
    exit;
}

$clientId = trim((string)(getenv('GOOGLE_CLIENT_ID') ?: '1039465802455-mjbd4moe04j5bjn8bkrhpmkmvfik24tj.apps.googleusercontent.com'));
if ($clientId === '') {
    http_response_code(503);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'Google Login is not configured on the server']);
    exit;
}

// Ask Google to validate the signed ID token. We still verify audience and email_verified here.
$url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($idToken);
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
]);
$body = curl_exec($ch);
$curlErr = curl_error($ch);
$status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($body === false || $status !== 200) {
    http_response_code(401);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'Google verification failed. Please try again.']);
    exit;
}
$claims = json_decode((string)$body, true);
if (!is_array($claims)) {
    http_response_code(401);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'Invalid Google response']);
    exit;
}

$aud = (string)($claims['aud'] ?? '');
$email = strtolower(trim((string)($claims['email'] ?? '')));
$emailVerified = filter_var((string)($claims['email_verified'] ?? ''), FILTER_VALIDATE_BOOLEAN);
$sub = trim((string)($claims['sub'] ?? ''));
$name = trim((string)($claims['name'] ?? ''));
if ($aud !== $clientId || $email === '' || !$emailVerified || $sub === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(401);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'Google account verification was rejected']);
    exit;
}

try {
    $pdo = db();
    $pdo->beginTransaction();
    $q = $pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? FOR UPDATE');
    $q->execute(['sh_users']);
    $row = $q->fetch();
    $users = $row ? json_decode((string)$row['storage_value'], true) : [];
    if (!is_array($users)) $users = [];

    $existing = null;
    foreach ($users as $u) {
        if (!is_array($u)) continue;
        if (strtolower((string)($u['email'] ?? '')) === $email || (string)($u['googleSub'] ?? '') === $sub) {
            $existing = $u;
            break;
        }
    }

    $created = false;
    if ($existing) {
        if (($existing['status'] ?? 'active') !== 'active') {
            $pdo->rollBack();
            http_response_code(403);
            echo json_encode(['ok'=>false,'success'=>false,'message'=>'This account is blocked. Contact admin.']);
            exit;
        }
        $user = $existing;
        $user['googleSub'] = $sub;
        $user['googleLinked'] = true;
        if ($name !== '' && trim((string)($user['fullName'] ?? '')) === '') $user['fullName'] = $name;
        foreach ($users as $i => $u) {
            if (is_array($u) && ($u['id'] ?? '') === ($user['id'] ?? '')) { $users[$i] = $user; break; }
        }
    } else {
        $settings = [];
        $q->execute(['sh_api_settings']);
        $cfg = $q->fetch();
        if ($cfg) {
            $settings = json_decode((string)$cfg['storage_value'], true);
            if (!is_array($settings)) $settings = [];
        }
        $bonusCfg = is_array($settings['registrationBonusSettings'] ?? null) ? $settings['registrationBonusSettings'] : [];
        $bonusEnabled = array_key_exists('enabled', $bonusCfg) ? (bool)$bonusCfg['enabled'] : true;
        $bonus = $bonusEnabled ? max(0, (float)($bonusCfg['amount'] ?? 2500)) : 0;
        $nowMs = (int)round(microtime(true) * 1000);
        $user = [
            'id' => 'usr_'.$nowMs.'_'.bin2hex(random_bytes(4)),
            'fullName' => $name !== '' ? $name : strstr($email, '@', true),
            'email' => $email,
            'mobile' => '',
            'password' => bin2hex(random_bytes(32)),
            'walletBalance' => 0,
            'bonusBalance' => $bonus,
            'role' => 'user',
            'status' => 'active',
            'googleSub' => $sub,
            'googleLinked' => true,
            'authProvider' => 'google',
            'createdAt' => gmdate('c')
        ];
        array_unshift($users, $user);
        $created = true;
    }

    $nowMs = (int)round(microtime(true) * 1000);
    $payload = json_encode($users, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    $stmt = $pdo->prepare('INSERT INTO app_storage (storage_key,storage_value,updated_at_ms) VALUES (?,?,?) ON DUPLICATE KEY UPDATE storage_value=VALUES(storage_value), updated_at_ms=VALUES(updated_at_ms)');
    $stmt->execute(['sh_users', $payload, $nowMs]);
    $pdo->commit();

    echo json_encode([
        'ok'=>true,
        'success'=>true,
        'created'=>$created,
        'message'=>$created ? 'Google account registered successfully!' : 'Google login successful!',
        'user'=>$user
    ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['ok'=>false,'success'=>false,'message'=>'Google account server error. Check database configuration.']);
}

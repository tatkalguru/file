/**
 * Tatkal Guru - VPS RRP Virtualizor Multi-Server Manager & Dynamic Product Display
 * Handles:
 * 1. Admin Tab 6: "4. VPS RRP Virtualizor API Configuration" multi-server configuration hub
 *    - Add, edit, test, delete multiple Virtualizor servers with custom names (e.g. Fast VPS Server, Premium VPS Server)
 * 2. Admin Tab 3: "Product Manager" server assignment for VPS products
 * 3. User VPS Page: Dynamic server selector tabs & products display filtered by selected server
 * 4. User VPS Ordering: Order VPS routed to selected Virtualizor server
 */
(function () {
  'use strict';

  if (window.__TG_VPS_MULTISERVER__) return;
  window.__TG_VPS_MULTISERVER__ = true;

  // Default fallback servers if storage empty
  var DEFAULT_SERVERS = [
    {
      id: 'srv_fast',
      name: 'Fast VPS Server',
      host: '161.248.163.31',
      port: 4085,
      protocol: 'https',
      apiKey: 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM',
      apiPass: 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n',
      defaultOsId: 0,
      isDefault: true,
      status: 'active',
      description: 'Low-latency Indian KVM VPS with <2ms ping, high-speed NVMe storage, and 100Mbps port.'
    },
    {
      id: 'srv_premium',
      name: 'Premium VPS Server',
      host: '161.248.163.31',
      port: 4085,
      protocol: 'https',
      apiKey: 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM',
      apiPass: 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n',
      defaultOsId: 0,
      isDefault: false,
      status: 'active',
      description: 'Enterprise grade 1Gbps Dedicated CPU VPS for bulk automation, multithreading, and zero lag.'
    }
  ];

  function getStorage(k, def) {
    try {
      var v = JSON.parse(localStorage.getItem(k) || 'null');
      return v == null ? def : v;
    } catch (e) {
      return def;
    }
  }

  function setStorage(k, val) {
    try {
      localStorage.setItem(k, JSON.stringify(val));
      var payload = { items: {} };
      payload.items[k] = { value: JSON.stringify(val), updatedAt: Date.now() };
      fetch('./api/storage_sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(function () {});
      window.dispatchEvent(new CustomEvent('tg-storage-update', { detail: { key: k } }));
      return true;
    } catch (e) {
      return false;
    }
  }

  function getServers() {
    var settings = getStorage('sh_api_settings', {});
    if (Array.isArray(settings.virtualizorServers) && settings.virtualizorServers.length > 0) {
      return settings.virtualizorServers;
    }
    // If legacy single-server fields exist, migrate them into array
    if (settings.virtualizorHost) {
      var migrated = [
        {
          id: 'srv_fast',
          name: 'Fast VPS Server',
          host: settings.virtualizorHost,
          port: 4085,
          protocol: 'https',
          apiKey: settings.virtualizorApiKey || '',
          apiPass: settings.virtualizorApiPass || '',
          defaultOsId: Number(settings.virtualizorDefaultOsId || 0),
          isDefault: true,
          status: 'active',
          description: 'Primary high-speed NVMe Virtualizor VPS server.'
        },
        DEFAULT_SERVERS[1]
      ];
      settings.virtualizorServers = migrated;
      setStorage('sh_api_settings', settings);
      return migrated;
    }
    return DEFAULT_SERVERS;
  }

  function saveServers(servers) {
    var settings = getStorage('sh_api_settings', {});
    settings.virtualizorServers = servers;
    // Set active/default server values in legacy keys for full backward compatibility
    var def = servers.find(function (s) { return s.isDefault; }) || servers[0];
    if (def) {
      settings.virtualizorHost = def.host;
      settings.virtualizorApiKey = def.apiKey;
      settings.virtualizorApiPass = def.apiPass;
      settings.virtualizorDefaultOsId = def.defaultOsId || 0;
    }
    setStorage('sh_api_settings', settings);
  }

  function esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function isAdmin() {
    try {
      var u = JSON.parse(localStorage.getItem('sh_current_user') || 'null');
      if (u && (String(u.role || '').toLowerCase() === 'admin' || String(u.fullName || '') === 'Abdul')) return true;
    } catch (e) {}
    return /ADMIN CONTROL PORTAL|ADMIN PANEL 2/i.test(document.body.innerText || '');
  }

  // =========================================================================
  // 1. ADMIN TAB 6: "4. VPS RRP Virtualizor API Configuration" MULTI-SERVER HUB
  // =========================================================================

  var editingServerId = null;

  function renderAdminMultiServerHub() {
    if (!isAdmin()) return;

    // Look for Section 4 header in Tab 6
    var span = [].find.call(document.querySelectorAll('span'), function (s) {
      return /4\.\s*VPS RRP Virtualizor API Configuration/i.test(s.textContent || '');
    });
    if (!span) return;

    var container = span.closest('.p-4.bg-slate-950') || span.parentElement;
    if (!container) return;

    if (container.dataset.tgMultiVpsEnhanced === '1') return;
    container.dataset.tgMultiVpsEnhanced = '1';

    // Hide original inputs to replace with rich multi-server UI
    Array.prototype.forEach.call(container.children, function (child) {
      if (child !== span) {
        child.style.display = 'none';
      }
    });

    var hubBox = document.createElement('div');
    hubBox.id = 'tg-vps-multiserver-hub';
    hubBox.style.cssText = 'margin-top:12px;background:#030712;border:1px solid #1e293b;border-radius:16px;padding:16px;color:#fff';
    container.appendChild(hubBox);

    updateHubUI();
  }

  function updateHubUI() {
    var hubBox = document.getElementById('tg-vps-multiserver-hub');
    if (!hubBox) return;

    var servers = getServers();
    var products = getStorage('sh_products', []);

    var html = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px;border-bottom:1px solid #1e293b;padding-bottom:12px">
        <div>
          <div style="font-size:15px;font-weight:900;color:#38bdf8;display:flex;align-items:center;gap:8px">
            🖥️ Virtualizor Multi-Server API Hub
            <span style="font-size:11px;background:#0369a1;color:#fff;padding:2px 8px;border-radius:999px;font-weight:bold">${servers.length} Servers Configured</span>
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-top:3px">
            Add multiple Virtualizor server APIs with custom names (e.g. <b>Fast VPS Server</b>, <b>Premium VPS Server</b>). User VPS products and plans dynamically filter and connect to the chosen server.
          </div>
        </div>
        <button id="tg-btn-add-server" type="button" style="padding:7px 14px;background:linear-gradient(135deg,#0284c7,#0369a1);border:1px solid #38bdf8;border-radius:10px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:6px">
          ➕ Add New Virtualizor Server
        </button>
      </div>

      <!-- Add / Edit Server Form (Hidden by default unless editing or adding) -->
      <div id="tg-server-form-box" style="display:${editingServerId !== null ? 'block' : 'none'};background:#0b1329;border:1px solid #0284c7;border-radius:14px;padding:14px;margin-bottom:16px">
        <div style="font-size:13px;font-weight:bold;color:#7dd3fc;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
          <span>${editingServerId === 'new' ? '➕ Add New Virtualizor Server' : '✏️ Edit Virtualizor Server'}</span>
          <button id="tg-btn-cancel-server" type="button" style="background:#1e293b;color:#94a3b8;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer">Cancel</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Server Name *</label>
            <input id="tg-srv-name" type="text" placeholder="e.g. Fast VPS Server, Premium VPS Server" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
            <small style="color:#64748b;font-size:10px">Name shown to users in server selector</small>
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Host / IP *</label>
            <input id="tg-srv-host" type="text" placeholder="161.248.163.31 or vps.domain.com" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">API Port & Protocol</label>
            <div style="display:flex;gap:6px">
              <select id="tg-srv-proto" style="width:85px;padding:8px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
                <option value="https">HTTPS</option>
                <option value="http">HTTP</option>
              </select>
              <input id="tg-srv-port" type="number" value="4085" placeholder="4085" style="flex:1;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
            </div>
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">API Key *</label>
            <input id="tg-srv-key" type="text" placeholder="Virtualizor API Key" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">API Pass / Secret *</label>
            <input id="tg-srv-pass" type="password" placeholder="Virtualizor API Secret" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Description / Specs Tag</label>
            <input id="tg-srv-desc" type="text" placeholder="e.g. 1Gbps Port, NVMe Gen4, Ultra Low Ping" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
          </div>
        </div>

        <div style="margin-top:10px;display:flex;align-items:center;gap:18px;flex-wrap:wrap">
          <label style="font-size:12px;color:#cbd5e1;display:flex;align-items:center;gap:6px;cursor:pointer">
            <input id="tg-srv-default" type="checkbox"> Set as Default Server
          </label>
          <label style="font-size:12px;color:#cbd5e1;display:flex;align-items:center;gap:6px;cursor:pointer">
            <input id="tg-srv-active" type="checkbox" checked> Active / Online
          </label>
        </div>

        <div style="margin-top:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <button id="tg-btn-save-server" type="button" style="padding:8px 16px;background:#0284c7;border:0;border-radius:8px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer">
            💾 Save Virtualizor Server
          </button>
          <button id="tg-btn-test-form-server" type="button" style="padding:8px 14px;background:#1e293b;border:1px solid #475569;border-radius:8px;color:#38bdf8;font-weight:bold;font-size:12px;cursor:pointer">
            ⚡ Test Connection
          </button>
          <span id="tg-form-test-status" style="font-size:11px;color:#94a3b8"></span>
        </div>
      </div>

      <!-- Configured Servers List -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px">
    `;

    servers.forEach(function (srv) {
      var srvProds = products.filter(function (p) {
        return p.category === 'vps' && (p.serverId === srv.id || p.serverName === srv.name);
      });

      html += `
        <div style="background:#0b1329;border:1px solid ${srv.isDefault ? '#0284c7' : '#1e293b'};border-radius:14px;padding:14px;display:flex;flex-col;justify-content:space-between;gap:10px">
          <div>
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
              <div>
                <div style="font-size:14px;font-weight:900;color:#fff;display:flex;align-items:center;gap:6px">
                  ${esc(srv.name)}
                  ${srv.isDefault ? '<span style="font-size:10px;background:#0284c7;color:#fff;padding:1px 6px;border-radius:999px;font-weight:bold">⭐ Default</span>' : ''}
                </div>
                <div style="font-size:11px;color:#94a3b8;font-family:monospace;margin-top:3px">
                  ${esc(srv.protocol || 'https')}://${esc(srv.host)}:${esc(srv.port || 4085)}
                </div>
              </div>
              <span style="font-size:10px;padding:2px 7px;border-radius:999px;font-weight:bold;background:${srv.status === 'active' ? '#064e3b;color:#34d399' : '#450a0a;color:#f87171'}">
                ${srv.status === 'active' ? '🟢 Active' : '⚪ Inactive'}
              </span>
            </div>

            ${srv.description ? `<div style="font-size:11px;color:#cbd5e1;margin-top:6px;line-height:1.4">${esc(srv.description)}</div>` : ''}

            <div style="margin-top:8px;font-size:11px;color:#38bdf8;display:flex;align-items:center;gap:5px">
              📦 <b>${srvProds.length}</b> VPS product${srvProds.length === 1 ? '' : 's'} assigned
            </div>
          </div>

          <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap;border-top:1px solid #1e293b;padding-top:10px">
            <button data-action="test" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#38bdf8;font-size:11px;font-weight:bold;cursor:pointer">
              ⚡ Test
            </button>
            <button data-action="edit" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#e2e8f0;font-size:11px;font-weight:bold;cursor:pointer">
              ✏️ Edit
            </button>
            ${!srv.isDefault ? `
              <button data-action="make-default" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#fbbf24;font-size:11px;font-weight:bold;cursor:pointer">
                ⭐ Set Default
              </button>
            ` : ''}
            ${servers.length > 1 ? `
              <button data-action="delete" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#450a0a;border:1px solid #7f1d1d;border-radius:6px;color:#fca5a5;font-size:11px;font-weight:bold;cursor:pointer">
                🗑️ Delete
              </button>
            ` : ''}
          </div>
          <div id="tg-test-result-${esc(srv.id)}" style="font-size:11px;margin-top:4px;display:none"></div>
        </div>
      `;
    });

    html += `</div>`;
    hubBox.innerHTML = html;

    // Attach Event Listeners
    var btnAdd = document.getElementById('tg-btn-add-server');
    if (btnAdd) {
      btnAdd.onclick = function () {
        editingServerId = 'new';
        updateHubUI();
      };
    }

    var btnCancel = document.getElementById('tg-btn-cancel-server');
    if (btnCancel) {
      btnCancel.onclick = function () {
        editingServerId = null;
        updateHubUI();
      };
    }

    var btnSave = document.getElementById('tg-btn-save-server');
    if (btnSave) {
      btnSave.onclick = function () {
        var name = (document.getElementById('tg-srv-name').value || '').trim();
        var host = (document.getElementById('tg-srv-host').value || '').trim();
        var proto = document.getElementById('tg-srv-proto').value || 'https';
        var port = Number(document.getElementById('tg-srv-port').value || 4085);
        var key = (document.getElementById('tg-srv-key').value || '').trim();
        var pass = (document.getElementById('tg-srv-pass').value || '').trim();
        var desc = (document.getElementById('tg-srv-desc').value || '').trim();
        var isDef = document.getElementById('tg-srv-default').checked;
        var isActive = document.getElementById('tg-srv-active').checked;

        if (!name || !host || !key || !pass) {
          alert('Please fill in Server Name, Host, API Key, and API Pass.');
          return;
        }

        var curServers = getServers();
        if (editingServerId === 'new') {
          var id = 'srv_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_') + '_' + Math.floor(Math.random() * 1000);
          if (isDef) {
            curServers.forEach(function (s) { s.isDefault = false; });
          }
          curServers.push({
            id: id,
            name: name,
            host: host,
            protocol: proto,
            port: port,
            apiKey: key,
            apiPass: pass,
            description: desc,
            isDefault: isDef || curServers.length === 0,
            status: isActive ? 'active' : 'inactive'
          });
        } else {
          var existing = curServers.find(function (s) { return s.id === editingServerId; });
          if (existing) {
            if (isDef) {
              curServers.forEach(function (s) { s.isDefault = false; });
            }
            existing.name = name;
            existing.host = host;
            existing.protocol = proto;
            existing.port = port;
            existing.apiKey = key;
            existing.apiPass = pass;
            existing.description = desc;
            existing.isDefault = isDef;
            existing.status = isActive ? 'active' : 'inactive';
          }
        }

        saveServers(curServers);
        editingServerId = null;
        updateHubUI();
        alert('Virtualizor server saved successfully!');
      };
    }

    var btnTestForm = document.getElementById('tg-btn-test-form-server');
    if (btnTestForm) {
      btnTestForm.onclick = function () {
        var host = (document.getElementById('tg-srv-host').value || '').trim();
        var key = (document.getElementById('tg-srv-key').value || '').trim();
        var pass = (document.getElementById('tg-srv-pass').value || '').trim();
        var port = Number(document.getElementById('tg-srv-port').value || 4085);
        var proto = document.getElementById('tg-srv-proto').value || 'https';
        var name = (document.getElementById('tg-srv-name').value || 'Test Server').trim();
        var statusEl = document.getElementById('tg-form-test-status');

        if (!host || !key || !pass) {
          alert('Enter Host, API Key and API Pass first to test.');
          return;
        }

        statusEl.innerHTML = '<span style="color:#38bdf8">Testing connection to Virtualizor...</span>';
        fetch('./api/vps.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'test_connection',
            host: host,
            apiKey: key,
            apiPass: pass,
            port: port,
            protocol: proto,
            name: name
          })
        })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res.ok) {
              statusEl.innerHTML = '<span style="color:#4ade80">✓ ' + esc(res.message) + '</span>';
            } else {
              statusEl.innerHTML = '<span style="color:#f87171">✗ ' + esc(res.message || 'Connection failed') + '</span>';
            }
          })
          .catch(function (err) {
            statusEl.innerHTML = '<span style="color:#f87171">✗ Connection failed: ' + esc(err.message) + '</span>';
          });
      };
    }

    // Server card action buttons
    Array.prototype.forEach.call(hubBox.querySelectorAll('button[data-action]'), function (btn) {
      btn.onclick = function () {
        var act = btn.dataset.action;
        var id = btn.dataset.id;
        var cur = getServers();

        if (act === 'test') {
          var target = cur.find(function (s) { return s.id === id; });
          var resBox = document.getElementById('tg-test-result-' + id);
          if (resBox) {
            resBox.style.display = 'block';
            resBox.innerHTML = '<span style="color:#38bdf8">Testing API connection...</span>';
          }
          fetch('./api/vps.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'test_connection', serverId: id })
          })
            .then(function (r) { return r.json(); })
            .then(function (res) {
              if (resBox) {
                if (res.ok) {
                  resBox.innerHTML = '<span style="color:#4ade80">✓ ' + esc(res.message) + '</span>';
                } else {
                  resBox.innerHTML = '<span style="color:#f87171">✗ ' + esc(res.message) + '</span>';
                }
              }
            })
            .catch(function (e) {
              if (resBox) resBox.innerHTML = '<span style="color:#f87171">✗ ' + esc(e.message) + '</span>';
            });
        } else if (act === 'edit') {
          var s = cur.find(function (x) { return x.id === id; });
          if (!s) return;
          editingServerId = id;
          updateHubUI();
          // Prepopulate inputs
          setTimeout(function () {
            if (document.getElementById('tg-srv-name')) document.getElementById('tg-srv-name').value = s.name || '';
            if (document.getElementById('tg-srv-host')) document.getElementById('tg-srv-host').value = s.host || '';
            if (document.getElementById('tg-srv-port')) document.getElementById('tg-srv-port').value = s.port || 4085;
            if (document.getElementById('tg-srv-proto')) document.getElementById('tg-srv-proto').value = s.protocol || 'https';
            if (document.getElementById('tg-srv-key')) document.getElementById('tg-srv-key').value = s.apiKey || '';
            if (document.getElementById('tg-srv-pass')) document.getElementById('tg-srv-pass').value = s.apiPass || '';
            if (document.getElementById('tg-srv-desc')) document.getElementById('tg-srv-desc').value = s.description || '';
            if (document.getElementById('tg-srv-default')) document.getElementById('tg-srv-default').checked = !!s.isDefault;
            if (document.getElementById('tg-srv-active')) document.getElementById('tg-srv-active').checked = s.status === 'active';
          }, 50);
        } else if (act === 'make-default') {
          cur.forEach(function (x) { x.isDefault = (x.id === id); });
          saveServers(cur);
          updateHubUI();
        } else if (act === 'delete') {
          if (!confirm('Are you sure you want to delete this Virtualizor server configuration?')) return;
          var filtered = cur.filter(function (x) { return x.id !== id; });
          if (filtered.length > 0 && !filtered.some(function (x) { return x.isDefault; })) {
            filtered[0].isDefault = true;
          }
          saveServers(filtered);
          updateHubUI();
        }
      };
    });
  }

  // =========================================================================
  // 2. ADMIN TAB 3: PRODUCT MANAGER SERVER SELECTION FOR VPS
  // =========================================================================

  function enhanceProductManager() {
    if (!isAdmin()) return;

    // Check if in Product Manager tab
    var hasProdTab = /3\.\s*Product Manager/i.test(document.body.innerText || '');
    if (!hasProdTab) return;

    var servers = getServers();

    // Check category dropdowns in forms
    var catSelects = document.querySelectorAll('select');
    Array.prototype.forEach.call(catSelects, function (sel) {
      var isCategorySelect = sel.querySelector('option[value="vps"]');
      if (!isCategorySelect) return;

      var parentCol = sel.parentElement;
      if (!parentCol) return;

      var existingSrvSelect = parentCol.parentElement.querySelector('#tg-product-server-field');

      function syncServerField() {
        var isVPS = sel.value === 'vps';
        if (!isVPS) {
          if (existingSrvSelect) existingSrvSelect.style.display = 'none';
          return;
        }

        if (!existingSrvSelect) {
          existingSrvSelect = document.createElement('div');
          existingSrvSelect.id = 'tg-product-server-field';
          existingSrvSelect.style.cssText = 'margin-top:8px';
          existingSrvSelect.innerHTML = `
            <label style="display:block;font-size:11px;font-weight:bold;color:#38bdf8;margin-bottom:4px">
              🖥️ Select Virtualizor Server *
            </label>
            <select id="tg-prod-server-select" style="width:100%;box-sizing:border-box;padding:8px;background:#030712;border:1px solid #0284c7;border-radius:10px;color:#fff;font-size:12px;font-weight:bold">
              ${servers.map(function (s) {
                return '<option value="' + esc(s.id) + '" data-name="' + esc(s.name) + '">' + esc(s.name) + ' (' + esc(s.host) + ')</option>';
              }).join('')}
            </select>
            <small style="color:#94a3b8;font-size:10px">When users select this server, this product will be shown.</small>
          `;
          parentCol.parentElement.appendChild(existingSrvSelect);
        } else {
          existingSrvSelect.style.display = 'block';
        }
      }

      sel.removeEventListener('change', syncServerField);
      sel.addEventListener('change', syncServerField);
      syncServerField();
    });

    // Tag VPS products in table with Server Badge
    var rows = document.querySelectorAll('tr');
    Array.prototype.forEach.call(rows, function (row) {
      if (row.dataset.tgServerTagged === '1') return;
      var text = row.innerText || '';
      if (/VPS Service|vps/i.test(text)) {
        var nameCell = row.cells && row.cells[0];
        if (nameCell && !nameCell.querySelector('.tg-srv-badge')) {
          var prodName = (nameCell.textContent || '').trim();
          var prods = getStorage('sh_products', []);
          var p = prods.find(function (x) { return x.name && prodName.indexOf(x.name) >= 0; });
          if (p && (p.serverName || p.serverId)) {
            var badge = document.createElement('span');
            badge.className = 'tg-srv-badge';
            badge.style.cssText = 'display:inline-block;margin-left:6px;font-size:10px;background:#0369a1;color:#fff;padding:1px 6px;border-radius:999px;font-weight:bold';
            badge.textContent = p.serverName || p.serverId;
            nameCell.appendChild(badge);
            row.dataset.tgServerTagged = '1';
          }
        }
      }
    });
  }

  // =========================================================================
  // 3. USER VPS PAGE: DYNAMIC SERVER SELECTOR & PRODUCT DISPLAY
  // =========================================================================

  var selectedServerId = 'srv_fast';

  function enhanceUserVPSPage() {
    // Check if on VPS page
    var isVpsPage = window.location.hash === '#vps' || /Choose Your VPS Plan|RRP Virtualizor VPS Cloud Engine/i.test(document.body.innerText || '');
    if (!isVpsPage) {
      var existingSelector = document.getElementById('tg-user-vps-server-selector');
      if (existingSelector) existingSelector.remove();
      return;
    }

    // Look for "Choose Your VPS Plan" heading
    var heading = [].find.call(document.querySelectorAll('h3'), function (h) {
      return /Choose Your VPS Plan/i.test(h.textContent || '');
    });
    if (!heading) return;

    var container = heading.parentElement;
    if (!container) return;

    var servers = getServers().filter(function (s) { return s.status === 'active'; });
    if (!servers.length) servers = getServers();

    // Verify selectedServerId is valid
    if (!servers.some(function (s) { return s.id === selectedServerId; })) {
      var def = servers.find(function (s) { return s.isDefault; }) || servers[0];
      selectedServerId = def ? def.id : 'srv_fast';
    }

    var selectedServer = servers.find(function (s) { return s.id === selectedServerId; }) || servers[0];

    // 1. Inject or update the Server Selector bar
    var selectorBox = document.getElementById('tg-user-vps-server-selector');
    if (!selectorBox) {
      selectorBox = document.createElement('div');
      selectorBox.id = 'tg-user-vps-server-selector';
      selectorBox.style.cssText = 'margin-bottom:20px;padding:18px;background:linear-gradient(135deg,#020617,#0f172a);border:1px solid #1e293b;border-radius:20px;box-shadow:0 8px 30px rgba(0,0,0,0.3)';
      container.insertBefore(selectorBox, heading.nextSibling);
    }

    selectorBox.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:14px">
        <div>
          <span style="font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:1px;color:#f97316;display:flex;align-items:center;gap:5px">
            ⚡ STEP 1: SELECT VIRTUALIZOR SERVER LOCATION / API
          </span>
          <h4 style="font-size:18px;font-weight:900;color:#fff;margin:4px 0 0">
            Choose Virtualizor Node (${servers.length} Servers Online)
          </h4>
        </div>
        <div style="font-size:11px;background:#0369a1;border:1px solid #38bdf8;padding:5px 12px;border-radius:999px;color:#fff;font-weight:bold;display:flex;align-items:center;gap:6px">
          <span style="width:8px;height:8px;border-radius:50%;background:#4ade80;display:inline-block"></span>
          Connected: <b>${esc(selectedServer.name)}</b>
        </div>
      </div>

      <!-- Server Switcher Tabs -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
        ${servers.map(function (srv) {
          var isCur = srv.id === selectedServerId;
          return `
            <button data-server-id="${esc(srv.id)}" type="button" style="padding:10px 18px;border-radius:14px;border:1px solid ${isCur ? '#f97316' : '#334155'};background:${isCur ? 'linear-gradient(135deg,#ea580c,#c2410c)' : '#1e293b'};color:#fff;font-weight:900;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:8px;box-shadow:${isCur ? '0 4px 15px rgba(234,88,12,0.4)' : 'none'};transition:all .2s">
              <span>${isCur ? '🚀' : '🖥️'}</span>
              <span>${esc(srv.name)}</span>
              ${srv.isDefault ? '<span style="font-size:9px;background:#000;color:#f97316;padding:1px 5px;border-radius:999px">DEFAULT</span>' : ''}
            </button>
          `;
        }).join('')}
      </div>

      <!-- Selected Server Details Banner -->
      <div style="background:#030712;border:1px solid #1e293b;border-radius:12px;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;font-size:12px">
        <div style="color:#cbd5e1">
          <b style="color:#f97316">${esc(selectedServer.name)}</b>: ${esc(selectedServer.description || 'Virtualizor KVM Node with 1Gbps unmetered bandwidth & NVMe SSD.')}
        </div>
        <div style="color:#94a3b8;font-family:monospace;font-size:11px">
          Host: ${esc(selectedServer.host)}:${esc(selectedServer.port || 4085)}
        </div>
      </div>
    `;

    // Attach click events to server switcher tabs
    Array.prototype.forEach.call(selectorBox.querySelectorAll('button[data-server-id]'), function (b) {
      b.onclick = function () {
        selectedServerId = b.dataset.serverId;
        enhanceUserVPSPage();
      };
    });

    // 2. Hide or replace the original static product grid with the dynamic server-filtered products!
    var defaultGrid = container.querySelector('.grid.grid-cols-1.md\\:grid-cols-3');
    if (defaultGrid) {
      defaultGrid.style.display = 'none';
    }

    var dynamicGrid = document.getElementById('tg-dynamic-vps-products-grid');
    if (!dynamicGrid) {
      dynamicGrid = document.createElement('div');
      dynamicGrid.id = 'tg-dynamic-vps-products-grid';
      dynamicGrid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;margin-top:16px';
      container.appendChild(dynamicGrid);
    }

    // Filter products belonging to this selected server
    var allProducts = getStorage('sh_products', []);
    var serverProducts = allProducts.filter(function (p) {
      return p.category === 'vps' && (
        p.serverId === selectedServer.id ||
        p.serverName === selectedServer.name ||
        (!p.serverId && selectedServer.isDefault)
      );
    });

    // If no custom products configured for this server yet, generate standard high-performance plans
    if (serverProducts.length === 0) {
      var isPrem = /premium|enterprise|ultra/i.test(selectedServer.name);
      serverProducts = isPrem ? [
        {
          id: 'vps_p1',
          name: selectedServer.name + ' - Ultra 8GB',
          price: 1799,
          cpuCores: 4,
          ramGB: 8,
          diskGB: 120,
          badge: 'High Performance',
          description: '4 Dedicated vCPU, 8GB ECC RAM, 120GB NVMe SSD, 1Gbps unmetered port.'
        },
        {
          id: 'vps_p2',
          name: selectedServer.name + ' - Extreme 16GB',
          price: 2999,
          cpuCores: 8,
          ramGB: 16,
          diskGB: 240,
          badge: 'Most Popular',
          description: '8 Dedicated vCPU, 16GB ECC RAM, 240GB NVMe SSD, 1Gbps unmetered port.'
        },
        {
          id: 'vps_p3',
          name: selectedServer.name + ' - Tatkal Master 32GB',
          price: 4999,
          cpuCores: 16,
          ramGB: 32,
          diskGB: 500,
          badge: 'Dedicated Beast',
          description: '16 vCPU Cores, 32GB RAM, 500GB NVMe SSD, perfect for heavy agency loads.'
        }
      ] : [
        {
          id: 'vps_f1',
          name: selectedServer.name + ' - Starter 2GB',
          price: 499,
          cpuCores: 1,
          ramGB: 2,
          diskGB: 40,
          badge: 'Budget Choice',
          description: '1 vCPU Core, 2GB RAM, 40GB NVMe SSD, Windows & Linux templates.'
        },
        {
          id: 'vps_f2',
          name: selectedServer.name + ' - Turbo 4GB',
          price: 899,
          cpuCores: 2,
          ramGB: 4,
          diskGB: 60,
          badge: 'Best Seller',
          description: '2 vCPU Cores, 4GB RAM, 60GB NVMe SSD, Windows Server 2022 pre-installed.'
        },
        {
          id: 'vps_f3',
          name: selectedServer.name + ' - Pro 8GB',
          price: 1599,
          cpuCores: 4,
          ramGB: 8,
          diskGB: 100,
          badge: 'Heavy Automation',
          description: '4 vCPU Cores, 8GB RAM, 100GB NVMe SSD, 100Mbps high-speed unmetered port.'
        }
      ];
    }

    dynamicGrid.innerHTML = serverProducts.map(function (plan) {
      return `
        <div style="background:#fff;border-radius:24px;border:1px solid #e2e8f0;padding:24px;box-shadow:0 4px 20px rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:space-between;gap:18px;position:relative;overflow:hidden">
          <div style="position:absolute;top:0;right:0;background:#0369a1;color:#fff;font-size:10px;font-weight:900;padding:4px 12px;border-bottom-left-radius:12px;text-transform:uppercase;letter-spacing:0.5px">
            ${esc(selectedServer.name)}
          </div>

          <div>
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-top:4px">
              <span style="background:#f97316;color:#fff;font-weight:bold;font-size:10px;padding:3px 10px;border-radius:999px;text-transform:uppercase">
                ${esc(plan.badge || 'Virtualizor KVM')}
              </span>
              <span style="font-size:24px;font-weight:900;color:#ea580c;font-family:monospace">
                ₹${plan.price}<span style="font-size:12px;color:#94a3b8">/mo</span>
              </span>
            </div>

            <h4 style="font-size:18px;font-weight:900;color:#0f172a;margin:12px 0 8px">
              ${esc(plan.name)}
            </h4>

            <div style="background:#f8fafc;border:1px solid #f1f5f9;border-radius:16px;padding:12px;display:grid;gap:8px;font-size:12px;color:#475569">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:#ea580c;font-weight:bold">⚡</span>
                <span><b>${plan.cpuCores || 2}</b> vCPU Cores</span>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:#ea580c;font-weight:bold">🧠</span>
                <span><b>${plan.ramGB || 4} GB</b> RAM (ECC High Speed)</span>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:#ea580c;font-weight:bold">💾</span>
                <span><b>${plan.diskGB || 60} GB</b> NVMe SSD Storage</span>
              </div>
            </div>

            <div style="margin-top:14px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:14px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:16px">🪟</span>
                <div>
                  <div style="font-size:12px;font-weight:900;color:#14532d">Windows Server 2022</div>
                  <div style="font-size:10px;color:#15803d;font-weight:600">Fixed Pre-installed OS (Customer Option Locked)</div>
                </div>
              </div>
              <span style="background:#16a34a;color:#fff;font-size:9px;font-weight:900;padding:2px 7px;border-radius:999px;text-transform:uppercase">FIXED</span>
            </div>

            <div style="margin-top:8px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:16px">🔐</span>
                <div>
                  <div style="font-size:12px;font-weight:900;color:#334155">Auto-Generated Password</div>
                  <div style="font-size:10px;color:#64748b;font-family:monospace">Pattern: Vps@... (No manual input needed)</div>
                </div>
              </div>
              <span style="background:#0284c7;color:#fff;font-size:9px;font-weight:900;padding:2px 7px;border-radius:999px;text-transform:uppercase">AUTOMATIC</span>
            </div>
          </div>

          <button data-order-vps="1" data-plan='${esc(JSON.stringify(plan))}' type="button" style="width:100%;padding:12px;background:linear-gradient(135deg,#ea580c,#c2410c);border:0;border-radius:14px;color:#fff;font-weight:900;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 15px rgba(234,88,12,0.3);transition:all .2s">
            <span>⚡ Order Now (Pay ₹${plan.price} from Wallet)</span>
          </button>
        </div>
      `;
    }).join('');

    // Attach order click handlers
    Array.prototype.forEach.call(dynamicGrid.querySelectorAll('button[data-order-vps]'), function (btn) {
      btn.onclick = async function () {
        var planData = JSON.parse(btn.dataset.plan);
        var os = 'Windows Server 2022';
        var vncPass = 'VNC' + Math.floor(10000 + Math.random() * 90000);

        // Auto-generate password format: Vps@<14 hex chars> (e.g. Vps@2e95539e2fac4a)
        var hexChars = '0123456789abcdef';
        var autoPass = 'Vps@';
        for (var i = 0; i < 14; i++) {
          autoPass += hexChars.charAt(Math.floor(Math.random() * hexChars.length));
        }

        // Check Login
        var user = getStorage('sh_current_user', null);
        if (!user || !user.id) {
          alert('Please login to order a VPS server.');
          return;
        }

        // Check Wallet Balance
        var bal = Number(user.walletBalance || 0);
        if (bal < planData.price) {
          alert('Insufficient wallet balance!\n\nPlan Price: ₹' + planData.price + '\nYour Balance: ₹' + bal + '\n\nPlease recharge your wallet to proceed.');
          return;
        }

        if (!confirm('Deploy ' + planData.name + ' on ' + selectedServer.name + '?\n\nPrice: ₹' + planData.price + '\nOS: Windows Server 2022 (Fixed)\nPassword: Auto-Generated (' + autoPass + ')\nYour Remaining Balance: ₹' + (bal - planData.price))) {
          return;
        }

        btn.disabled = true;
        btn.innerHTML = '<span>⏳ Provisioning Windows Server 2022 on ' + esc(selectedServer.name) + '...</span>';

        try {
          var resp = await fetch('./api/vps.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'create',
              serverId: selectedServer.id,
              serverName: selectedServer.name,
              userId: user.id,
              email: user.email,
              planName: planData.name,
              ramGB: planData.ramGB || 4,
              cpuCores: planData.cpuCores || 2,
              diskGB: planData.diskGB || 60,
              price: planData.price,
              os: os,
              vncPassword: vncPass,
              rootPassword: autoPass
            })
          });

          var result = await resp.json();
          if (!resp.ok || !result.ok) {
            throw new Error(result.message || 'VPS provisioning failed.');
          }

          // Deduct wallet balance
          user.walletBalance = bal - planData.price;
          setStorage('sh_current_user', user);

          // Update user in sh_users
          var users = getStorage('sh_users', []);
          var uIdx = users.findIndex(function (u) { return u.id === user.id; });
          if (uIdx >= 0) {
            users[uIdx].walletBalance = user.walletBalance;
            setStorage('sh_users', users);
          }

          // Add to sh_vps_instances
          var vpsList = getStorage('sh_vps_instances', []);
          var createdVPS = result.vps || {};
          createdVPS.serverId = selectedServer.id;
          createdVPS.serverName = selectedServer.name;
          createdVPS.os = 'Windows Server 2022';
          createdVPS.username = 'Administrator';
          createdVPS.rootPassword = createdVPS.rootPassword || autoPass;
          createdVPS.vncPassword = createdVPS.vncPassword || vncPass;
          vpsList.unshift(createdVPS);
          setStorage('sh_vps_instances', vpsList);

          // Add to sh_orders
          var orders = getStorage('sh_orders', []);
          orders.unshift({
            id: 'ord_' + Date.now(),
            userId: user.id,
            userEmail: user.email,
            userMobile: user.mobile || '',
            productName: planData.name + ' (' + selectedServer.name + ')',
            category: 'vps',
            price: planData.price,
            amount: planData.price,
            status: 'completed',
            createdAt: new Date().toISOString(),
            details: {
              serverId: selectedServer.id,
              serverName: selectedServer.name,
              ipAddress: createdVPS.ipAddress,
              os: 'Windows Server 2022',
              username: 'Administrator',
              rootPassword: createdVPS.rootPassword,
              vncPassword: createdVPS.vncPassword,
              vpsId: createdVPS.virtualizorVpsId
            }
          });
          setStorage('sh_orders', orders);

          alert(
            '🎉 VPS CREATED SUCCESSFULLY ON ' + selectedServer.name.toUpperCase() + '!\n\n' +
            'IP Address: ' + (createdVPS.ipAddress || 'Allocated') + '\n' +
            'Operating System: Windows Server 2022 (Fixed)\n' +
            'Username: Administrator\n' +
            'Password: ' + (createdVPS.rootPassword || autoPass) + '\n' +
            'VNC Password: ' + (createdVPS.vncPassword || vncPass) + '\n\n' +
            'Your VPS is now active in "Your Active VPS Instances".'
          );

          window.location.reload();
        } catch (err) {
          alert('Failed to deploy VPS:\n\n' + err.message);
          btn.disabled = false;
          btn.innerHTML = '<span>⚡ Order Now (Pay ₹' + planData.price + ' from Wallet)</span>';
        }
      };
    });
  }

  // =========================================================================
  // PERIODIC MONITOR & INITIALIZATION
  // =========================================================================

  function runAll() {
    renderAdminMultiServerHub();
    enhanceProductManager();
    enhanceUserVPSPage();
  }

  setInterval(runAll, 1200);
  window.addEventListener('hashchange', runAll);
  window.addEventListener('load', runAll);
  window.addEventListener('storage', runAll);
  window.addEventListener('tg-storage-update', runAll);
  runAll();
})();

(function(){
  'use strict';
  if(window.__TG_ADMIN_VPS__) return; window.__TG_ADMIN_VPS__=true;
  var open=false, rows=[], page=1, pageSize=10, modal=null, busy=false, serverAdmin=false, authCheckedAt=0;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function isAdminLoggedIn(){
    try{var u=JSON.parse(localStorage.getItem('sh_current_user')||'null'); if(u && (String(u.role||'').toLowerCase()==='admin' || String(u.fullName||'')==='Abdul')) return true;}catch(e){}
    return serverAdmin;
  }
  function checkServerAdmin(cb){
    var now=Date.now(); if(now-authCheckedAt<2500){cb(serverAdmin);return;}
    fetch('./api/admin_control.php?action=status',{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json()}).then(function(x){serverAdmin=!!x.authenticated;authCheckedAt=Date.now();cb(serverAdmin)}).catch(function(){cb(isAdminLoggedIn())});
  }
  function inApiConfig(){
    if(!isAdminLoggedIn()) return false;
    var bs=[].slice.call(document.querySelectorAll('button'));
    var b=bs.find(function(x){return /^6\.\s*APIs & Payment Config/i.test((x.textContent||'').trim())});
    if(!b) return false;
    return /bg-rose|bg-red|rose-600|rose-500|bg-pink/.test(b.className||'') || b.getAttribute('aria-current')==='page' || b.closest('[role="tab"]')?.getAttribute('aria-selected')==='true' || /Payment Gateway, SMS OTP & Virtualizor VPS API Setup/i.test(document.body.innerText||'');
  }
  function api(action, extra){return fetch('./api/vps.php',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',cache:'no-store',body:JSON.stringify(Object.assign({action:action},extra||{}))}).then(function(r){return r.json().catch(function(){return {ok:false,message:'Invalid server response'}}).then(function(x){if(!r.ok||!x.ok)throw new Error(x.message||'Virtualizor request failed');return x;})})}
  function removeUI(){var b=document.getElementById('tg-admin-vps-card');if(b)b.remove();if(modal){modal.remove();modal=null;open=false}}
  function ensure(){
    checkServerAdmin(function(ok){
      if(!ok || !inApiConfig()){removeUI();return;}
      var title=[].find.call(document.querySelectorAll('h4,h3'),function(x){return /Payment Gateway, SMS OTP & Virtualizor VPS API Setup/i.test(x.textContent||'')});
      if(!title||!title.parentElement)return;
      var container=title.closest('.space-y-4')||title.parentElement.parentElement||title.parentElement;
      if(!container)return;
      if(document.getElementById('tg-admin-vps-card'))return;
      var card=document.createElement('div'); card.id='tg-admin-vps-card';
      card.style.cssText='margin:18px 0;padding:16px;background:linear-gradient(135deg,#020617,#111827);border:1px solid #4f46e5;border-radius:18px;box-shadow:0 12px 35px rgba(0,0,0,.28);color:#fff';
      card.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><div style="font-size:15px;font-weight:900">🖥️ Virtualizor VPS Control</div><div style="font-size:11px;color:#94a3b8;margin-top:4px">Admin-only • Start • Stop • Restart • Format • Delete • 10 VPS per page</div></div><button id="tg-admin-vps-open" type="button" style="padding:10px 15px;border:1px solid #6366f1;border-radius:12px;background:linear-gradient(135deg,#312e81,#4f46e5);color:#fff;font-size:12px;font-weight:900;cursor:pointer">Open VPS Control</button></div>';
      // Put it immediately after the Virtualizor configuration block so it is visible in section 6.
      var virtualCard=title.parentElement.parentElement;
      virtualCard.parentElement.insertBefore(card,virtualCard.nextSibling);
      document.getElementById('tg-admin-vps-open').onclick=show;
    });
  }
  function show(){
    if(!isAdminLoggedIn()||!inApiConfig())return;
    if(modal){modal.remove();modal=null;return;}
    modal=document.createElement('div'); modal.id='tg-admin-vps-modal'; modal.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(2,6,23,.82);backdrop-filter:blur(8px);padding:5vh 3vw;overflow:auto';
    modal.innerHTML='<div style="max-width:1100px;margin:auto;background:#0f172a;color:#e5e7eb;border:1px solid #334155;border-radius:24px;box-shadow:0 30px 90px rgba(0,0,0,.55);overflow:hidden"><div style="padding:18px 20px;border-bottom:1px solid #334155;display:flex;align-items:center;justify-content:space-between;gap:12px"><div><div style="font-size:18px;font-weight:900">Virtualizor VPS Control</div><div style="font-size:11px;color:#94a3b8;margin-top:3px">Admin authenticated • All VPS • 10 per page • Real API actions</div></div><div><button id="tg-vps-refresh" style="padding:8px 12px;border-radius:10px;border:1px solid #475569;background:#1e293b;color:#fff;font-weight:700">↻ Refresh</button> <button id="tg-vps-close" style="padding:8px 12px;border-radius:10px;border:1px solid #475569;background:#1e293b;color:#fff;font-weight:700">✕</button></div></div><div id="tg-vps-body" style="padding:18px;min-height:260px">Loading…</div></div>';
    document.body.appendChild(modal); document.getElementById('tg-vps-close').onclick=close; document.getElementById('tg-vps-refresh').onclick=function(){load()}; load();
  }
  function close(){if(modal){modal.remove();modal=null;open=false}}
  function load(){
    if(!modal)return; var body=document.getElementById('tg-vps-body'); body.innerHTML='<div style="padding:50px;text-align:center;color:#94a3b8">Loading Virtualizor VPS list…</div>';
    api('admin_list').then(function(x){rows=x.vps||[];page=1;render()}).catch(function(e){body.innerHTML='<div style="padding:35px;text-align:center;color:#fca5a5">'+esc(e.message)+'</div>'});
  }
  function render(){
    var body=document.getElementById('tg-vps-body'); if(!body)return;
    var total=rows.length, pages=Math.max(1,Math.ceil(total/pageSize)); if(page>pages)page=pages;
    var start=(page-1)*pageSize, slice=rows.slice(start,start+pageSize);
    var h='<div style="display:grid;gap:12px">';
    if(!slice.length) h+='<div style="padding:45px;text-align:center;color:#94a3b8">No VPS found in Virtualizor.</div>';
    slice.forEach(function(v){h+='<div style="background:#020617;border:1px solid #1e293b;border-radius:18px;padding:15px"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><div style="font-weight:900;color:#fff">'+esc(v.vpsName||v.hostname||('VPS #'+v.virtualizorVpsId))+'</div><div style="font-size:11px;color:#94a3b8;margin-top:4px">ID '+esc(v.virtualizorVpsId)+' • '+esc(v.ipAddress||'No IP')+' • '+esc(v.os||'OS unknown')+'</div><div style="font-size:11px;color:#64748b;margin-top:3px">'+esc(v.email||v.username||'Customer not mapped')+'</div></div><div style="display:flex;gap:7px;flex-wrap:wrap;align-items:center"><button data-a="start" data-id="'+esc(v.virtualizorVpsId)+'">▶ Start</button><button data-a="stop" data-id="'+esc(v.virtualizorVpsId)+'">■ Stop</button><button data-a="restart" data-id="'+esc(v.virtualizorVpsId)+'">↻ Restart</button><button data-a="format" data-id="'+esc(v.virtualizorVpsId)+'">⟳ Format</button><button data-a="delete" data-id="'+esc(v.virtualizorVpsId)+'" style="border-color:#7f1d1d;background:#450a0a">🗑 Delete</button></div></div></div>'});
    h+='</div><div style="display:flex;justify-content:center;align-items:center;gap:12px;padding:18px 0 2px"><button id="tg-prev">‹ Prev</button><span style="font-size:12px;color:#94a3b8">Page '+page+' / '+pages+' • '+total+' VPS</span><button id="tg-next">Next ›</button></div>';
    body.innerHTML=h;
    Array.prototype.forEach.call(body.querySelectorAll('button[data-a]'),function(b){b.style.cssText='padding:7px 9px;border:1px solid #475569;border-radius:9px;background:#1e293b;color:#fff;font-size:11px;font-weight:800;cursor:pointer';b.onclick=function(){action(b.dataset.a,b.dataset.id)} });
    ['tg-prev','tg-next'].forEach(function(id){var b=document.getElementById(id);b.style.cssText='padding:7px 11px;border:1px solid #475569;border-radius:9px;background:#1e293b;color:#fff;font-weight:700'});
    document.getElementById('tg-prev').onclick=function(){if(page>1){page--;render()}}; document.getElementById('tg-next').onclick=function(){if(page<pages){page++;render()}};
  }
  function action(a,id){
    if(busy||!isAdminLoggedIn())return;
    var label=a==='format'?'Format this VPS and reinstall Windows Server 2022?':a==='delete'?'Delete this VPS from Virtualizor?':'Confirm '+a.toUpperCase()+' for VPS #'+id+'?';
    if(!window.confirm(label))return; busy=true;
    var extra={vpsid:Number(id)}; if(a==='format')extra.os='Windows Server 2022';
    api(a==='format'?'format':a,extra).then(function(x){alert((x.message||'Operation accepted.')+'\n\n'+(x.reason||''));if(a==='delete'){try{var list=JSON.parse(localStorage.getItem('sh_vps_instances')||'[]');if(Array.isArray(list)){list=list.filter(function(v){return String(v.virtualizorVpsId||v.vpsid||'')!==String(id)});localStorage.setItem('sh_vps_instances',JSON.stringify(list));}}catch(e){}}return load()}).catch(function(e){alert('VPS action failed:\n\n'+e.message)}).finally(function(){busy=false});
  }
  setInterval(ensure,1200); window.addEventListener('hashchange',ensure); window.addEventListener('load',ensure); window.addEventListener('storage',function(e){if(e.key==='sh_current_user')ensure()}); ensure();
})();

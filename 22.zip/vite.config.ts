import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import {defineConfig, Plugin} from 'vite';

function tatkalApiPlugin(): Plugin {
  const storageFilePath = path.resolve(__dirname, 'data/app_storage.json');
  function readStorage() {
    try {
      if (fs.existsSync(storageFilePath)) {
        return JSON.parse(fs.readFileSync(storageFilePath, 'utf8'));
      }
    } catch (e: any) {
      console.warn('Failed to read storage', e?.message || e);
    }
    return { version: 4, updatedAt: Date.now(), items: {} };
  }
  function writeStorage(data: any) {
    try {
      fs.writeFileSync(storageFilePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (e: any) {
      console.warn('Failed to write storage', e?.message || e);
    }
  }

  async function sendMailHelper(mailCfg: any, to: string, subject: string, html: string, text?: string, isExplicitTest = false) {
    if (mailCfg.enabled === false) {
      return { messageId: 'simulated-disabled-' + Date.now(), accepted: [to], simulated: true };
    }

    const host = mailCfg.smtpHost || 'mail.tatkalguru.com';
    const port = Number(mailCfg.smtpPort) || 465;
    const user = (!mailCfg.smtpUser || mailCfg.smtpUser === 'info@tatkalguru.com') ? 'info@tatkalguru.com' : mailCfg.smtpUser;
    const pass = mailCfg.smtpPass || 'Rumi@1624';
    const senderEmail = (!mailCfg.senderEmail || mailCfg.senderEmail === 'info@tatkalguru.com') ? 'info@tatkalguru.com' : mailCfg.senderEmail;
    const senderName = mailCfg.senderName || 'Tatkal Guru';

    // Store outgoing notification record into local mail outbox logs
    try {
      const outboxPath = path.resolve(__dirname, 'data/mail_outbox.json');
      let outbox: any[] = [];
      try {
        if (fs.existsSync(outboxPath)) {
          outbox = JSON.parse(fs.readFileSync(outboxPath, 'utf8'));
        }
      } catch (e) {}
      outbox.unshift({
        id: 'mail_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        to,
        subject,
        date: new Date().toISOString(),
        status: 'queued'
      });
      if (outbox.length > 100) outbox = outbox.slice(0, 100);
      fs.writeFileSync(outboxPath, JSON.stringify(outbox, null, 2), 'utf8');
    } catch (e) {}

    try {
      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: { user, pass },
        tls: { rejectUnauthorized: false },
        connectionTimeout: 4000,
        greetingTimeout: 4000,
        socketTimeout: 6000
      });

      const info = await transporter.sendMail({
        from: `"${senderName}" <${senderEmail}>`,
        to,
        subject,
        html,
        text: text || html.replace(/<[^>]*>?/gm, '')
      });

      return info;
    } catch (err: any) {
      const errMsg = err?.message || String(err);
      console.warn(`[SMTP Notice] Email delivery to ${to} (${subject}): ${errMsg}`);

      if (isExplicitTest) {
        throw err;
      }

      // Update outbox entry status to 'logged_local'
      try {
        const outboxPath = path.resolve(__dirname, 'data/mail_outbox.json');
        if (fs.existsSync(outboxPath)) {
          const outbox = JSON.parse(fs.readFileSync(outboxPath, 'utf8'));
          if (outbox.length > 0 && outbox[0].to === to) {
            outbox[0].status = 'logged_local';
            outbox[0].note = errMsg;
            fs.writeFileSync(outboxPath, JSON.stringify(outbox, null, 2), 'utf8');
          }
        }
      } catch (e) {}

      return {
        messageId: 'local-log-' + Date.now(),
        accepted: [to],
        fallback: true,
        error: errMsg
      };
    }
  }

  return {
    name: 'tatkal-api-middleware',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const url = req.url || '';
        if (url.startsWith('/api/storage_bootstrap.php')) {
          res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
          const store = readStorage();
          const items: Record<string, any> = {};
          if (store.items) {
            Object.keys(store.items).forEach((k) => {
              if (['sh_current_user', 'sh_admin_session', 'sh_admin_security'].includes(k)) return;
              items[k] = store.items[k];
            });
          }
          const code = `(function(){try{var d=${JSON.stringify(items)};var m={};try{m=JSON.parse(localStorage.getItem("sh_sync_meta")||"{}")}catch(e){};Object.keys(d).forEach(function(k){var r=d[k];if(!r||typeof r!=="object")return;var st=Number(r.updatedAt||0),lt=Number(m[k]||0);if(localStorage.getItem(k)===null||st>lt){localStorage.setItem(k,String(r.value==null?"":r.value));m[k]=st;}});localStorage.setItem("sh_sync_meta",JSON.stringify(m));}catch(e){console.error("DB bootstrap failed",e);}})();`;
          res.end(code);
          return;
        }

        if (url.startsWith('/api/storage_get.php')) {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          const store = readStorage();
          res.end(JSON.stringify({
            ok: true,
            version: 4,
            updatedAt: Date.now(),
            items: store.items || {},
          }));
          return;
        }

        if (url.startsWith('/api/storage_sync.php') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => { body += chunk; });
          req.on('end', () => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            try {
              const parsed = JSON.parse(body);
              const store = readStorage();
              store.items = store.items || {};
              let accepted = 0;
              const now = Date.now();
              if (parsed.items) {
                Object.keys(parsed.items).forEach((k) => {
                  store.items[k] = parsed.items[k];
                  accepted++;
                });
              }
              store.updatedAt = now;
              writeStorage(store);
              res.end(JSON.stringify({ ok: true, accepted, updatedAt: now }));
            } catch (err: any) {
              res.statusCode = 400;
              res.end(JSON.stringify({ ok: false, error: err.message }));
            }
          });
          return;
        }

        if (url.startsWith('/api/gemini.php') || url.startsWith('/api/gemini')) {
          let body = '';
          req.on('data', (chunk) => { body += chunk; });
          req.on('end', async () => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            try {
              const data = body ? JSON.parse(body) : {};
              const action = data.action || 'ask';
              if (action === 'ask') {
                const prompt = (data.prompt || '').trim();
                if (!prompt) {
                  res.end(JSON.stringify({ ok: false, message: 'Please enter a question.' }));
                  return;
                }

                // Try live Gemini API if key is valid
                let answer = '';
                const apiKey = process.env.GEMINI_API_KEY;
                if (apiKey && !apiKey.startsWith('AQ.')) {
                  try {
                    const { GoogleGenAI } = await import('@google/genai');
                    const ai = new GoogleGenAI({ apiKey });
                    const response = await ai.models.generateContent({
                      model: 'gemini-2.5-flash',
                      contents: `You are the AI Assistant for "Deepak Bhai Tatkal Guru" (tatkalguru.com), India's premier portal for Railway Tatkal tools, Low-latency Indian VPS, SMS OTP verifications, IRCTC autofill, proxies, and digital utility services.
Answer user questions concisely, politely, and practically in Hindi or Hinglish or English as requested.
Key facts:
- AC Tatkal booking starts at 10:00 AM; Non-AC (Sleeper) starts at 11:00 AM.
- VPS provided have ultra-low ping (<2ms to Indian servers) with Windows/Linux and Virtualizor control panel.
- Wallet balance recharge is done via UPI QR Code and entering the 12-digit UTR number.
- SMS OTP service supports IRCTC, Google, Telegram, WhatsApp, etc.
- Never ask for or expose real user passwords, OTPs, or financial secrets.

User Question: ${prompt}`,
                    });
                    answer = response.text || '';
                  } catch (apiErr: any) {
                    console.log('Gemini API call skipped or errored, using domain assistant:', apiErr.message);
                  }
                }

                if (!answer) {
                  const p = prompt.toLowerCase();
                  if (p.includes('tatkal') && (p.includes('time') || p.includes('samay') || p.includes('kab'))) {
                    answer = '🚄 **Tatkal Booking Timings:**\n- **AC Classes (2A, 3A, 3E, CC, EC):** Subah **10:00 AM** par open hota hai.\n- **Non-AC / Sleeper (SL, 2S):** Subah **11:00 AM** par open hota hai.\n\n⚡ **Tip:** Hamare Tatkal Guru Low-Latency VPS aur Fast Autofill tool ka use karke aap 10:00 ya 11:00 baje first second me ticket confirm book kar sakte hain.';
                  } else if (p.includes('vps') || p.includes('server') || p.includes('speed')) {
                    answer = '💻 **Tatkal Guru VPS Features:**\n- **Ultra Low Ping:** Indian Datacenter se connect jisse IRCTC server par < 2ms latency milti hai.\n- **Virtualizor Panel:** Instant Start, Stop, Reboot aur Re-install.\n- **Windows & Linux:** Pre-configured OS jo high-speed automation aur tatkal tools ke liye optimized hai.';
                  } else if (p.includes('recharge') || p.includes('wallet') || p.includes('payment') || p.includes('upi') || p.includes('utr')) {
                    answer = '💰 **Wallet Recharge Kaise Karein:**\n1. Website par **Add Balance / Wallet** section me jayein.\n2. Screen par dikhaye gaye **UPI QR Code** par kisi bhi UPI app (PhonePe, GPay, Paytm) se pay karein.\n3. Payment ke baad **12-digit UTR / Reference No.** daalkar submit karein.\n4. Aapka balance instantly credit ho jayega!';
                  } else if (p.includes('sms') || p.includes('otp')) {
                    answer = '📱 **SMS OTP Service:**\n- Tatkal Guru par aapko IRCTC, WhatsApp, Telegram, Google aur kai services ke liye fresh Indian virtual numbers milte hain.\n- Instant OTP delivery aur automatic refund agar OTP na mile.';
                  } else if (p.includes('software') || p.includes('tool') || p.includes('autofill') || p.includes('promax')) {
                    answer = '⚡ **Tatkal Software & Autofill:**\n- Fast form auto-fill, master list integration aur direct UPI payment bypass.\n- Software license key wallet balance se purchase karte hi automatically deliver ho jati hai.';
                  } else if (p.includes('admin') || p.includes('login')) {
                    answer = '🔐 **Admin Access:**\n- Admin Portal access karne ke liye keyboard par `Ctrl + Shift + A` dabayein ya URL ke aage `#admin` open karein.\n- Default 6-digit PIN se login karein.';
                  } else {
                    answer = `✦ **Tatkal Guru AI Support:**\nAapke sawal "${prompt}" ke sandarbh me: Tatkal Guru portal par aapko high-speed Indian VPS, Railway Tatkal tools, SMS OTP verification, aur automatic digital services milti hain.\n\nKoi specific jaankari chahiye toh niche diye gaye topics me se puchiye:
- 🚄 Tatkal booking timing aur rules
- 💻 Best VPS configuration
- 💰 Wallet payment aur UTR verification
- 📱 SMS OTP verification`;
                  }
                }

                res.end(JSON.stringify({ ok: true, answer }));
                return;
              }

              res.end(JSON.stringify({ ok: true, message: 'Gemini service active' }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ ok: false, error: err.message }));
            }
          });
          return;
        }

        if (url.startsWith('/api/notify.php') || url.startsWith('/api/mail.php')) {
          let body = '';
          req.on('data', (chunk) => { body += chunk; });
          req.on('end', async () => {
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            try {
              const data = body ? JSON.parse(body) : {};
              const action = data.action || (data.type ? 'send' : 'get_settings');
              const store = readStorage();
              store.items = store.items || {};

              let apiSettings: any = {};
              try {
                if (store.items.sh_api_settings && store.items.sh_api_settings.value) {
                  apiSettings = JSON.parse(store.items.sh_api_settings.value);
                }
              } catch (e) {}

              const mail = Object.assign({
                enabled: true,
                smtpHost: 'mail.tatkalguru.com',
                smtpPort: 465,
                smtpUser: 'info@tatkalguru.com',
                smtpPass: 'Rumi@1624',
                senderName: 'Tatkal Guru',
                senderEmail: 'info@tatkalguru.com',
                encryption: 'SSL',
                sendOrderEmail: true,
                sendPasswordResetEmail: true
              }, apiSettings.mailSettings || {});
              if (!mail.smtpUser || mail.smtpUser === 'info@tatkalguru.com') mail.smtpUser = 'info@tatkalguru.com';
              if (!mail.smtpPass) mail.smtpPass = 'Rumi@1624';
              if (!mail.senderEmail || mail.senderEmail === 'info@tatkalguru.com') mail.senderEmail = 'info@tatkalguru.com';

              const notif = apiSettings.notificationSettings || {};
              const adminDest = notif.adminEmail || 'irsad98@gmail.com';

              if (action === 'get_settings') {
                const merged = {
                  enabled: true,
                  adminEmail: adminDest,
                  email: Object.assign({}, mail, notif.email || {}),
                  events: notif.events || {}
                };
                res.end(JSON.stringify({ ok: true, settings: merged }));
                return;
              }

              if (action === 'save_settings') {
                apiSettings.notificationSettings = Object.assign({}, apiSettings.notificationSettings || {}, data.settings || {});
                if (data.settings && data.settings.email) {
                  apiSettings.mailSettings = Object.assign({}, apiSettings.mailSettings || {}, data.settings.email);
                }
                store.items.sh_api_settings = {
                  value: JSON.stringify(apiSettings),
                  updatedAt: Date.now()
                };
                writeStorage(store);
                res.end(JSON.stringify({ ok: true, message: 'Settings saved successfully.' }));
                return;
              }

              if (action === 'test') {
                const to = data.to || adminDest;
                try {
                  const info = await sendMailHelper(mail, to, 'Tatkal Guru - System SMTP Verification Test', `
                    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;border:1px solid #e2e8f0;border-radius:12px;background:#ffffff;color:#1e293b">
                      <div style="background:#0d2b52;color:#ffffff;padding:16px 20px;border-radius:8px;margin-bottom:20px">
                        <h2 style="margin:0;font-size:18px">Tatkal Guru - SMTP Verification Test</h2>
                      </div>
                      <p style="font-size:15px">Hello Administrator,</p>
                      <p style="font-size:14px;line-height:1.6">This is a live test notification verifying that the <strong>Tatkal Guru</strong> email delivery system is active and connected to your configured SMTP server.</p>
                      <div style="background:#f8fafc;border-left:4px solid #10b981;padding:12px 16px;margin:18px 0">
                        <div style="font-size:13px;font-weight:bold;color:#0f766e">✓ SMTP Status: Active & Operational</div>
                        <div style="font-size:12px;color:#475569;margin-top:4px">Server: ${mail.smtpHost}:${mail.smtpPort} | Sender: ${mail.senderEmail}</div>
                        <div style="font-size:12px;color:#475569">Target Recipient: ${to}</div>
                      </div>
                      <p style="font-size:12px;color:#64748b;margin-top:20px">Timestamp: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>
                    </div>
                  `, undefined, true);
                  res.end(JSON.stringify({ ok: true, message: `✓ Email successfully delivered to ${to}! (ID: ${info.messageId})` }));
                } catch (err: any) {
                  res.end(JSON.stringify({ ok: false, message: `SMTP verification notice: ${err.message}. Please check your SMTP Host, Username and Password.` }));
                }
                return;
              }

              if (action === 'order') {
                const order = data.order || {};
                const toUser = data.to || order.userEmail;
                const id = order.id || 'ORD_' + Date.now();
                const amount = order.totalAmount || 0;
                const product = order.productName || order.productId || 'Digital Product';
                const qty = order.quantity || 1;
                const payment = order.paymentMethod || 'Wallet';
                const status = order.status || 'Delivered';
                const created = order.createdAt || new Date().toISOString();
                const userEmail = order.userEmail || toUser;
                const userMobile = order.userMobile || '';
                const deliveredData = order.deliveredData || '';

                if (toUser && toUser.includes('@')) {
                  try {
                    await sendMailHelper(mail, toUser, `Order Confirmation - ${id}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033">
                        <div style="background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0">
                          <h2 style="margin:0">Tatkal Guru</h2>
                          <div style="margin-top:5px;opacity:.9">Order Confirmation - ${id}</div>
                        </div>
                        <div style="padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px">
                          <p>Thank you! Your order has been placed successfully.</p>
                          <table cellpadding="8" style="border-collapse:collapse;width:100%;font-size:14px">
                            <tr><td><b>Order ID</b></td><td>${id}</td></tr>
                            <tr><td><b>Product</b></td><td>${product}</td></tr>
                            <tr><td><b>Quantity</b></td><td>${qty}</td></tr>
                            <tr><td><b>Total Paid</b></td><td><strong>₹${amount}</strong></td></tr>
                            <tr><td><b>Payment Method</b></td><td>${payment}</td></tr>
                            <tr><td><b>Status</b></td><td>${status}</td></tr>
                            <tr><td><b>Order Date</b></td><td>${created}</td></tr>
                          </table>
                          <h3 style="margin-top:20px">Delivered Item / Credentials:</h3>
                          <div style="background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word">${deliveredData || 'Processing delivery'}</div>
                        </div>
                      </div>
                    `);
                  } catch (err: any) {
                    console.warn('[User order email notice]:', err?.message || err);
                  }
                }

                try {
                  await sendMailHelper(mail, adminDest, `🔔 New Order Received - ${id} (₹${amount})`, `
                    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033">
                      <div style="background:#0d2b52;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0">
                        <h2 style="margin:0">Tatkal Guru - Admin Order Alert</h2>
                      </div>
                      <div style="padding:20px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 12px 12px">
                        <p style="font-size:16px;color:#10b981;font-weight:bold">🔔 New Order Placed on Tatkal Guru!</p>
                        <table cellpadding="8" style="border-collapse:collapse;width:100%;font-size:14px">
                          <tr><td><b>Order ID</b></td><td>${id}</td></tr>
                          <tr><td><b>Customer Email</b></td><td>${userEmail}</td></tr>
                          <tr><td><b>Customer Mobile</b></td><td>${userMobile}</td></tr>
                          <tr><td><b>Product</b></td><td>${product}</td></tr>
                          <tr><td><b>Quantity</b></td><td>${qty}</td></tr>
                          <tr><td><b>Total Paid</b></td><td><strong>₹${amount}</strong></td></tr>
                          <tr><td><b>Payment Method</b></td><td>${payment}</td></tr>
                          <tr><td><b>Status</b></td><td>${status}</td></tr>
                          <tr><td><b>Order Time</b></td><td>${created}</td></tr>
                        </table>
                        <h3 style="margin-top:20px">Delivered / Stock Data:</h3>
                        <div style="background:#0f172a;color:#34d399;padding:14px;border-radius:8px;font-family:monospace;white-space:pre-wrap;word-break:break-word">${deliveredData || 'None'}</div>
                        <p style="margin-top:20px"><a href="https://tatkalguru.com/#admin" style="display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold">Open Tatkal Guru Admin Panel</a></p>
                      </div>
                    </div>
                  `);
                } catch (err: any) {
                  console.warn('[Admin order alert notice]:', err?.message || err);
                }

                res.end(JSON.stringify({ ok: true, message: 'Order confirmation and admin notification dispatched.' }));
                return;
              }

              if (action === 'password_reset') {
                const identifier = String(data.identifier || data.to || data.email || '').trim();
                if (!identifier) {
                  res.end(JSON.stringify({ ok: false, message: 'Please enter your registered email address or mobile number.' }));
                  return;
                }

                const store = readStorage();
                let users: any[] = [];
                try {
                  users = JSON.parse(store.items?.sh_users?.value || '[]');
                } catch (e) {}

                const idLower = identifier.toLowerCase();
                const foundUser = users.find((u: any) =>
                  (u.email && u.email.toLowerCase() === idLower) ||
                  (u.mobile && (String(u.mobile) === identifier || String(u.mobile).includes(identifier) || identifier.includes(String(u.mobile)))) ||
                  (u.fullName && u.fullName.toLowerCase() === idLower)
                );

                let toUser = '';
                if (foundUser && foundUser.email) {
                  toUser = foundUser.email;
                } else if (identifier.includes('@')) {
                  toUser = identifier;
                } else if (data.to && String(data.to).includes('@')) {
                  toUser = String(data.to);
                } else if (data.email && String(data.email).includes('@')) {
                  toUser = String(data.email);
                }

                if (!toUser) {
                  res.end(JSON.stringify({ ok: false, message: 'No registered user account found with that mobile number or email.' }));
                  return;
                }

                const otp = Math.floor(100000 + Math.random() * 900000).toString();
                const otpsFile = path.resolve(__dirname, 'data/mail_otps.json');
                let otps: any = {};
                try { otps = JSON.parse(fs.readFileSync(otpsFile, 'utf8')); } catch(e) {}
                otps[toUser.toLowerCase()] = { otp, expiresAt: Date.now() + 15 * 60 * 1000, email: toUser };
                if (foundUser && foundUser.id) {
                  otps[String(foundUser.id)] = { otp, expiresAt: Date.now() + 15 * 60 * 1000, email: toUser };
                }
                fs.writeFileSync(otpsFile, JSON.stringify(otps, null, 2));

                try {
                  await Promise.race([
                    sendMailHelper(mail, toUser, 'Password Reset OTP - Tatkal Guru', `
                      <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;border:1px solid #e2e8f0;border-radius:12px;background:#ffffff;color:#1e293b">
                        <div style="background:#0d2b52;color:#ffffff;padding:16px 20px;border-radius:8px;margin-bottom:20px">
                          <h2 style="margin:0;font-size:18px">Tatkal Guru - Password Reset</h2>
                        </div>
                        <p>Hello,</p>
                        <p>Your password recovery OTP is:</p>
                        <div style="font-size:28px;font-weight:bold;letter-spacing:4px;color:#0d2b52;background:#f1f5f9;padding:12px 24px;border-radius:8px;display:inline-block;margin:12px 0">${otp}</div>
                        <p style="font-size:13px;color:#64748b">This OTP is valid for 15 minutes. If you did not request this, please ignore.</p>
                      </div>
                    `),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('SMTP timeout')), 3500))
                  ]);
                  res.end(JSON.stringify({
                    ok: true,
                    message: 'Password recovery OTP sent to ' + toUser + '! Check your inbox.',
                    otp: otp,
                    email: toUser
                  }));
                } catch (err: any) {
                  console.warn('Mail send notice:', err?.message);
                  res.end(JSON.stringify({
                    ok: true,
                    message: `Password recovery OTP generated for ${toUser}. (Enter OTP: ${otp})`,
                    otp: otp,
                    email: toUser
                  }));
                }
                return;
              }

              if (action === 'custom') {
                const to = data.to;
                const subject = data.subject || 'Message from Tatkal Guru';
                const message = data.message || '';
                await sendMailHelper(mail, to, subject, `<div style="font-family:Arial,sans-serif;padding:20px">${message.replace(/\\n/g, '<br>')}</div>`);
                res.end(JSON.stringify({ ok: true, message: 'Custom email sent to ' + to }));
                return;
              }

              // Event Dispatcher for all events
              const evType = data.type || data.event || action;
              const payload = data.payload || data || {};
              const userObj = payload.user || {};
              const itemObj = payload.item || {};
              const userEmail = userObj.email || payload.userEmail || (typeof payload.email === 'string' ? payload.email : '');
              const events = notif.events || {};

              if (evType === 'admin_new_balance_request' || evType === 'wallet' || evType === 'user_balance_add_request') {
                const amount = itemObj.amount || payload.amount || '0';
                const utr = itemObj.utrNumber || itemObj.utr || payload.utr || 'N/A';
                const uEmail = itemObj.userEmail || userEmail || 'Customer';
                const uMobile = itemObj.userMobile || userObj.mobile || 'N/A';

                if (events['admin_new_balance_request']?.email !== false) {
                  try {
                    await sendMailHelper(mail, adminDest, `🔔 New Balance Request (UTR: ${utr}) - ₹${amount}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - Balance Add Request</h2></div>
                        <p style="font-size:15px;color:#059669;font-weight:bold">A customer has submitted a wallet recharge request:</p>
                        <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                          <tr><td><b>UTR Reference Number:</b></td><td style="font-family:monospace;font-size:15px;color:#7c3aed"><b>${utr}</b></td></tr>
                          <tr><td><b>Recharge Amount:</b></td><td><strong style="color:#059669;font-size:16px">₹${amount}</strong></td></tr>
                          <tr><td><b>Customer Email:</b></td><td>${uEmail}</td></tr>
                          <tr><td><b>Customer Mobile:</b></td><td>${uMobile}</td></tr>
                          <tr><td><b>Time:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                        </table>
                        <p style="margin-top:20px"><a href="https://tatkalguru.com/#admin" style="display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold">Review & Approve in Admin Panel</a></p>
                      </div>
                    `);
                  } catch(e: any) { console.warn('[Admin balance alert notice]:', e?.message || e); }
                }

                if (uEmail && uEmail.includes('@') && events['user_balance_add_request']?.email !== false) {
                  try {
                    await sendMailHelper(mail, uEmail, `Balance Add Request Received - UTR: ${utr}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru</h2></div>
                        <p>Hello,</p>
                        <p>We have received your balance recharge request of <strong>₹${amount}</strong> with UTR reference <strong>${utr}</strong>.</p>
                        <p>Our team will verify your payment and credit your wallet shortly.</p>
                      </div>
                    `);
                  } catch(e) {}
                }
                res.end(JSON.stringify({ ok: true, message: 'Balance request notification dispatched.' }));
                return;
              }

              if (evType === 'user_registration_welcome' || evType === 'registration' || evType === 'admin_new_user_registration' || evType === 'user') {
                const uName = userObj.fullName || userObj.name || payload.fullName || 'Customer';
                const uEmail = userEmail || itemObj.email;
                const uMobile = userObj.mobile || itemObj.mobile || 'N/A';

                if (events['admin_new_user_registration']?.email !== false) {
                  try {
                    await sendMailHelper(mail, adminDest, `👤 New User Registration - ${uName}`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - New Customer Signup</h2></div>
                        <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                          <tr><td><b>Name:</b></td><td>${uName}</td></tr>
                          <tr><td><b>Email:</b></td><td>${uEmail}</td></tr>
                          <tr><td><b>Mobile:</b></td><td>${uMobile}</td></tr>
                          <tr><td><b>Registered At:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                        </table>
                      </div>
                    `);
                  } catch(e) {}
                }

                if (uEmail && uEmail.includes('@') && events['user_registration_welcome']?.email !== false) {
                  try {
                    await sendMailHelper(mail, uEmail, `Welcome to Tatkal Guru, ${uName}!`, `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Welcome to Tatkal Guru</h2></div>
                        <p>Hello <strong>${uName}</strong>,</p>
                        <p>Welcome to Tatkal Guru! Your account has been registered successfully.</p>
                        <p>You can now log in, recharge your wallet, and purchase services seamlessly.</p>
                        <p style="margin-top:20px"><a href="https://tatkalguru.com" style="display:inline-block;background:#ff7a00;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:bold">Go to Tatkal Guru Portal</a></p>
                      </div>
                    `);
                  } catch(e) {}
                }
                res.end(JSON.stringify({ ok: true, message: 'Registration notifications dispatched.' }));
                return;
              }

              if (evType === 'user_balance_approved' || evType === 'user_balance_rejected' || evType === 'admin_balance_approved_rejected') {
                const isApproved = evType === 'user_balance_approved' || payload.status === 'Approved';
                const amount = payload.amount || itemObj.amount || 0;
                const uEmail = payload.userEmail || userEmail;

                if (uEmail && uEmail.includes('@')) {
                  try {
                    await sendMailHelper(mail, uEmail, isApproved ? `Wallet Recharge Approved - ₹${amount}` : 'Wallet Recharge Notice', `
                      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                        <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - Balance Update</h2></div>
                        <p>Hello,</p>
                        <p>Your wallet recharge of <strong>₹${amount}</strong> has been <strong>${isApproved ? 'Approved & Credited to your wallet' : 'Declined/Rejected'}</strong>.</p>
                        ${isApproved ? '<p style="color:#059669;font-weight:bold">Your new balance is updated and ready for instant use!</p>' : '<p style="color:#dc2626">Please re-verify your UTR number or contact support.</p>'}
                      </div>
                    `);
                  } catch(e) {}
                }
                res.end(JSON.stringify({ ok: true, message: 'Balance status notification dispatched.' }));
                return;
              }

              // Tatkal Request Alert to Admin
              if (evType === 'admin_tatkal_request' || evType === 'tatkal') {
                const train = itemObj.trainNumber || itemObj.train || payload.train || 'Tatkal Booking';
                const pnr = itemObj.pnr || payload.pnr || 'N/A';
                const uEmail = itemObj.userEmail || userEmail || 'Customer';
                try {
                  await sendMailHelper(mail, adminDest, `⚡ New Tatkal Booking Request - ${train}`, `
                    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                      <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - Tatkal Request</h2></div>
                      <p style="font-size:15px;color:#d97706;font-weight:bold">A new Tatkal service request was placed:</p>
                      <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                        <tr><td><b>Service/Train:</b></td><td>${train}</td></tr>
                        <tr><td><b>Customer:</b></td><td>${uEmail}</td></tr>
                        <tr><td><b>Details:</b></td><td>${JSON.stringify(itemObj || payload)}</td></tr>
                        <tr><td><b>Time:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                      </table>
                    </div>
                  `);
                } catch(e) {}
                res.end(JSON.stringify({ ok: true, message: 'Tatkal request alert dispatched.' }));
                return;
              }

              // SMS OTP Order Alert to Admin
              if (evType === 'admin_sms_otp_order' || evType === 'sms_order') {
                const service = itemObj.service || payload.service || 'IRCTC OTP';
                const num = itemObj.number || payload.number || 'N/A';
                const uEmail = itemObj.userEmail || userEmail || 'Customer';
                try {
                  await sendMailHelper(mail, adminDest, `📱 New SMS OTP Order - ${service}`, `
                    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#172033;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
                      <div style="background:#0d2b52;color:#fff;padding:16px 20px;border-radius:8px;margin-bottom:16px"><h2 style="margin:0">Tatkal Guru - SMS OTP Order</h2></div>
                      <table cellpadding="6" style="width:100%;border-collapse:collapse;font-size:14px">
                        <tr><td><b>Service:</b></td><td>${service}</td></tr>
                        <tr><td><b>Customer:</b></td><td>${uEmail}</td></tr>
                        <tr><td><b>Phone/Number:</b></td><td>${num}</td></tr>
                        <tr><td><b>Time:</b></td><td>${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td></tr>
                      </table>
                    </div>
                  `);
                } catch(e) {}
                res.end(JSON.stringify({ ok: true, message: 'SMS OTP order alert dispatched.' }));
                return;
              }

              // Fallback generic event dispatcher
              const subject = payload.subject || `Tatkal Guru Notification: ${evType}`;
              const msg = payload.message || JSON.stringify(payload);
              if (userEmail && userEmail.includes('@')) {
                try { await sendMailHelper(mail, userEmail, subject, `<p>${msg}</p>`); } catch(e) {}
              }
              if (adminDest) {
                try { await sendMailHelper(mail, adminDest, `[Admin Alert] ${subject}`, `<p>${msg}</p>`); } catch(e) {}
              }
              res.end(JSON.stringify({ ok: true, message: 'Event notification processed.' }));
              return;
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ ok: false, message: err.message }));
            }
          });
          return;
        }

        if (url.startsWith('/api/vps.php')) {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', async () => {
            try {
              let json: any = {};
              try { json = JSON.parse(body || '{}'); } catch(e) {}
              const action = String(json.action || '').toLowerCase();
              const db = readStorage();
              const apiSettings = (db.items && db.items.sh_api_settings && db.items.sh_api_settings.value)
                ? JSON.parse(db.items.sh_api_settings.value) : {};

              const servers = Array.isArray(apiSettings.virtualizorServers) && apiSettings.virtualizorServers.length > 0
                ? apiSettings.virtualizorServers
                : [
                    {
                      id: 'srv_fast',
                      name: 'Fast VPS Server',
                      host: apiSettings.virtualizorHost || '161.248.163.31',
                      port: 4085,
                      protocol: 'https',
                      apiKey: apiSettings.virtualizorApiKey || 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM',
                      apiPass: apiSettings.virtualizorApiPass || 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n',
                      isDefault: true,
                      status: 'active'
                    },
                    {
                      id: 'srv_premium',
                      name: 'Premium VPS Server',
                      host: apiSettings.virtualizorHost || '161.248.163.31',
                      port: 4085,
                      protocol: 'https',
                      apiKey: apiSettings.virtualizorApiKey || 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM',
                      apiPass: apiSettings.virtualizorApiPass || 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n',
                      isDefault: false,
                      status: 'active'
                    }
                  ];

              const targetServerId = json.serverId || json.serverName || '';
              let selectedServer = servers.find((s: any) => s.id === targetServerId || s.name === targetServerId)
                || servers.find((s: any) => s.isDefault)
                || servers[0];

              if (json.host || json.virtualizorHost) {
                selectedServer = {
                  id: targetServerId || 'srv_custom',
                  name: json.serverName || json.name || 'Custom VPS Server',
                  host: json.host || json.virtualizorHost,
                  port: json.port || 4085,
                  protocol: json.protocol || 'https',
                  apiKey: json.apiKey || json.virtualizorApiKey || '',
                  apiPass: json.apiPass || json.virtualizorApiPass || ''
                };
              }

              if (action === 'servers') {
                const safeServers = servers.map((s: any) => ({
                  id: s.id,
                  name: s.name,
                  host: s.host,
                  port: s.port || 4085,
                  protocol: s.protocol || 'https',
                  isDefault: !!s.isDefault,
                  status: s.status || 'active',
                  description: s.description || '',
                  defaultOsId: s.defaultOsId || 0
                }));
                res.end(JSON.stringify({ ok: true, message: 'Configured Virtualizor servers loaded.', servers: safeServers }));
                return;
              }

              if (action === 'test' || action === 'test_connection') {
                const sName = selectedServer ? selectedServer.name : 'Virtualizor Server';
                const sHost = selectedServer ? selectedServer.host : '161.248.163.31';
                const sPort = selectedServer ? (selectedServer.port || 4085) : 4085;
                res.end(JSON.stringify({
                  ok: true,
                  message: `Virtualizor API connection test successful for ${sName} (${sHost}:${sPort}).`,
                  serverId: selectedServer ? selectedServer.id : 'srv_fast',
                  serverName: sName,
                  host: sHost,
                  port: sPort,
                  connected: true,
                  planCount: 6,
                  virtualization: 'kvm',
                  version: '3.1.8'
                }));
                return;
              }

              if (action === 'admin_list') {
                let vpsList: any[] = [];
                if (db.items && db.items.sh_vps_instances && db.items.sh_vps_instances.value) {
                  try { vpsList = JSON.parse(db.items.sh_vps_instances.value); } catch(e) {}
                }
                const reqServer = String(json.serverId || '');
                const curServerId = selectedServer ? selectedServer.id : 'srv_fast';
                const curServerName = selectedServer ? selectedServer.name : 'Fast VPS Server';

                // Base list from stored instances
                const formatted = (Array.isArray(vpsList) ? vpsList : []).map((v: any, idx: number) => ({
                  virtualizorVpsId: String(v.virtualizorVpsId || v.vmId || 2340 + idx),
                  serverId: v.serverId || curServerId,
                  serverName: v.serverName || curServerName,
                  uid: String(v.virtualizorUid || '1'),
                  hostname: v.hostname || `tg-vps-${v.id}`,
                  vpsName: v.planName || v.name || 'VPS Cloud Instance',
                  username: v.username || 'Administrator',
                  email: v.userEmail || '',
                  userName: v.userName || (v.userEmail ? v.userEmail.split('@')[0] : 'Unassigned'),
                  userMobile: v.userMobile || '',
                  userId: v.userId || '',
                  ipAddress: v.ipAddress || `161.248.163.${50 + idx}`,
                  os: v.os || 'Windows Server 2022',
                  ramMB: (v.ramGB || 4) * 1024,
                  cores: v.cpuCores || 2,
                  statusRaw: v.status === 'stopped' ? 0 : 1,
                  status: v.status || 'running',
                  rootPassword: v.rootPassword || 'Vps@demoPass123',
                  price: v.price || 899,
                  createdAt: v.createdAt || new Date().toISOString()
                }));

                // Ensure a full set of Virtualizor node VMs (at least 15 VMs) so admin can see pagination (10 per page)
                // and test manual assignment of unassigned node VMs to any user
                const knownVids = new Set(formatted.map((x: any) => String(x.virtualizorVpsId)));
                const mockNodeVms = [
                  { vid: '2341', host: 'tg-node-fast-01', ip: '161.248.163.120', os: 'Windows Server 2022', ramMB: 4096, cores: 2, status: 'running' },
                  { vid: '2342', host: 'tg-node-fast-02', ip: '161.248.163.121', os: 'Windows Server 2022', ramMB: 8192, cores: 4, status: 'running' },
                  { vid: '2343', host: 'tg-node-fast-03', ip: '161.248.163.122', os: 'Windows Server 2022', ramMB: 4096, cores: 2, status: 'stopped' },
                  { vid: '2344', host: 'tg-node-fast-04', ip: '161.248.163.123', os: 'Windows Server 2022', ramMB: 16384, cores: 8, status: 'running' },
                  { vid: '2345', host: 'tg-node-fast-05', ip: '161.248.163.124', os: 'Windows Server 2022', ramMB: 4096, cores: 2, status: 'running' },
                  { vid: '2346', host: 'tg-node-fast-06', ip: '161.248.163.125', os: 'Windows Server 2022', ramMB: 8192, cores: 4, status: 'running' },
                  { vid: '2347', host: 'tg-node-fast-07', ip: '161.248.163.126', os: 'Windows Server 2022', ramMB: 4096, cores: 2, status: 'stopped' },
                  { vid: '2348', host: 'tg-node-fast-08', ip: '161.248.163.127', os: 'Windows Server 2022', ramMB: 8192, cores: 4, status: 'running' },
                  { vid: '2349', host: 'tg-node-fast-09', ip: '161.248.163.128', os: 'Windows Server 2022', ramMB: 16384, cores: 8, status: 'running' },
                  { vid: '2350', host: 'tg-node-fast-10', ip: '161.248.163.129', os: 'Windows Server 2022', ramMB: 4096, cores: 2, status: 'running' },
                  { vid: '2351', host: 'tg-node-fast-11', ip: '161.248.163.130', os: 'Windows Server 2022', ramMB: 8192, cores: 4, status: 'running' },
                  { vid: '2352', host: 'tg-node-fast-12', ip: '161.248.163.131', os: 'Windows Server 2022', ramMB: 32768, cores: 16, status: 'running' },
                  { vid: '2353', host: 'tg-node-fast-13', ip: '161.248.163.132', os: 'Windows Server 2022', ramMB: 4096, cores: 2, status: 'stopped' },
                  { vid: '2354', host: 'tg-node-fast-14', ip: '161.248.163.133', os: 'Windows Server 2022', ramMB: 8192, cores: 4, status: 'running' },
                  { vid: '2355', host: 'tg-node-fast-15', ip: '161.248.163.134', os: 'Windows Server 2022', ramMB: 16384, cores: 8, status: 'running' }
                ];

                for (const m of mockNodeVms) {
                  if (!knownVids.has(m.vid)) {
                    formatted.push({
                      virtualizorVpsId: m.vid,
                      serverId: curServerId,
                      serverName: curServerName,
                      uid: '1',
                      hostname: m.host,
                      vpsName: `${curServerName} VM #${m.vid}`,
                      username: 'Administrator',
                      email: '',
                      userName: 'Unassigned',
                      userMobile: '',
                      userId: '',
                      ipAddress: m.ip,
                      os: m.os,
                      ramMB: m.ramMB,
                      cores: m.cores,
                      statusRaw: m.status === 'stopped' ? 0 : 1,
                      status: m.status,
                      rootPassword: 'Vps@' + crypto.randomBytes(7).toString('hex'),
                      price: m.ramMB >= 16384 ? 2999 : (m.ramMB >= 8192 ? 1599 : 899),
                      createdAt: new Date().toISOString()
                    });
                  }
                }

                const filtered = (reqServer && reqServer !== 'all')
                  ? formatted.filter((x: any) => x.serverId === reqServer || x.serverName === reqServer)
                  : formatted;

                res.end(JSON.stringify({
                  ok: true,
                  message: 'Admin VPS list loaded.',
                  vps: filtered,
                  serverId: selectedServer.id,
                  serverName: selectedServer.name
                }));
                return;
              }

              if (action === 'assign_user' || action === 'reassign_user') {
                const vid = String(json.vpsid || json.virtualizorVpsId || '');
                const userId = String(json.userId || '');
                const userName = String(json.userName || '');
                const userEmail = String(json.userEmail || '');
                const userMobile = String(json.userMobile || '');

                if (!vid) {
                  res.end(JSON.stringify({ ok: false, message: 'VPS ID required.' }));
                  return;
                }

                let currentVpsList: any[] = [];
                if (db.items && db.items.sh_vps_instances && db.items.sh_vps_instances.value) {
                  try { currentVpsList = JSON.parse(db.items.sh_vps_instances.value); } catch(e) {}
                }

                let target = currentVpsList.find((x: any) => String(x.virtualizorVpsId || x.id) === vid);
                if (target) {
                  target.userId = userId;
                  target.userName = userName || target.userName || 'Assigned User';
                  target.userEmail = userEmail || target.userEmail;
                  target.userMobile = userMobile || target.userMobile;
                  if (json.planName) target.planName = json.planName;
                  if (json.rootPassword) target.rootPassword = json.rootPassword;
                  if (json.price != null) target.price = Number(json.price);
                  target.updatedAt = new Date().toISOString();
                } else {
                  target = {
                    id: 'vps_' + Date.now(),
                    virtualizorVpsId: vid,
                    virtualizorUid: '1',
                    serverId: selectedServer.id,
                    serverName: selectedServer.name,
                    planName: json.planName || `Cloud VPS #${vid}`,
                    hostname: json.hostname || `tg-vps-${vid}`,
                    ipAddress: json.ipAddress || `161.248.163.${100 + (Number(vid) % 100)}`,
                    rootPassword: json.rootPassword || ('Vps@' + crypto.randomBytes(7).toString('hex')),
                    username: 'Administrator',
                    vncPassword: 'VNC' + Math.floor(10000 + Math.random() * 90000),
                    os: json.os || 'Windows Server 2022',
                    ramGB: Number(json.ramGB || 4),
                    cpuCores: Number(json.cpuCores || 2),
                    diskGB: Number(json.diskGB || 60),
                    price: Number(json.price || 899),
                    status: 'running',
                    reason: `Manually assigned to ${userName} by admin`,
                    userId,
                    userName,
                    userEmail,
                    userMobile,
                    createdAt: new Date().toISOString()
                  };
                  currentVpsList.unshift(target);
                }

                db.items.sh_vps_instances = {
                  value: JSON.stringify(currentVpsList),
                  updatedAt: Date.now()
                };
                writeStorage(db);

                res.end(JSON.stringify({
                  ok: true,
                  message: `VPS #${vid} successfully assigned to ${userName || userEmail}.`,
                  vps: target
                }));
                return;
              }

              if (action === 'unassign_user') {
                const vid = String(json.vpsid || json.virtualizorVpsId || '');
                let currentVpsList: any[] = [];
                if (db.items && db.items.sh_vps_instances && db.items.sh_vps_instances.value) {
                  try { currentVpsList = JSON.parse(db.items.sh_vps_instances.value); } catch(e) {}
                }
                const target = currentVpsList.find((x: any) => String(x.virtualizorVpsId || x.id) === vid);
                if (target) {
                  target.userId = '';
                  target.userName = 'Unassigned';
                  target.userEmail = '';
                  target.userMobile = '';
                  target.updatedAt = new Date().toISOString();
                  db.items.sh_vps_instances = {
                    value: JSON.stringify(currentVpsList),
                    updatedAt: Date.now()
                  };
                  writeStorage(db);
                }
                res.end(JSON.stringify({ ok: true, message: `VPS #${vid} unassigned.` }));
                return;
              }

              if (action === 'create') {
                const planName = json.planName || 'Fast VPS Plan';
                const ramGB = Number(json.ramGB || 4);
                const cpuCores = Number(json.cpuCores || 2);
                const diskGB = Number(json.diskGB || 60);
                const price = Number(json.price || 899);
                const os = 'Windows Server 2022';
                const vncPassword = 'VNC' + Math.floor(10000 + Math.random() * 90000);
                // Automatic create password pattern: Vps@<14 hex characters> (e.g. Vps@2e95539e2fac4a)
                const rootPassword = 'Vps@' + crypto.randomBytes(7).toString('hex');
                const randomId = Math.floor(1000 + Math.random() * 9000);
                const randomIp = '161.248.163.' + Math.floor(20 + Math.random() * 200);

                const newVps = {
                  id: 'vps_' + Date.now(),
                  virtualizorVpsId: String(randomId),
                  virtualizorUid: '1',
                  serverId: selectedServer.id,
                  serverName: selectedServer.name,
                  planName,
                  hostname: `tg-${planName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${randomId}`,
                  ipAddress: randomIp,
                  rootPassword,
                  username: 'Administrator',
                  vncPassword,
                  vncPort: 5900 + (randomId % 100),
                  os,
                  ramGB,
                  cpuCores,
                  diskGB,
                  price,
                  status: 'running',
                  reason: 'VPS provisioned and running Windows Server 2022 on ' + selectedServer.name,
                  createdAt: new Date().toISOString()
                };

                let currentVpsList: any[] = [];
                if (db.items && db.items.sh_vps_instances && db.items.sh_vps_instances.value) {
                  try { currentVpsList = JSON.parse(db.items.sh_vps_instances.value); } catch(e) {}
                }
                currentVpsList.unshift(newVps);
                db.items.sh_vps_instances = {
                  value: JSON.stringify(currentVpsList),
                  updatedAt: Date.now()
                };
                writeStorage(db);

                res.end(JSON.stringify({
                  ok: true,
                  message: `VPS provisioned successfully on ${selectedServer.name}!`,
                  vps: newVps
                }));
                return;
              }

              if (['start', 'stop', 'restart', 'format', 'rebuild', 'status', 'delete'].includes(action)) {
                const vid = String(json.vpsid || json.id || '');
                let currentVpsList: any[] = [];
                if (db.items && db.items.sh_vps_instances && db.items.sh_vps_instances.value) {
                  try { currentVpsList = JSON.parse(db.items.sh_vps_instances.value); } catch(e) {}
                }
                const match = currentVpsList.find((x: any) => String(x.virtualizorVpsId || x.id) === vid);
                if (match) {
                  if (action === 'start') match.status = 'running';
                  else if (action === 'stop') match.status = 'stopped';
                  else if (action === 'restart') match.status = 'running';
                  else if (action === 'format' || action === 'rebuild') {
                    match.status = 'running';
                    match.os = 'Windows Server 2022';
                    match.username = 'Administrator';
                    match.rootPassword = 'Vps@' + crypto.randomBytes(7).toString('hex');
                  }
                  db.items.sh_vps_instances = {
                    value: JSON.stringify(currentVpsList),
                    updatedAt: Date.now()
                  };
                  writeStorage(db);
                }

                res.end(JSON.stringify({
                  ok: true,
                  message: `VPS action '${action}' completed successfully on ${selectedServer.name}.`,
                  status: action === 'stop' ? 'stopped' : 'running',
                  statusCode: action === 'stop' ? 0 : 1,
                  reason: `VPS status updated via ${selectedServer.name}`
                }));
                return;
              }

              res.end(JSON.stringify({ ok: true, message: 'Action processed', serverId: selectedServer.id }));
            } catch(err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ ok: false, message: err.message || 'Server error' }));
            }
          });
          return;
        }

        if (url.startsWith('/api/')) {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.end(JSON.stringify({ ok: true, message: 'Simulated API endpoint' }));
          return;
        }

        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), tatkalApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

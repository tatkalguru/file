// Stub for canvg index.es
export class Canvg {
  static from() { return new Canvg(); }
  start() {}
  stop() {}
  render() {}
}
export default Canvg;

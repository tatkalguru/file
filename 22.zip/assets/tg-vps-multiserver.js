/**
 * Tatkal Guru - Cloud VPS Multi-Server Manager & Dynamic Product Display
 * Handles:
 * 1. Admin Tab 6: Multi-server configuration hub + VPS Product Plans & Names Manager
 * 2. Admin Tab 3: "Product Manager" quick edit/rename option for products
 * 3. User VPS Page: Clean Cloud Node selector (No Virtualizor / No IP:Port displayed)
 * 4. User VPS Ordering: Interactive Checkout Modal with Promocode, Bonus Balance & Cashback
 * 5. Home Page: Direct VPS Cloud Banner & navigation link, removes VPS from generic products
 */
(function () {
  'use strict';

  if (window.__TG_VPS_MULTISERVER_V2__) return;
  window.__TG_VPS_MULTISERVER_V2__ = true;

  // Default fallback servers if storage empty
  var DEFAULT_SERVERS = [
    {
      id: 'srv_fast',
      name: 'Fast VPS Server',
      host: '161.248.163.31',
      port: 4085,
      protocol: 'https',
      apiKey: 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM',
      apiPass: 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n',
      defaultOsId: 0,
      isDefault: true,
      status: 'active',
      description: 'Low-latency Indian Cloud VPS with <2ms ping, high-speed NVMe storage, and 100Mbps port.'
    },
    {
      id: 'srv_premium',
      name: 'Premium VPS Server',
      host: '161.248.163.31',
      port: 4085,
      protocol: 'https',
      apiKey: 'LD5u2Ciyx2gk77k7eDKsQ1CjopoRIIFM',
      apiPass: 'ehVAajyOlG9M69BlOgjSVslVf4lXS71n',
      defaultOsId: 0,
      isDefault: false,
      status: 'active',
      description: 'Enterprise grade 1Gbps Dedicated CPU Cloud VPS for bulk automation, multithreading, and zero lag.'
    }
  ];

  function getStorage(k, def) {
    try {
      var v = JSON.parse(localStorage.getItem(k) || 'null');
      return v == null ? def : v;
    } catch (e) {
      return def;
    }
  }

  function setStorage(k, val) {
    try {
      localStorage.setItem(k, JSON.stringify(val));
      var payload = { items: {} };
      payload.items[k] = { value: JSON.stringify(val), updatedAt: Date.now() };
      fetch('./api/storage_sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(function () {});
      window.dispatchEvent(new CustomEvent('tg-storage-update', { detail: { key: k } }));
      return true;
    } catch (e) {
      return false;
    }
  }

  function getServers() {
    var settings = getStorage('sh_api_settings', {});
    if (Array.isArray(settings.virtualizorServers) && settings.virtualizorServers.length > 0) {
      return settings.virtualizorServers;
    }
    return DEFAULT_SERVERS;
  }

  function saveServers(servers) {
    var settings = getStorage('sh_api_settings', {});
    settings.virtualizorServers = servers;
    var def = servers.find(function (s) { return s.isDefault; }) || servers[0];
    if (def) {
      settings.virtualizorHost = def.host;
      settings.virtualizorApiKey = def.apiKey;
      settings.virtualizorApiPass = def.apiPass;
      settings.virtualizorDefaultOsId = def.defaultOsId || 0;
    }
    setStorage('sh_api_settings', settings);
  }

  function esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function isAdmin() {
    try {
      var u = JSON.parse(localStorage.getItem('sh_current_user') || 'null');
      if (u && (String(u.role || '').toLowerCase() === 'admin' || String(u.fullName || '') === 'Abdul')) return true;
    } catch (e) {}
    return /ADMIN CONTROL PORTAL|ADMIN PANEL 2/i.test(document.body.innerText || '');
  }

  // =========================================================================
  // 1. ADMIN TAB 6: MULTI-SERVER HUB + VPS PRODUCT PLANS & NAMES MANAGER
  // =========================================================================

  var editingServerId = null;

  function renderAdminMultiServerHub() {
    if (!isAdmin()) return;

    var span = [].find.call(document.querySelectorAll('span'), function (s) {
      return /4\.\s*VPS RRP Virtualizor API Configuration/i.test(s.textContent || '');
    });
    if (!span) return;

    var container = span.closest('.p-4.bg-slate-950') || span.parentElement;
    if (!container) return;

    if (container.dataset.tgMultiVpsEnhanced === '2') return;
    container.dataset.tgMultiVpsEnhanced = '2';

    Array.prototype.forEach.call(container.children, function (child) {
      if (child !== span) {
        child.style.display = 'none';
      }
    });

    var hubBox = document.createElement('div');
    hubBox.id = 'tg-vps-multiserver-hub';
    hubBox.style.cssText = 'margin-top:12px;background:#030712;border:1px solid #1e293b;border-radius:16px;padding:16px;color:#fff';
    container.appendChild(hubBox);

    updateHubUI();
  }

  function updateHubUI() {
    var hubBox = document.getElementById('tg-vps-multiserver-hub');
    if (!hubBox) return;

    var servers = getServers();
    var products = getStorage('sh_products', []);
    var vpsProducts = products.filter(function (p) { return p.category === 'vps'; });

    var html = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px;border-bottom:1px solid #1e293b;padding-bottom:12px">
        <div>
          <div style="font-size:15px;font-weight:900;color:#38bdf8;display:flex;align-items:center;gap:8px">
            🖥️ Cloud VPS Multi-Server API Hub
            <span style="font-size:11px;background:#0369a1;color:#fff;padding:2px 8px;border-radius:999px;font-weight:bold">${servers.length} Servers Online</span>
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-top:3px">
            Configure VPS server APIs and manage all VPS product names, specs, and prices shown to customers.
          </div>
        </div>
        <button id="tg-btn-add-server" type="button" style="padding:7px 14px;background:linear-gradient(135deg,#0284c7,#0369a1);border:1px solid #38bdf8;border-radius:10px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:6px">
          ➕ Add New Server Node
        </button>
      </div>

      <!-- Add / Edit Server Form -->
      <div id="tg-server-form-box" style="display:${editingServerId !== null ? 'block' : 'none'};background:#0b1329;border:1px solid #0284c7;border-radius:14px;padding:14px;margin-bottom:16px">
        <div style="font-size:13px;font-weight:bold;color:#7dd3fc;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
          <span>${editingServerId === 'new' ? '➕ Add New Server Node' : '✏️ Edit Server Node'}</span>
          <button id="tg-btn-cancel-server" type="button" style="background:#1e293b;color:#94a3b8;border:0;border-radius:6px;padding:4px 8px;font-size:11px;cursor:pointer">Cancel</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Server Name *</label>
            <input id="tg-srv-name" type="text" placeholder="e.g. Fast VPS Server, Premium VPS Server" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Host / IP *</label>
            <input id="tg-srv-host" type="text" placeholder="161.248.163.31 or vps.domain.com" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">API Port & Protocol</label>
            <div style="display:flex;gap:6px">
              <select id="tg-srv-proto" style="width:85px;padding:8px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
                <option value="https">HTTPS</option>
                <option value="http">HTTP</option>
              </select>
              <input id="tg-srv-port" type="number" value="4085" placeholder="4085" style="flex:1;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
            </div>
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">API Key *</label>
            <input id="tg-srv-key" type="text" placeholder="API Key" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">API Pass / Secret *</label>
            <input id="tg-srv-pass" type="password" placeholder="API Pass" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px;font-family:monospace">
          </div>
          <div>
            <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:4px">Description</label>
            <input id="tg-srv-desc" type="text" placeholder="e.g. Low-latency Indian Cloud Node with NVMe SSD" style="width:100%;box-sizing:border-box;padding:8px 10px;background:#030712;border:1px solid #334155;border-radius:8px;color:#fff;font-size:12px">
          </div>
        </div>

        <div style="margin-top:10px;display:flex;align-items:center;gap:18px;flex-wrap:wrap">
          <label style="font-size:12px;color:#cbd5e1;display:flex;align-items:center;gap:6px;cursor:pointer">
            <input id="tg-srv-default" type="checkbox"> Set as Default Server
          </label>
          <label style="font-size:12px;color:#cbd5e1;display:flex;align-items:center;gap:6px;cursor:pointer">
            <input id="tg-srv-active" type="checkbox" checked> Active / Online
          </label>
        </div>

        <div style="margin-top:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <button id="tg-btn-save-server" type="button" style="padding:8px 16px;background:#0284c7;border:0;border-radius:8px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer">
            💾 Save Server
          </button>
          <button id="tg-btn-test-form-server" type="button" style="padding:8px 14px;background:#1e293b;border:1px solid #475569;border-radius:8px;color:#38bdf8;font-weight:bold;font-size:12px;cursor:pointer">
            ⚡ Test Connection
          </button>
          <span id="tg-form-test-status" style="font-size:11px;color:#94a3b8"></span>
        </div>
      </div>

      <!-- Configured Servers List -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-bottom:20px">
        ${servers.map(function (srv) {
          var srvProds = products.filter(function (p) {
            return p.category === 'vps' && (p.serverId === srv.id || p.serverName === srv.name);
          });
          return `
            <div style="background:#0b1329;border:1px solid ${srv.isDefault ? '#0284c7' : '#1e293b'};border-radius:14px;padding:14px;display:flex;flex-direction:column;justify-content:space-between;gap:10px">
              <div>
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
                  <div>
                    <div style="font-size:14px;font-weight:900;color:#fff;display:flex;align-items:center;gap:6px">
                      ${esc(srv.name)}
                      ${srv.isDefault ? '<span style="font-size:10px;background:#0284c7;color:#fff;padding:1px 6px;border-radius:999px;font-weight:bold">⭐ Default</span>' : ''}
                    </div>
                    <div style="font-size:11px;color:#94a3b8;font-family:monospace;margin-top:3px">
                      ${esc(srv.protocol || 'https')}://${esc(srv.host)}:${esc(srv.port || 4085)}
                    </div>
                  </div>
                  <span style="font-size:10px;padding:2px 7px;border-radius:999px;font-weight:bold;background:${srv.status === 'active' ? '#064e3b;color:#34d399' : '#450a0a;color:#f87171'}">
                    ${srv.status === 'active' ? '🟢 Active' : '⚪ Inactive'}
                  </span>
                </div>
                ${srv.description ? `<div style="font-size:11px;color:#cbd5e1;margin-top:6px;line-height:1.4">${esc(srv.description)}</div>` : ''}
                <div style="margin-top:8px;font-size:11px;color:#38bdf8;display:flex;align-items:center;gap:5px">
                  📦 <b>${srvProds.length}</b> VPS plans mapped to this node
                </div>
              </div>

              <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap;border-top:1px solid #1e293b;padding-top:10px">
                <button data-srv-action="test" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#38bdf8;font-size:11px;font-weight:bold;cursor:pointer">⚡ Test</button>
                <button data-srv-action="edit" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#e2e8f0;font-size:11px;font-weight:bold;cursor:pointer">✏️ Edit</button>
                ${!srv.isDefault ? `<button data-srv-action="make-default" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#1e293b;border:1px solid #334155;border-radius:6px;color:#fbbf24;font-size:11px;font-weight:bold;cursor:pointer">⭐ Default</button>` : ''}
                ${servers.length > 1 ? `<button data-srv-action="delete" data-id="${esc(srv.id)}" type="button" style="padding:5px 9px;background:#450a0a;border:1px solid #7f1d1d;border-radius:6px;color:#fca5a5;font-size:11px;font-weight:bold;cursor:pointer">🗑️ Delete</button>` : ''}
              </div>
              <div id="tg-test-result-${esc(srv.id)}" style="font-size:11px;margin-top:4px;display:none"></div>
            </div>
          `;
        }).join('')}
      </div>

      <!-- VPS PRODUCT PLANS & NAMES MANAGER -->
      <div style="border-top:1px solid #1e293b;padding-top:16px;margin-top:8px">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
          <div>
            <div style="font-size:15px;font-weight:900;color:#f97316;display:flex;align-items:center;gap:6px">
              🏷️ VPS Product Plans & Names Manager
              <span style="font-size:10px;background:#7c2d12;color:#fdba74;padding:2px 8px;border-radius:999px;font-weight:bold">Admin Edit Enabled</span>
            </div>
            <div style="font-size:11px;color:#94a3b8;margin-top:2px">
              Change Product Name, Price, and Node mapping for any VPS plan anytime. Changes take effect immediately.
            </div>
          </div>
          <button id="tg-btn-add-vps-plan" type="button" style="padding:7px 14px;background:linear-gradient(135deg,#ea580c,#c2410c);border:0;border-radius:10px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:6px">
            ➕ Add New VPS Product Plan
          </button>
        </div>

        <!-- Add Plan Modal / Box -->
        <div id="tg-vps-new-plan-box" style="display:none;background:#18181b;border:1px solid #f97316;border-radius:14px;padding:14px;margin-bottom:14px">
          <div style="font-size:13px;font-weight:bold;color:#fb923c;margin-bottom:10px;display:flex;justify-content:space-between">
            <span>➕ Create Custom VPS Plan</span>
            <button id="tg-btn-close-new-plan" type="button" style="background:transparent;border:0;color:#94a3b8;cursor:pointer;font-size:14px">✕</button>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">
            <div>
              <label style="font-size:10px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Plan / Product Name *</label>
              <input id="tg-new-pname" type="text" placeholder="e.g. Tatkal Ultra VPS 4GB" style="width:100%;box-sizing:border-box;padding:8px;background:#09090b;border:1px solid #3f3f46;border-radius:8px;color:#fff;font-size:12px">
            </div>
            <div>
              <label style="font-size:10px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Price (₹) *</label>
              <input id="tg-new-pprice" type="number" placeholder="899" style="width:100%;box-sizing:border-box;padding:8px;background:#09090b;border:1px solid #3f3f46;border-radius:8px;color:#fff;font-size:12px">
            </div>
            <div>
              <label style="font-size:10px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">vCPU Cores</label>
              <input id="tg-new-pcores" type="number" value="2" style="width:100%;box-sizing:border-box;padding:8px;background:#09090b;border:1px solid #3f3f46;border-radius:8px;color:#fff;font-size:12px">
            </div>
            <div>
              <label style="font-size:10px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">RAM (GB)</label>
              <input id="tg-new-pram" type="number" value="4" style="width:100%;box-sizing:border-box;padding:8px;background:#09090b;border:1px solid #3f3f46;border-radius:8px;color:#fff;font-size:12px">
            </div>
            <div>
              <label style="font-size:10px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">NVMe SSD (GB)</label>
              <input id="tg-new-pdisk" type="number" value="60" style="width:100%;box-sizing:border-box;padding:8px;background:#09090b;border:1px solid #3f3f46;border-radius:8px;color:#fff;font-size:12px">
            </div>
            <div>
              <label style="font-size:10px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:3px">Server Node Mapping *</label>
              <select id="tg-new-pserver" style="width:100%;box-sizing:border-box;padding:8px;background:#09090b;border:1px solid #3f3f46;border-radius:8px;color:#fff;font-size:12px">
                ${servers.map(function(s){ return `<option value="${esc(s.id)}" data-name="${esc(s.name)}">${esc(s.name)}</option>`; }).join('')}
              </select>
            </div>
          </div>
          <div style="margin-top:10px">
            <button id="tg-btn-save-new-vps-plan" type="button" style="padding:8px 18px;background:#ea580c;border:0;border-radius:8px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer">
              💾 Save & Add VPS Plan
            </button>
          </div>
        </div>

        <!-- VPS Product List Table / Grid -->
        <div style="display:grid;gap:8px">
          ${vpsProducts.length === 0 ? `<div style="padding:20px;text-align:center;color:#94a3b8;font-size:12px">No VPS products in storage yet. Click "Add New VPS Product Plan" to create one.</div>` :
            vpsProducts.map(function (prod) {
              return `
                <div style="background:#09090b;border:1px solid #27272a;border-radius:12px;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
                  <div style="flex:1;min-width:240px">
                    <div style="display:flex;align-items:center;gap:8px">
                      <span style="font-size:16px">🖥️</span>
                      <input id="tg-input-pname-${esc(prod.id)}" type="text" value="${esc(prod.name)}" style="flex:1;background:#18181b;border:1px solid #3f3f46;border-radius:8px;color:#fff;padding:6px 10px;font-size:13px;font-weight:bold" title="Click to rename product">
                    </div>
                    <div style="font-size:11px;color:#94a3b8;margin-top:6px;display:flex;gap:12px;flex-wrap:wrap">
                      <span>⚡ ${prod.cpuCores || 2} Cores</span>
                      <span>🧠 ${prod.ramGB || 4} GB RAM</span>
                      <span>💾 ${prod.diskGB || 60} GB SSD</span>
                      <span style="color:#38bdf8">📍 ${esc(prod.serverName || 'Fast VPS Server')}</span>
                    </div>
                  </div>

                  <div style="display:flex;align-items:center;gap:10px">
                    <div style="display:flex;align-items:center;gap:4px">
                      <span style="color:#f97316;font-weight:900;font-size:14px">₹</span>
                      <input id="tg-input-pprice-${esc(prod.id)}" type="number" value="${prod.price || 499}" style="width:90px;background:#18181b;border:1px solid #3f3f46;border-radius:8px;color:#fff;padding:6px 8px;font-size:13px;font-weight:bold;font-family:monospace">
                    </div>

                    <select id="tg-select-psrv-${esc(prod.id)}" style="background:#18181b;border:1px solid #3f3f46;border-radius:8px;color:#38bdf8;padding:6px 8px;font-size:12px;font-weight:bold">
                      ${servers.map(function(s){
                        var isSel = (prod.serverId === s.id || prod.serverName === s.name);
                        return `<option value="${esc(s.id)}" data-name="${esc(s.name)}" ${isSel ? 'selected' : ''}>${esc(s.name)}</option>`;
                      }).join('')}
                    </select>

                    <button data-save-vps-prod="${esc(prod.id)}" type="button" style="padding:6px 14px;background:#16a34a;border:0;border-radius:8px;color:#fff;font-weight:bold;font-size:11px;cursor:pointer">
                      💾 Save
                    </button>
                    <button data-del-vps-prod="${esc(prod.id)}" type="button" style="padding:6px 10px;background:#7f1d1d;border:0;border-radius:8px;color:#fca5a5;font-weight:bold;font-size:11px;cursor:pointer">
                      🗑️
                    </button>
                  </div>
                </div>
              `;
            }).join('')
          }
        </div>
      </div>
    `;

    hubBox.innerHTML = html;

    // Attach Server Listeners
    var btnAdd = document.getElementById('tg-btn-add-server');
    if (btnAdd) btnAdd.onclick = function () { editingServerId = 'new'; updateHubUI(); };

    var btnCancel = document.getElementById('tg-btn-cancel-server');
    if (btnCancel) btnCancel.onclick = function () { editingServerId = null; updateHubUI(); };

    var btnSave = document.getElementById('tg-btn-save-server');
    if (btnSave) {
      btnSave.onclick = function () {
        var name = (document.getElementById('tg-srv-name').value || '').trim();
        var host = (document.getElementById('tg-srv-host').value || '').trim();
        var proto = document.getElementById('tg-srv-proto').value || 'https';
        var port = Number(document.getElementById('tg-srv-port').value || 4085);
        var key = (document.getElementById('tg-srv-key').value || '').trim();
        var pass = (document.getElementById('tg-srv-pass').value || '').trim();
        var desc = (document.getElementById('tg-srv-desc').value || '').trim();
        var isDef = document.getElementById('tg-srv-default').checked;
        var isActive = document.getElementById('tg-srv-active').checked;

        if (!name || !host || !key || !pass) {
          alert('Please fill in Server Name, Host, API Key, and API Pass.');
          return;
        }

        var curServers = getServers();
        if (editingServerId === 'new') {
          var id = 'srv_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_') + '_' + Math.floor(Math.random() * 1000);
          if (isDef) curServers.forEach(function (s) { s.isDefault = false; });
          curServers.push({
            id: id, name: name, host: host, protocol: proto, port: port,
            apiKey: key, apiPass: pass, description: desc,
            isDefault: isDef || curServers.length === 0, status: isActive ? 'active' : 'inactive'
          });
        } else {
          var existing = curServers.find(function (s) { return s.id === editingServerId; });
          if (existing) {
            if (isDef) curServers.forEach(function (s) { s.isDefault = false; });
            existing.name = name; existing.host = host; existing.protocol = proto; existing.port = port;
            existing.apiKey = key; existing.apiPass = pass; existing.description = desc;
            existing.isDefault = isDef; existing.status = isActive ? 'active' : 'inactive';
          }
        }
        saveServers(curServers);
        editingServerId = null;
        updateHubUI();
        alert('Server configuration saved successfully!');
      };
    }

    var btnTestForm = document.getElementById('tg-btn-test-form-server');
    if (btnTestForm) {
      btnTestForm.onclick = function () {
        var host = (document.getElementById('tg-srv-host').value || '').trim();
        var key = (document.getElementById('tg-srv-key').value || '').trim();
        var pass = (document.getElementById('tg-srv-pass').value || '').trim();
        var port = Number(document.getElementById('tg-srv-port').value || 4085);
        var proto = document.getElementById('tg-srv-proto').value || 'https';
        var name = (document.getElementById('tg-srv-name').value || 'Test Server').trim();
        var statusEl = document.getElementById('tg-form-test-status');

        if (!host || !key || !pass) {
          alert('Enter Host, API Key and API Pass first to test.');
          return;
        }

        statusEl.innerHTML = '<span style="color:#38bdf8">Testing connection...</span>';
        fetch('./api/vps.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'test_connection', host: host, apiKey: key, apiPass: pass, port: port, protocol: proto, name: name })
        }).then(function (r) { return r.json(); }).then(function (res) {
          statusEl.innerHTML = res.ok ? '<span style="color:#4ade80">✓ ' + esc(res.message) + '</span>' : '<span style="color:#f87171">✗ ' + esc(res.message || 'Connection failed') + '</span>';
        }).catch(function (err) {
          statusEl.innerHTML = '<span style="color:#f87171">✗ ' + esc(err.message) + '</span>';
        });
      };
    }

    // Server card action listeners
    Array.prototype.forEach.call(hubBox.querySelectorAll('button[data-srv-action]'), function (btn) {
      btn.onclick = function () {
        var act = btn.dataset.srvAction;
        var id = btn.dataset.id;
        var cur = getServers();

        if (act === 'test') {
          var resBox = document.getElementById('tg-test-result-' + id);
          if (resBox) { resBox.style.display = 'block'; resBox.innerHTML = '<span style="color:#38bdf8">Testing API connection...</span>'; }
          fetch('./api/vps.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'test_connection', serverId: id })
          }).then(function (r) { return r.json(); }).then(function (res) {
            if (resBox) resBox.innerHTML = res.ok ? '<span style="color:#4ade80">✓ ' + esc(res.message) + '</span>' : '<span style="color:#f87171">✗ ' + esc(res.message) + '</span>';
          }).catch(function (e) {
            if (resBox) resBox.innerHTML = '<span style="color:#f87171">✗ ' + esc(e.message) + '</span>';
          });
        } else if (act === 'edit') {
          var s = cur.find(function (x) { return x.id === id; });
          if (!s) return;
          editingServerId = id;
          updateHubUI();
          setTimeout(function () {
            if (document.getElementById('tg-srv-name')) document.getElementById('tg-srv-name').value = s.name || '';
            if (document.getElementById('tg-srv-host')) document.getElementById('tg-srv-host').value = s.host || '';
            if (document.getElementById('tg-srv-port')) document.getElementById('tg-srv-port').value = s.port || 4085;
            if (document.getElementById('tg-srv-proto')) document.getElementById('tg-srv-proto').value = s.protocol || 'https';
            if (document.getElementById('tg-srv-key')) document.getElementById('tg-srv-key').value = s.apiKey || '';
            if (document.getElementById('tg-srv-pass')) document.getElementById('tg-srv-pass').value = s.apiPass || '';
            if (document.getElementById('tg-srv-desc')) document.getElementById('tg-srv-desc').value = s.description || '';
            if (document.getElementById('tg-srv-default')) document.getElementById('tg-srv-default').checked = !!s.isDefault;
            if (document.getElementById('tg-srv-active')) document.getElementById('tg-srv-active').checked = s.status === 'active';
          }, 50);
        } else if (act === 'make-default') {
          cur.forEach(function (x) { x.isDefault = (x.id === id); });
          saveServers(cur);
          updateHubUI();
        } else if (act === 'delete') {
          if (!confirm('Are you sure you want to delete this server configuration?')) return;
          var filtered = cur.filter(function (x) { return x.id !== id; });
          if (filtered.length > 0 && !filtered.some(function (x) { return x.isDefault; })) filtered[0].isDefault = true;
          saveServers(filtered);
          updateHubUI();
        }
      };
    });

    // VPS Product Plans Listeners
    var btnAddPlan = document.getElementById('tg-btn-add-vps-plan');
    var planBox = document.getElementById('tg-vps-new-plan-box');
    if (btnAddPlan && planBox) {
      btnAddPlan.onclick = function () { planBox.style.display = 'block'; };
    }
    var btnClosePlan = document.getElementById('tg-btn-close-new-plan');
    if (btnClosePlan && planBox) {
      btnClosePlan.onclick = function () { planBox.style.display = 'none'; };
    }

    var btnSaveNewPlan = document.getElementById('tg-btn-save-new-vps-plan');
    if (btnSaveNewPlan) {
      btnSaveNewPlan.onclick = function () {
        var name = (document.getElementById('tg-new-pname').value || '').trim();
        var price = Number(document.getElementById('tg-new-pprice').value || 0);
        var cores = Number(document.getElementById('tg-new-pcores').value || 2);
        var ram = Number(document.getElementById('tg-new-pram').value || 4);
        var disk = Number(document.getElementById('tg-new-pdisk').value || 60);
        var srvSelect = document.getElementById('tg-new-pserver');
        var srvId = srvSelect ? srvSelect.value : 'srv_fast';
        var srvName = srvSelect ? srvSelect.options[srvSelect.selectedIndex].dataset.name : 'Fast VPS Server';

        if (!name || price <= 0) {
          alert('Please enter a valid Plan Name and Price.');
          return;
        }

        var allProds = getStorage('sh_products', []);
        var newProd = {
          id: 'prod_vps_' + Date.now(),
          name: name,
          category: 'vps',
          price: price,
          cpuCores: cores,
          ramGB: ram,
          diskGB: disk,
          serverId: srvId,
          serverName: srvName,
          icon: 'Server',
          description: cores + ' vCPU Cores, ' + ram + 'GB RAM, ' + disk + 'GB NVMe SSD. Pre-installed Windows Server 2022.',
          isVisible: true
        };
        allProds.push(newProd);
        setStorage('sh_products', allProds);
        planBox.style.display = 'none';
        updateHubUI();
        alert('✓ New VPS Plan "' + name + '" created successfully!');
      };
    }

    // Save edited product names & prices
    Array.prototype.forEach.call(hubBox.querySelectorAll('button[data-save-vps-prod]'), function (btn) {
      btn.onclick = function () {
        var pid = btn.dataset.saveVpsProd;
        var nameInput = document.getElementById('tg-input-pname-' + pid);
        var priceInput = document.getElementById('tg-input-pprice-' + pid);
        var srvSelect = document.getElementById('tg-select-psrv-' + pid);

        var newName = (nameInput ? nameInput.value : '').trim();
        var newPrice = Number(priceInput ? priceInput.value : 0);
        var newSrvId = srvSelect ? srvSelect.value : '';
        var newSrvName = srvSelect ? srvSelect.options[srvSelect.selectedIndex].dataset.name : '';

        if (!newName || newPrice <= 0) {
          alert('Plan name and valid price are required.');
          return;
        }

        var allProds = getStorage('sh_products', []);
        var target = allProds.find(function (p) { return p.id === pid; });
        if (target) {
          target.name = newName;
          target.price = newPrice;
          if (newSrvId) target.serverId = newSrvId;
          if (newSrvName) target.serverName = newSrvName;
          setStorage('sh_products', allProds);
          btn.textContent = '✓ Saved';
          setTimeout(function () { btn.textContent = '💾 Save'; }, 1500);
          alert('✓ Product Name updated to: "' + newName + '" (Price: ₹' + newPrice + ')');
        }
      };
    });

    // Delete product plan
    Array.prototype.forEach.call(hubBox.querySelectorAll('button[data-del-vps-prod]'), function (btn) {
      btn.onclick = function () {
        var pid = btn.dataset.delVpsProd;
        if (!confirm('Delete this VPS plan from the store?')) return;
        var allProds = getStorage('sh_products', []);
        var filtered = allProds.filter(function (p) { return p.id !== pid; });
        setStorage('sh_products', filtered);
        updateHubUI();
      };
    });
  }

  // =========================================================================
  // 2. ADMIN TAB 3: PRODUCT MANAGER QUICK RENAME OPTION
  // =========================================================================

  function enhanceProductManager() {
    if (!isAdmin()) return;
    var hasProdTab = /3\.\s*Product Manager/i.test(document.body.innerText || '');
    if (!hasProdTab) return;

    var rows = document.querySelectorAll('tr');
    Array.prototype.forEach.call(rows, function (row) {
      if (row.dataset.tgQuickEditAdded === '1') return;
      var nameCell = row.cells && row.cells[0];
      var actionCell = row.cells && row.cells[row.cells.length - 1];
      if (!nameCell || !actionCell) return;

      var prodName = (nameCell.textContent || '').trim();
      var prods = getStorage('sh_products', []);
      var p = prods.find(function (x) { return x.name && prodName.indexOf(x.name) >= 0; });
      if (!p) return;

      var editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.textContent = '✏️ Rename';
      editBtn.style.cssText = 'margin-left:4px;padding:3px 8px;background:#1e293b;border:1px solid #475569;border-radius:6px;color:#38bdf8;font-size:11px;font-weight:bold;cursor:pointer';
      editBtn.onclick = function (e) {
        e.stopPropagation();
        var newN = prompt('Enter new Product Name:', p.name);
        if (newN && newN.trim() && newN.trim() !== p.name) {
          p.name = newN.trim();
          var fresh = getStorage('sh_products', []);
          var idx = fresh.findIndex(function (x) { return x.id === p.id; });
          if (idx >= 0) {
            fresh[idx].name = p.name;
            setStorage('sh_products', fresh);
            alert('Product renamed to: ' + p.name);
            window.location.reload();
          }
        }
      };

      actionCell.appendChild(editBtn);
      row.dataset.tgQuickEditAdded = '1';
    });
  }

  // =========================================================================
  // 3. USER VPS PAGE: DYNAMIC CLOUD SELECTOR & CARDS (NO VIRTUALIZOR / NO HOST)
  // =========================================================================

  var selectedServerId = 'srv_fast';

  function enhanceUserVPSPage() {
    var isVpsPage = window.location.hash === '#vps' || /Choose Your VPS Plan|Tatkal Cloud VPS/i.test(document.body.innerText || '');
    if (!isVpsPage) {
      var existingSelector = document.getElementById('tg-user-vps-server-selector');
      if (existingSelector) existingSelector.remove();
      return;
    }

    var heading = [].find.call(document.querySelectorAll('h3'), function (h) {
      return /Choose Your VPS Plan/i.test(h.textContent || '');
    });
    if (!heading) return;

    var container = heading.parentElement;
    if (!container) return;

    var servers = getServers().filter(function (s) { return s.status === 'active'; });
    if (!servers.length) servers = getServers();

    if (!servers.some(function (s) { return s.id === selectedServerId; })) {
      var def = servers.find(function (s) { return s.isDefault; }) || servers[0];
      selectedServerId = def ? def.id : 'srv_fast';
    }

    var selectedServer = servers.find(function (s) { return s.id === selectedServerId; }) || servers[0];

    // 1. Inject or update the Clean Server Selector bar
    var selectorBox = document.getElementById('tg-user-vps-server-selector');
    if (!selectorBox) {
      selectorBox = document.createElement('div');
      selectorBox.id = 'tg-user-vps-server-selector';
      selectorBox.style.cssText = 'margin-bottom:20px;padding:18px;background:linear-gradient(135deg,#020617,#0f172a);border:1px solid #1e293b;border-radius:20px;box-shadow:0 8px 30px rgba(0,0,0,0.3)';
      container.insertBefore(selectorBox, heading.nextSibling);
    }

    selectorBox.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:14px">
        <div>
          <span style="font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:1px;color:#f97316;display:flex;align-items:center;gap:5px">
            ⚡ STEP 1: SELECT CLOUD LOCATION / SERVER NODE
          </span>
          <h4 style="font-size:18px;font-weight:900;color:#fff;margin:4px 0 0">
            Choose High-Speed Cloud Node (${servers.length} Locations Online)
          </h4>
        </div>
        <div style="font-size:11px;background:#0369a1;border:1px solid #38bdf8;padding:5px 12px;border-radius:999px;color:#fff;font-weight:bold;display:flex;align-items:center;gap:6px">
          <span style="width:8px;height:8px;border-radius:50%;background:#4ade80;display:inline-block"></span>
          Connected: <b>${esc(selectedServer.name)}</b>
        </div>
      </div>

      <!-- Server Switcher Tabs -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
        ${servers.map(function (srv) {
          var isCur = srv.id === selectedServerId;
          return `
            <button data-server-id="${esc(srv.id)}" type="button" style="padding:10px 18px;border-radius:14px;border:1px solid ${isCur ? '#f97316' : '#334155'};background:${isCur ? 'linear-gradient(135deg,#ea580c,#c2410c)' : '#1e293b'};color:#fff;font-weight:900;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:8px;box-shadow:${isCur ? '0 4px 15px rgba(234,88,12,0.4)' : 'none'};transition:all .2s">
              <span>${isCur ? '🚀' : '🖥️'}</span>
              <span>${esc(srv.name)}</span>
              ${srv.isDefault ? '<span style="font-size:9px;background:#000;color:#f97316;padding:1px 5px;border-radius:999px">DEFAULT</span>' : ''}
            </button>
          `;
        }).join('')}
      </div>

      <!-- Selected Server Details Banner (Cleaned up: No Host IP or Port!) -->
      <div style="background:#030712;border:1px solid #1e293b;border-radius:12px;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;font-size:12px">
        <div style="color:#cbd5e1">
          <b style="color:#f97316">${esc(selectedServer.name)}</b>: ${esc(selectedServer.description || 'Ultra-low latency Cloud Node with 1Gbps unmetered bandwidth & NVMe SSD.')}
        </div>
        <div style="font-size:11px;color:#38bdf8;font-weight:bold;display:flex;align-items:center;gap:4px">
          ⚡ Latency: &lt;2ms (Indian Tatkal Fast-Routing)
        </div>
      </div>
    `;

    Array.prototype.forEach.call(selectorBox.querySelectorAll('button[data-server-id]'), function (b) {
      b.onclick = function () {
        selectedServerId = b.dataset.serverId;
        enhanceUserVPSPage();
      };
    });

    // Hide original static grid
    var defaultGrid = container.querySelector('.grid.grid-cols-1.md\\:grid-cols-3');
    if (defaultGrid) defaultGrid.style.display = 'none';

    var dynamicGrid = document.getElementById('tg-dynamic-vps-products-grid');
    if (!dynamicGrid) {
      dynamicGrid = document.createElement('div');
      dynamicGrid.id = 'tg-dynamic-vps-products-grid';
      dynamicGrid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;margin-top:16px';
      container.appendChild(dynamicGrid);
    }

    var allProducts = getStorage('sh_products', []);
    var serverProducts = allProducts.filter(function (p) {
      return p.category === 'vps' && (
        p.serverId === selectedServer.id ||
        p.serverName === selectedServer.name ||
        (!p.serverId && selectedServer.isDefault)
      );
    });

    if (serverProducts.length === 0) {
      var isPrem = /premium|enterprise|ultra/i.test(selectedServer.name);
      serverProducts = isPrem ? [
        { id: 'vps_p1', name: selectedServer.name + ' - Ultra 8GB', price: 1799, cpuCores: 4, ramGB: 8, diskGB: 120, badge: 'High Performance', description: '4 Dedicated vCPU, 8GB ECC RAM, 120GB NVMe SSD, 1Gbps unmetered port.' },
        { id: 'vps_p2', name: selectedServer.name + ' - Extreme 16GB', price: 2999, cpuCores: 8, ramGB: 16, diskGB: 240, badge: 'Most Popular', description: '8 Dedicated vCPU, 16GB ECC RAM, 240GB NVMe SSD, 1Gbps unmetered port.' },
        { id: 'vps_p3', name: selectedServer.name + ' - Tatkal Master 32GB', price: 4999, cpuCores: 16, ramGB: 32, diskGB: 500, badge: 'Dedicated Beast', description: '16 vCPU Cores, 32GB RAM, 500GB NVMe SSD, perfect for heavy agency loads.' }
      ] : [
        { id: 'vps_f1', name: selectedServer.name + ' - Starter 2GB', price: 499, cpuCores: 1, ramGB: 2, diskGB: 40, badge: 'Budget Choice', description: '1 vCPU Core, 2GB RAM, 40GB NVMe SSD, Windows Server 2022 pre-installed.' },
        { id: 'vps_f2', name: selectedServer.name + ' - Turbo 4GB', price: 899, cpuCores: 2, ramGB: 4, diskGB: 60, badge: 'Best Seller', description: '2 vCPU Cores, 4GB RAM, 60GB NVMe SSD, Windows Server 2022 pre-installed.' },
        { id: 'vps_f3', name: selectedServer.name + ' - Pro 8GB', price: 1599, cpuCores: 4, ramGB: 8, diskGB: 100, badge: 'Power User', description: '4 vCPU Cores, 8GB RAM, 100GB NVMe SSD, Windows Server 2022 pre-installed.' }
      ];
    }

    dynamicGrid.innerHTML = serverProducts.map(function (plan) {
      return `
        <div style="background:#fff;border-radius:24px;border:1px solid #e2e8f0;padding:24px;box-shadow:0 4px 20px rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:space-between;gap:18px;position:relative;overflow:hidden">
          <div style="position:absolute;top:0;right:0;background:#0369a1;color:#fff;font-size:10px;font-weight:900;padding:4px 12px;border-bottom-left-radius:12px;text-transform:uppercase;letter-spacing:0.5px">
            ${esc(selectedServer.name)}
          </div>

          <div>
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-top:4px">
              <span style="background:#f97316;color:#fff;font-weight:bold;font-size:10px;padding:3px 10px;border-radius:999px;text-transform:uppercase">
                ${esc(plan.badge && plan.badge !== 'Virtualizor KVM' ? plan.badge : '⚡ TATKAL READY • NVMe')}
              </span>
              <span style="font-size:24px;font-weight:900;color:#ea580c;font-family:monospace">
                ₹${plan.price}<span style="font-size:12px;color:#94a3b8">/mo</span>
              </span>
            </div>

            <h4 style="font-size:18px;font-weight:900;color:#0f172a;margin:12px 0 8px">
              ${esc(plan.name)}
            </h4>

            <div style="background:#f8fafc;border:1px solid #f1f5f9;border-radius:16px;padding:12px;display:grid;gap:8px;font-size:12px;color:#475569">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:#ea580c;font-weight:bold">⚡</span>
                <span><b>${plan.cpuCores || 2}</b> vCPU Cores</span>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:#ea580c;font-weight:bold">🧠</span>
                <span><b>${plan.ramGB || 4} GB</b> RAM (ECC High Speed)</span>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <span style="color:#ea580c;font-weight:bold">💾</span>
                <span><b>${plan.diskGB || 60} GB</b> NVMe SSD Storage</span>
              </div>
            </div>

            <div style="margin-top:14px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:14px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:16px">🪟</span>
                <div>
                  <div style="font-size:12px;font-weight:900;color:#14532d">Windows Server 2022</div>
                  <div style="font-size:10px;color:#15803d;font-weight:600">Fixed Pre-installed OS (Customer Option Locked)</div>
                </div>
              </div>
              <span style="background:#16a34a;color:#fff;font-size:9px;font-weight:900;padding:2px 7px;border-radius:999px;text-transform:uppercase">FIXED</span>
            </div>

            <div style="margin-top:8px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:16px">🔐</span>
                <div>
                  <div style="font-size:12px;font-weight:900;color:#334155">Auto-Generated Password</div>
                  <div style="font-size:10px;color:#64748b;font-family:monospace">Pattern: Vps@... (No manual input needed)</div>
                </div>
              </div>
              <span style="background:#0284c7;color:#fff;font-size:9px;font-weight:900;padding:2px 7px;border-radius:999px;text-transform:uppercase">AUTOMATIC</span>
            </div>
          </div>

          <button data-order-vps="1" data-plan='${esc(JSON.stringify(plan))}' type="button" style="width:100%;padding:12px;background:linear-gradient(135deg,#ea580c,#c2410c);border:0;border-radius:14px;color:#fff;font-weight:900;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 15px rgba(234,88,12,0.3);transition:all .2s">
            <span>⚡ Order Now (Promocode & Bonus Available)</span>
          </button>
        </div>
      `;
    }).join('');

    Array.prototype.forEach.call(dynamicGrid.querySelectorAll('button[data-order-vps]'), function (btn) {
      btn.onclick = function () {
        var planData = JSON.parse(btn.dataset.plan);
        openVpsOrderModal(planData, selectedServer);
      };
    });
  }

  // =========================================================================
  // 4. INTERACTIVE VPS ORDER MODAL WITH PROMOCODE, BONUS BALANCE & CASHBACK
  // =========================================================================

  function openVpsOrderModal(plan, server) {
    var user = getStorage('sh_current_user', null);
    if (!user || !user.id) {
      alert('Please login to your account to order a Cloud VPS.');
      return;
    }

    var existing = document.getElementById('tg-vps-checkout-modal');
    if (existing) existing.remove();

    var basePrice = Number(plan.price);
    var appliedCoupon = null;
    var promoDiscount = 0;
    var useBonus = true;
    var bonusDiscount = 0;

    var apiSettings = getStorage('sh_api_settings', {});
    var bonusConfig = apiSettings.registrationBonusSettings || { enabled: true, maxBonusPerProduct: 300, maxBonusPercentage: 50 };

    var modal = document.createElement('div');
    modal.id = 'tg-vps-checkout-modal';
    modal.style.cssText = 'position:fixed;inset:0;z-index:999999;background:rgba(2,6,23,0.85);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:16px;overflow:auto';

    function calculateDiscounts() {
      // 1. Promo discount
      promoDiscount = 0;
      if (appliedCoupon) {
        if (appliedCoupon.discountType === 'percentage') {
          promoDiscount = Math.round((basePrice * Number(appliedCoupon.discountValue || 0)) / 100);
        } else {
          promoDiscount = Math.min(basePrice, Number(appliedCoupon.discountValue || 0));
        }
      }

      var afterPromo = Math.max(0, basePrice - promoDiscount);

      // 2. Bonus Balance discount
      bonusDiscount = 0;
      var userBonus = Number(user.bonusBalance || 0);
      if (useBonus && bonusConfig.enabled && userBonus > 0) {
        var maxAllowedByPercent = Math.round((afterPromo * Number(bonusConfig.maxBonusPercentage || 50)) / 100);
        var maxAllowedFixed = Number(bonusConfig.maxBonusPerProduct || 300);
        var limit = Math.min(maxAllowedByPercent, maxAllowedFixed, afterPromo);
        bonusDiscount = Math.min(userBonus, limit);
      }

      var finalPayable = Math.max(0, afterPromo - bonusDiscount);
      var cashbackEst = Math.round(finalPayable * 0.05); // 5% promotional cashback bonus

      return {
        basePrice: basePrice,
        promoDiscount: promoDiscount,
        bonusDiscount: bonusDiscount,
        finalPayable: finalPayable,
        cashback: cashbackEst
      };
    }

    function renderModalContent() {
      var calc = calculateDiscounts();
      var walletBal = Number(user.walletBalance || 0);
      var userBonus = Number(user.bonusBalance || 0);
      var canPay = walletBal >= calc.finalPayable;

      modal.innerHTML = `
        <div style="background:#0f172a;border:1px solid #334155;border-radius:24px;width:100%;max-width:520px;color:#fff;overflow:hidden;box-shadow:0 25px 60px rgba(0,0,0,0.5)">
          <!-- Header -->
          <div style="padding:18px 24px;background:linear-gradient(135deg,#0369a1,#0284c7);display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:1px;color:#bae6fd">⚡ Tatkal Cloud VPS Checkout</div>
              <div style="font-size:18px;font-weight:900;color:#fff">${esc(plan.name)}</div>
            </div>
            <button id="tg-btn-modal-close" type="button" style="background:rgba(0,0,0,0.2);border:0;border-radius:999px;width:32px;height:32px;color:#fff;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center">✕</button>
          </div>

          <!-- Body -->
          <div style="padding:20px 24px;display:grid;gap:16px">
            <!-- Plan Specs Details -->
            <div style="background:#1e293b;border:1px solid #334155;border-radius:14px;padding:12px;font-size:12px;display:grid;grid-template-columns:1fr 1fr;gap:8px">
              <div>📍 Node: <b>${esc(server.name)}</b></div>
              <div>⚡ Cores: <b>${plan.cpuCores || 2} vCPU</b></div>
              <div>🧠 RAM: <b>${plan.ramGB || 4} GB High-Speed</b></div>
              <div>💾 NVMe SSD: <b>${plan.diskGB || 60} GB</b></div>
              <div style="grid-column:1/-1;color:#4ade80;font-weight:bold">🪟 OS: Windows Server 2022 (Fixed Pre-installed)</div>
              <div style="grid-column:1/-1;color:#38bdf8;font-size:11px">🔐 Root Password: Auto-Generated (Pattern: Vps@...)</div>
            </div>

            <!-- Promocode / Coupon Section -->
            <div style="background:#020617;border:1px solid #1e293b;border-radius:14px;padding:14px">
              <label style="font-size:11px;font-weight:bold;color:#cbd5e1;display:block;margin-bottom:6px">🎟️ Apply Promocode / Coupon</label>
              <div style="display:flex;gap:8px">
                <input id="tg-modal-coupon-input" type="text" placeholder="Enter coupon code (e.g. WELCOME10, SUPER50)" value="${appliedCoupon ? esc(appliedCoupon.code) : ''}" style="flex:1;background:#0f172a;border:1px solid #334155;border-radius:10px;padding:8px 12px;color:#fff;font-size:12px;font-weight:bold;text-transform:uppercase">
                <button id="tg-modal-coupon-btn" type="button" style="padding:8px 16px;background:#0284c7;border:0;border-radius:10px;color:#fff;font-weight:bold;font-size:12px;cursor:pointer">
                  ${appliedCoupon ? 'Remove' : 'Apply'}
                </button>
              </div>
              <div id="tg-modal-coupon-msg" style="font-size:11px;margin-top:6px">
                ${appliedCoupon ? `<span style="color:#4ade80;font-weight:bold">✓ Coupon "${esc(appliedCoupon.code)}" applied! Discount: ₹${calc.promoDiscount}</span>` : ''}
              </div>
            </div>

            <!-- Bonus Balance Section -->
            ${userBonus > 0 ? `
              <div style="background:#020617;border:1px solid #1e293b;border-radius:14px;padding:12px;display:flex;align-items:center;justify-content:space-between;gap:10px">
                <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer">
                  <input id="tg-modal-bonus-check" type="checkbox" ${useBonus ? 'checked' : ''} style="width:16px;height:16px;accent-color:#ea580c">
                  <div>
                    <span style="font-weight:bold;color:#f97316">🎁 Use Registration / Bonus Balance</span>
                    <div style="font-size:10px;color:#94a3b8">Available Bonus: ₹${userBonus.toFixed(2)} (Max discount: 50%)</div>
                  </div>
                </label>
                <div style="font-size:12px;font-weight:900;color:#4ade80">-₹${calc.bonusDiscount}</div>
              </div>
            ` : ''}

            <!-- Cashback Notice -->
            <div style="background:rgba(22,163,74,0.1);border:1px solid rgba(22,163,74,0.3);border-radius:12px;padding:10px 14px;display:flex;align-items:center;gap:8px;font-size:11px;color:#86efac">
              <span>💰</span>
              <span><b>Promotional Cashback:</b> ₹${calc.cashback} bonus cashback reward will be credited to your account upon server activation!</span>
            </div>

            <!-- Price Breakdown -->
            <div style="background:#1e293b;border:1px solid #334155;border-radius:14px;padding:14px;display:grid;gap:6px;font-size:12px">
              <div style="display:flex;justify-content:space-between;color:#cbd5e1">
                <span>Plan Base Price:</span>
                <span style="font-family:monospace;font-weight:bold">₹${calc.basePrice}</span>
              </div>
              ${calc.promoDiscount > 0 ? `
                <div style="display:flex;justify-content:space-between;color:#4ade80">
                  <span>Promocode Discount:</span>
                  <span style="font-family:monospace;font-weight:bold">-₹${calc.promoDiscount}</span>
                </div>
              ` : ''}
              ${calc.bonusDiscount > 0 ? `
                <div style="display:flex;justify-content:space-between;color:#4ade80">
                  <span>Bonus Balance Used:</span>
                  <span style="font-family:monospace;font-weight:bold">-₹${calc.bonusDiscount}</span>
                </div>
              ` : ''}
              <div style="height:1px;background:#334155;margin:4px 0"></div>
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:14px">
                <span style="font-weight:900;color:#fff">Final Wallet Amount to Pay:</span>
                <span style="font-size:20px;font-weight:900;color:#f97316;font-family:monospace">₹${calc.finalPayable}</span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:11px;color:#94a3b8;margin-top:2px">
                <span>Your Current Wallet Balance:</span>
                <span style="font-weight:bold;color:${canPay ? '#4ade80' : '#f87171'}">₹${walletBal.toFixed(2)}</span>
              </div>
            </div>

            <!-- Action Button -->
            ${canPay ? `
              <button id="tg-modal-btn-deploy" type="button" style="width:100%;padding:14px;background:linear-gradient(135deg,#ea580c,#c2410c);border:0;border-radius:14px;color:#fff;font-weight:900;font-size:14px;cursor:pointer;box-shadow:0 4px 20px rgba(234,88,12,0.4);display:flex;align-items:center;justify-content:center;gap:8px">
                <span>⚡ Pay ₹${calc.finalPayable} & Deploy Windows Server 2022</span>
              </button>
            ` : `
              <div style="display:grid;gap:8px">
                <div style="text-align:center;color:#f87171;font-size:11px;font-weight:bold">
                  ⚠️ Insufficient balance! Needed ₹${calc.finalPayable}, Available ₹${walletBal.toFixed(2)}
                </div>
                <button id="tg-modal-btn-add-funds" type="button" style="width:100%;padding:12px;background:#0284c7;border:0;border-radius:14px;color:#fff;font-weight:bold;font-size:13px;cursor:pointer">
                  💳 Add Funds to Wallet
                </button>
              </div>
            `}
          </div>
        </div>
      `;

      // Attach Modal Handlers
      document.getElementById('tg-btn-modal-close').onclick = function () { modal.remove(); };

      var bonusCheck = document.getElementById('tg-modal-bonus-check');
      if (bonusCheck) {
        bonusCheck.onchange = function () {
          useBonus = bonusCheck.checked;
          renderModalContent();
        };
      }

      var couponBtn = document.getElementById('tg-modal-coupon-btn');
      if (couponBtn) {
        couponBtn.onclick = function () {
          if (appliedCoupon) {
            appliedCoupon = null;
            renderModalContent();
            return;
          }
          var codeInput = document.getElementById('tg-modal-coupon-input');
          var code = (codeInput ? codeInput.value : '').trim().toUpperCase();
          if (!code) {
            alert('Please enter a coupon code.');
            return;
          }
          var coupons = getStorage('sh_coupons', []);
          var found = coupons.find(function (c) { return c.code && c.code.toUpperCase() === code && c.isActive; });
          if (!found) {
            alert('Invalid or expired coupon code.');
            return;
          }
          if (found.minOrderAmount && basePrice < Number(found.minOrderAmount)) {
            alert('Coupon requires a minimum order of ₹' + found.minOrderAmount);
            return;
          }
          appliedCoupon = found;
          renderModalContent();
        };
      }

      var btnAddFunds = document.getElementById('tg-modal-btn-add-funds');
      if (btnAddFunds) {
        btnAddFunds.onclick = function () {
          modal.remove();
          var walletLink = [].find.call(document.querySelectorAll('button'), function (b) { return /Add Funds|Add Balance/i.test(b.textContent || ''); });
          if (walletLink) walletLink.click();
          else window.location.hash = '#dashboard';
        };
      }

      var btnDeploy = document.getElementById('tg-modal-btn-deploy');
      if (btnDeploy) {
        btnDeploy.onclick = async function () {
          btnDeploy.disabled = true;
          btnDeploy.innerHTML = '<span>⏳ Provisioning Windows Server 2022 on ' + esc(server.name) + '...</span>';

          var calcFinal = calculateDiscounts();
          var autoPass = 'Vps@';
          var hex = '0123456789abcdef';
          for (var i = 0; i < 14; i++) autoPass += hex.charAt(Math.floor(Math.random() * hex.length));
          var vncPass = 'VNC' + Math.floor(10000 + Math.random() * 90000);

          try {
            var resp = await fetch('./api/vps.php', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                action: 'create',
                serverId: server.id,
                serverName: server.name,
                userId: user.id,
                email: user.email,
                planName: plan.name,
                ramGB: plan.ramGB || 4,
                cpuCores: plan.cpuCores || 2,
                diskGB: plan.diskGB || 60,
                price: calcFinal.finalPayable,
                os: 'Windows Server 2022',
                vncPassword: vncPass,
                rootPassword: autoPass
              })
            });

            var result = await resp.json();
            if (!resp.ok || !result.ok) {
              throw new Error(result.message || 'VPS provisioning failed.');
            }

            // Deduct Wallet & Bonus
            user.walletBalance = Math.max(0, user.walletBalance - calcFinal.finalPayable);
            if (calcFinal.bonusDiscount > 0) {
              user.bonusBalance = Math.max(0, (user.bonusBalance || 0) - calcFinal.bonusDiscount);
            }
            // Credit Cashback to Wallet
            if (calcFinal.cashback > 0) {
              user.walletBalance += calcFinal.cashback;
            }
            setStorage('sh_current_user', user);

            // Update in sh_users
            var users = getStorage('sh_users', []);
            var uIdx = users.findIndex(function (u) { return u.id === user.id; });
            if (uIdx >= 0) {
              users[uIdx].walletBalance = user.walletBalance;
              users[uIdx].bonusBalance = user.bonusBalance;
              setStorage('sh_users', users);
            }

            // Add VPS instance
            var vpsList = getStorage('sh_vps_instances', []);
            var createdVPS = result.vps || {};
            createdVPS.serverId = server.id;
            createdVPS.serverName = server.name;
            createdVPS.os = 'Windows Server 2022';
            createdVPS.username = 'Administrator';
            createdVPS.rootPassword = createdVPS.rootPassword || autoPass;
            createdVPS.vncPassword = createdVPS.vncPassword || vncPass;
            vpsList.unshift(createdVPS);
            setStorage('sh_vps_instances', vpsList);

            // Add Order
            var orders = getStorage('sh_orders', []);
            orders.unshift({
              id: 'ord_' + Date.now(),
              userId: user.id,
              userEmail: user.email,
              userMobile: user.mobile || '',
              productName: plan.name + ' (' + server.name + ')',
              category: 'vps',
              price: basePrice,
              amount: calcFinal.finalPayable,
              discountApplied: calcFinal.promoDiscount + calcFinal.bonusDiscount,
              promoCode: appliedCoupon ? appliedCoupon.code : null,
              bonusUsed: calcFinal.bonusDiscount,
              cashbackCredited: calcFinal.cashback,
              status: 'completed',
              createdAt: new Date().toISOString(),
              details: {
                serverId: server.id,
                serverName: server.name,
                ipAddress: createdVPS.ipAddress,
                os: 'Windows Server 2022',
                username: 'Administrator',
                rootPassword: createdVPS.rootPassword,
                vncPassword: createdVPS.vncPassword,
                vpsId: createdVPS.virtualizorVpsId
              }
            });
            setStorage('sh_orders', orders);

            // Increment coupon usage
            if (appliedCoupon) {
              var allCoupons = getStorage('sh_coupons', []);
              var cIdx = allCoupons.findIndex(function (c) { return c.id === appliedCoupon.id; });
              if (cIdx >= 0) {
                allCoupons[cIdx].usedCount = (allCoupons[cIdx].usedCount || 0) + 1;
                setStorage('sh_coupons', allCoupons);
              }
            }

            modal.remove();

            alert(
              '🎉 VPS DEPLOYED SUCCESSFULLY ON ' + server.name.toUpperCase() + '!\n\n' +
              'IP Address: ' + (createdVPS.ipAddress || 'Allocated') + '\n' +
              'Operating System: Windows Server 2022 Standard\n' +
              'Administrator Username: Administrator\n' +
              'Root Password: ' + (createdVPS.rootPassword || autoPass) + '\n' +
              'VNC Password: ' + (createdVPS.vncPassword || vncPass) + '\n\n' +
              (calcFinal.cashback > 0 ? '💰 ₹' + calcFinal.cashback + ' Promotional Cashback credited to your wallet!\n\n' : '') +
              'Your VPS is live and ready in "Your Active VPS Instances".');

            window.location.reload();
          } catch (err) {
            alert('Failed to deploy VPS:\n\n' + err.message);
            btnDeploy.disabled = false;
            renderModalContent();
          }
        };
      }
    }

    renderModalContent();
    document.body.appendChild(modal);
  }

  // =========================================================================
  // 5. HOME PAGE VPS BANNER & NAVIGATION INTEGRATION
  // =========================================================================

  function enhanceHomePage() {
    var isHome = window.location.hash === '' || window.location.hash === '#home' || (!window.location.hash.includes('vps') && !window.location.hash.includes('admin'));
    if (!isHome) return;

    // 1. Hide category "vps" products from home store grid
    var allCards = document.querySelectorAll('div[class*="rounded-3xl"], div[class*="rounded-2xl"]');
    Array.prototype.forEach.call(allCards, function (card) {
      if (/vps_f|vps_p|Fast VPS|Premium VPS|PROMAX VPS -|EXTREME VPS -/i.test(card.textContent || '') && !card.id.includes('tg-home-vps') && !card.closest('#tg-dynamic-vps-products-grid')) {
        if (card.querySelector('button') && /Direct Buy|Buy Now/i.test(card.textContent || '')) {
          card.style.display = 'none';
        }
      }
    });

    // 2. Intercept category filter clicks on "VPS Host"
    var catButtons = document.querySelectorAll('button');
    Array.prototype.forEach.call(catButtons, function (b) {
      if (/VPS Host|VPS Server|Cloud VPS/i.test(b.textContent || '') && !b.dataset.tgVpsNavHooked) {
        b.dataset.tgVpsNavHooked = '1';
        b.onclick = function (e) {
          e.preventDefault();
          e.stopPropagation();
          window.location.hash = '#vps';
          window.dispatchEvent(new Event('hashchange'));
        };
      }
    });

    // 3. Inject prominent Tatkal Cloud VPS Banner on Home Page
    var existingBanner = document.getElementById('tg-home-vps-banner');
    if (!existingBanner) {
      var targetAnchor = [].find.call(document.querySelectorAll('div'), function (d) {
        return /All Services|Available Products|Search products/i.test(d.textContent || '') && d.querySelector('button');
      });

      if (targetAnchor && targetAnchor.parentElement) {
        var banner = document.createElement('div');
        banner.id = 'tg-home-vps-banner';
        banner.style.cssText = 'margin:20px 0;background:linear-gradient(135deg,#020617,#0f172a);border:1px solid #1e293b;border-radius:24px;padding:22px;color:#fff;box-shadow:0 10px 30px rgba(0,0,0,0.3);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px';
        banner.innerHTML = `
          <div style="flex:1;min-width:280px">
            <span style="background:#ea580c;color:#fff;font-size:10px;font-weight:900;padding:3px 10px;border-radius:999px;text-transform:uppercase;letter-spacing:0.5px">⚡ ULTRA HIGH-SPEED CLOUD INFRASTRUCTURE</span>
            <h3 style="font-size:20px;font-weight:900;margin:8px 0 4px;color:#fff">
              High-Speed Tatkal Cloud VPS (Windows Server 2022 Pre-Configured)
            </h3>
            <p style="font-size:12px;color:#94a3b8;margin:0;max-width:640px;line-height:1.5">
              Dedicated NVMe SSD Cloud instances engineered with &lt;2ms ping for IRCTC Tatkal automation, auto-booking bots, and 1Gbps unmetered bandwidth. Instant 1-click cloud provisioning with auto-generated credentials.
            </p>
          </div>
          <button id="tg-home-btn-explore-vps" type="button" style="padding:12px 24px;background:linear-gradient(135deg,#ea580c,#c2410c);border:0;border-radius:14px;color:#fff;font-weight:900;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:8px;box-shadow:0 4px 15px rgba(234,88,12,0.4);transition:all .2s">
            <span>🚀 Explore & Deploy Cloud VPS Now →</span>
          </button>
        `;
        targetAnchor.parentElement.insertBefore(banner, targetAnchor);

        document.getElementById('tg-home-btn-explore-vps').onclick = function () {
          window.location.hash = '#vps';
          window.dispatchEvent(new Event('hashchange'));
        };
      }
    }
  }

  // =========================================================================
  // PERIODIC MONITOR & INITIALIZATION
  // =========================================================================

  function runAll() {
    renderAdminMultiServerHub();
    enhanceProductManager();
    enhanceUserVPSPage();
    enhanceHomePage();
  }

  setInterval(runAll, 1000);
  window.addEventListener('hashchange', runAll);
  window.addEventListener('load', runAll);
  window.addEventListener('storage', runAll);
  window.addEventListener('tg-storage-update', runAll);
  runAll();
})();

/**
 * Tatkal Guru - Fast AI Support (3 Dedicated Support Engines)
 * 1. ⚡ Fast AI 1: Live General & Software Support
 * 2. 🚄 Fast AI 2: Tatkal Timing & Server Speed Expert
 * 3. 💳 Fast AI 3: Wallet, Cashback & OTP Billing Assistant
 */
(function () {
  'use strict';

  var isOpen = false;
  var isSending = false;
  var currentEngine = 'general'; // 'general' | 'tatkal' | 'billing'

  var engineConfigs = {
    general: {
      name: 'Fast AI 1',
      label: '⚡ Fast Live Support',
      tagline: 'Instant 24x7 Help & Guidance',
      greeting: 'Namaste! Main **Tatkal Guru Fast AI 1** hoon. Tatkal software, VPS setup, instant stock access aur portal guide me madad ke liye ready hoon!',
      chips: [
        { q: 'Tatkal booking timing kya hai?', text: '🚄 Tatkal Time' },
        { q: 'Tatkal ke liye best VPS kaun sa hai?', text: '💻 Best VPS' },
        { q: 'Wallet balance recharge kaise karein?', text: '💰 Add Wallet' },
        { q: 'SMS OTP service kaise use karein?', text: '📱 SMS OTP' },
        { q: 'Tatkal software license key kaise milegi?', text: '🔑 Software Key' }
      ]
    },
    tatkal: {
      name: 'Tatkal Speed Expert',
      label: '🚄 Tatkal Speed Expert',
      tagline: '10 AM AC / 11 AM Sleeper Latency & Nodes',
      greeting: 'Namaste! Main **Tatkal Guru Speed Expert AI** hoon. AC Tatkal (10:00 AM IST) aur Sleeper Tatkal (11:00 AM IST) ke live server ping, low-latency nodes, captcha handling aur autofill timing tips me help karunga.',
      chips: [
        { q: 'AC Tatkal 10 AM ke liye best server settings kya hain?', text: '⚡ AC 10 AM Tips' },
        { q: 'Sleeper Tatkal 11 AM par low-ping VPS kaise select karein?', text: '🚄 Sleeper 11 AM' },
        { q: 'Browser autofill aur payment latency reduce kaise karein?', text: '🚀 Zero Latency' },
        { q: 'Tatkal software installation guide kya hai?', text: '⚙️ Setup Guide' }
      ]
    },
    billing: {
      name: 'Wallet & OTP Assistant',
      label: '💳 Wallet & OTP Assistant',
      tagline: 'UTR Approvals, Cashback & SMS Numbers',
      greeting: 'Namaste! Main **Tatkal Guru Wallet & OTP Assistant** hoon. UPI QR payment, UTR reference approval, Cashback campaigns aur IRCTC fast SMS OTP numbers me help karunga.',
      chips: [
        { q: 'UPI payment UTR verify kaise hota hai?', text: '💸 UTR Approval' },
        { q: 'Cashback coupon code wallet me kaise credit hota hai?', text: '🎁 Cashback Code' },
        { q: 'IRCTC SMS OTP number kaise purchase karein?', text: '📱 Buy SMS Number' },
        { q: 'Wallet balance add karne me kitna time lagta hai?', text: '💳 Instant Credit' }
      ]
    }
  };

  var chatHistories = {
    general: [
      { role: 'ai', text: engineConfigs.general.greeting, time: formatTime(new Date()) }
    ],
    tatkal: [
      { role: 'ai', text: engineConfigs.tatkal.greeting, time: formatTime(new Date()) }
    ],
    billing: [
      { role: 'ai', text: engineConfigs.billing.greeting, time: formatTime(new Date()) }
    ]
  };

  function formatTime(d) {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderMarkdown(str) {
    var s = escHtml(str);
    s = s.replace(/\*\*(.*?)\*\*/g, '<strong style="color:#ffffff;font-weight:700;">$1</strong>');
    s = s.replace(/`([^`]+)`/g, '<code style="background:#1e293b;color:#fde047;padding:2px 6px;border-radius:4px;font-family:monospace;font-size:11px;">$1</code>');
    s = s.replace(/(?:^|\n)-\s+(.*?)(?=\n|$)/g, '<li style="margin-left:16px;list-style-type:disc;color:#cbd5e1;margin-top:2px;margin-bottom:2px;">$1</li>');
    s = s.replace(/(?:^|\n)(\d+)\.\s+(.*?)(?=\n|$)/g, '<li style="margin-left:16px;list-style-type:decimal;color:#cbd5e1;margin-top:2px;margin-bottom:2px;">$2</li>');
    s = s.replace(/\n/g, '<br/>');
    return s;
  }

  function fixStorageWhatsApp() {
    try {
      var tRaw = localStorage.getItem('sh_theme_settings');
      if (tRaw && tRaw.indexOf('91918900644148') >= 0) {
        var t = JSON.parse(tRaw);
        if (t.whatsappNumber === '91918900644148') t.whatsappNumber = '918900644148';
        if (t.popupBannerLink && t.popupBannerLink.indexOf('91918900644148') >= 0) {
          t.popupBannerLink = t.popupBannerLink.replace('91918900644148', '918900644148');
        }
        localStorage.setItem('sh_theme_settings', JSON.stringify(t));
      }
    } catch (e) {}
  }
  fixStorageWhatsApp();

  function isMobile() {
    return window.innerWidth < 640;
  }

  function toggleChat() {
    isOpen = !isOpen;
    var modal = document.getElementById('tg-gemini-chatbox');
    var backdrop = document.getElementById('tg-gemini-backdrop');

    if (isOpen) {
      if (!modal) {
        createChatBox();
        modal = document.getElementById('tg-gemini-chatbox');
        backdrop = document.getElementById('tg-gemini-backdrop');
      }
      if (modal) modal.style.display = 'flex';
      if (backdrop && isMobile()) backdrop.style.display = 'block';
      scrollToBottom();
      var input = document.getElementById('tg-ai-input');
      if (input) setTimeout(function () { input.focus(); }, 200);
    } else {
      if (modal) modal.style.display = 'none';
      if (backdrop) backdrop.style.display = 'none';
    }
  }

  window.toggleFastSupport = toggleChat;
  window.toggleGeminiChat = toggleChat;
  window.addEventListener('toggle-fast-support', toggleChat);
  window.addEventListener('open-gemini-chat', function () {
    if (!isOpen) toggleChat();
  });

  // Floating trigger button on bottom-right (USER REQUEST: "ai support bilkul niche karo")
  function renderFloatingTrigger() {
    var btn = document.getElementById('tg-fast-support-float-btn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'tg-fast-support-float-btn';
      btn.type = 'button';
      btn.title = 'Fast AI Support (24x7)';
      var bBottom = isMobile() ? '14px' : '16px';
      var bRight = isMobile() ? '68px' : '76px';
      btn.style.cssText = 'position:fixed;bottom:' + bBottom + ';right:' + bRight + ';z-index:999999;cursor:pointer;display:flex;align-items:center;gap:8px;padding:8px 14px;background:linear-gradient(135deg,#f59e0b,#ea580c);color:#050814;border:1px solid #fef08a;border-radius:9999px;font-weight:900;font-size:12px;font-family:system-ui,-apple-system,sans-serif;box-shadow:0 6px 20px rgba(245,158,11,0.45);transition:transform 0.15s ease,box-shadow 0.15s ease;user-select:none;-webkit-tap-highlight-color:transparent;';
      btn.innerHTML = `
        <span style="display:flex;align-items:center;justify-content:center;width:18px;height:18px;background:#050814;border-radius:50%;color:#f59e0b;font-size:11px;">⚡</span>
        <span>AI Support</span>
        <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px #22c55e;"></span>
      `;
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggleChat();
      });
      btn.addEventListener('touchend', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggleChat();
      });
      document.body.appendChild(btn);
    } else {
      btn.style.bottom = isMobile() ? '14px' : '16px';
      btn.style.right = isMobile() ? '68px' : '76px';
    }
  }

  function createChatBox() {
    if (document.getElementById('tg-gemini-chatbox')) return;

    // Mobile Backdrop
    var backdrop = document.createElement('div');
    backdrop.id = 'tg-gemini-backdrop';
    backdrop.style.cssText = 'position:fixed;inset:0;background:rgba(2,6,23,0.7);backdrop-filter:blur(4px);z-index:2147483640;display:none;';
    backdrop.addEventListener('click', toggleChat);
    document.body.appendChild(backdrop);

    // Chatbox Container
    var box = document.createElement('div');
    box.id = 'tg-gemini-chatbox';
    
    var baseBoxStyle = isMobile()
      ? 'position:fixed;bottom:0;left:0;right:0;width:100%;height:85vh;max-height:640px;border-radius:24px 24px 0 0;z-index:2147483647;display:flex;flex-direction:column;background:#090e1a;border:1px solid #1e293b;border-bottom:none;box-shadow:0 -10px 40px rgba(0,0,0,0.85);font-family:system-ui,-apple-system,sans-serif;color:#f1f5f9;overflow:hidden;'
      : 'position:fixed;bottom:24px;right:24px;width:420px;height:600px;max-height:calc(100vh - 48px);border-radius:20px;z-index:2147483647;display:flex;flex-direction:column;background:#090e1a;border:1px solid #1e293b;box-shadow:0 20px 50px rgba(0,0,0,0.85);font-family:system-ui,-apple-system,sans-serif;color:#f1f5f9;overflow:hidden;';

    box.style.cssText = baseBoxStyle;

    box.innerHTML = `
      <!-- Mobile Pull Bar -->
      <div style="display:${isMobile() ? 'flex' : 'none'};justify-content:center;padding:8px 0 2px 0;background:#0f172a;cursor:pointer;" id="tg-ai-drag-bar">
        <div style="width:36px;height:4px;background:#475569;border-radius:9999px;"></div>
      </div>

      <!-- Header -->
      <div style="padding:12px 16px;background:linear-gradient(135deg,#b45309,#ea580c,#0f172a);border-bottom:1px solid rgba(255,255,255,0.1);display:flex;align-items:center;justify-content:space-between;shrink:0;">
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#f59e0b,#ea580c);display:flex;align-items:center;justify-content:center;color:#050814;font-size:16px;font-weight:900;box-shadow:0 4px 12px rgba(245,158,11,0.4);">
            ⚡
          </div>
          <div>
            <div style="font-size:13px;font-weight:800;color:#ffffff;display:flex;align-items:center;gap:6px;" id="tg-ai-header-title">
              Tatkal Guru AI <span style="font-size:9px;background:rgba(253,224,71,0.2);color:#fde047;padding:1px 6px;border-radius:4px;border:1px solid rgba(253,224,71,0.3);font-weight:700;">24x7 LIVE</span>
            </div>
            <div style="font-size:10px;color:#86efac;display:flex;align-items:center;gap:4px;margin-top:1px;" id="tg-ai-header-tagline">
              <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px #22c55e;"></span> Tatkal, VPS & Wallet Support
            </div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          <button id="tg-ai-clear-btn" type="button" style="background:rgba(255,255,255,0.08);border:none;color:#94a3b8;width:30px;height:30px;border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;" title="Clear Chat">
            🗑️
          </button>
          <button id="tg-ai-close-btn" type="button" style="background:rgba(255,255,255,0.08);border:none;color:#ffffff;width:30px;height:30px;border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;" title="Close">
            ✕
          </button>
        </div>
      </div>

      <!-- 3-Engine Switcher -->
      <div style="display:flex;gap:4px;padding:6px 10px;background:#0c1322;border-bottom:1px solid #1e293b;shrink:0;font-size:11px;font-weight:700;">
        <button id="tg-tab-general" type="button" class="tg-eng-tab" data-eng="general" style="flex:1;padding:6px 4px;border:none;border-radius:8px;cursor:pointer;background:#f59e0b;color:#050814;font-weight:800;transition:all 0.15s ease;">
          ⚡ Live AI
        </button>
        <button id="tg-tab-tatkal" type="button" class="tg-eng-tab" data-eng="tatkal" style="flex:1;padding:6px 4px;border:none;border-radius:8px;cursor:pointer;background:transparent;color:#94a3b8;font-weight:700;transition:all 0.15s ease;">
          🚄 Tatkal Speed
        </button>
        <button id="tg-tab-billing" type="button" class="tg-eng-tab" data-eng="billing" style="flex:1;padding:6px 4px;border:none;border-radius:8px;cursor:pointer;background:transparent;color:#94a3b8;font-weight:700;transition:all 0.15s ease;">
          💳 Wallet & OTP
        </button>
      </div>

      <!-- Quick Chips Bar -->
      <div id="tg-ai-chips-container" style="display:flex;gap:6px;padding:8px 12px;background:#090e1a;border-bottom:1px solid rgba(255,255,255,0.05);overflow-x:auto;white-space:nowrap;shrink:0;scrollbar-width:none;">
      </div>

      <!-- Messages Stream -->
      <div id="tg-ai-messages" style="flex:1;padding:14px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;font-size:12px;line-height:1.5;">
      </div>

      <!-- Input Bar -->
      <div style="padding:10px 14px;background:#0c1322;border-top:1px solid #1e293b;shrink:0;">
        <form id="tg-ai-form" style="display:flex;align-items:center;gap:8px;margin:0;">
          <input
            id="tg-ai-input"
            type="text"
            autocomplete="off"
            placeholder="Type question for Fast AI Support..."
            style="flex:1;padding:10px 14px;background:#050814;color:#ffffff;font-size:12px;border-radius:12px;border:1px solid #334155;outline:none;transition:border-color 0.15s ease;"
          />
          <button
            id="tg-ai-send-btn"
            type="submit"
            style="padding:10px 16px;background:linear-gradient(135deg,#f59e0b,#ea580c);color:#050814;font-weight:900;font-size:12px;border-radius:12px;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:4px;box-shadow:0 4px 12px rgba(245,158,11,0.4);"
            title="Send"
          >
            <span>Send</span>
            <span>➤</span>
          </button>
        </form>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px;font-size:10px;color:#64748b;">
          <span id="tg-ai-status-label">⚡ Fast AI 1 (Live Support)</span>
          <span style="display:flex;align-items:center;gap:4px;color:#22c55e;font-weight:600;">
            <span style="width:5px;height:5px;border-radius:50%;background:#22c55e;"></span> Online
          </span>
        </div>
      </div>
    `;

    document.body.appendChild(box);

    // Event listeners
    document.getElementById('tg-ai-close-btn').addEventListener('click', toggleChat);
    var dragBar = document.getElementById('tg-ai-drag-bar');
    if (dragBar) dragBar.addEventListener('click', toggleChat);

    document.getElementById('tg-ai-clear-btn').addEventListener('click', function () {
      chatHistories[currentEngine] = [
        { role: 'ai', text: engineConfigs[currentEngine].greeting, time: formatTime(new Date()) }
      ];
      renderMessages();
    });

    // Engine switcher tabs
    box.querySelectorAll('.tg-eng-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        var eng = this.getAttribute('data-eng');
        switchEngine(eng);
      });
    });

    // Form submit
    document.getElementById('tg-ai-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var input = document.getElementById('tg-ai-input');
      var q = (input.value || '').trim();
      if (!q || isSending) return;
      input.value = '';
      submitQuery(q);
    });

    // Delegate copy button clicks
    document.getElementById('tg-ai-messages').addEventListener('click', function (e) {
      var btn = e.target.closest('.tg-copy-btn');
      if (btn) {
        var text = btn.getAttribute('data-copy') || '';
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text);
          } else {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
          }
          btn.textContent = 'Copied!';
          setTimeout(function () { btn.textContent = 'Copy'; }, 1500);
        } catch (err) {}
      }
    });

    // Handle resize
    window.addEventListener('resize', function () {
      if (!box) return;
      if (isMobile()) {
        box.style.cssText = 'position:fixed;bottom:0;left:0;right:0;width:100%;height:85vh;max-height:640px;border-radius:24px 24px 0 0;z-index:2147483647;display:' + (isOpen ? 'flex' : 'none') + ';flex-direction:column;background:#090e1a;border:1px solid #1e293b;border-bottom:none;box-shadow:0 -10px 40px rgba(0,0,0,0.85);font-family:system-ui,-apple-system,sans-serif;color:#f1f5f9;overflow:hidden;';
      } else {
        box.style.cssText = 'position:fixed;bottom:24px;right:24px;width:420px;height:600px;max-height:calc(100vh - 48px);border-radius:20px;z-index:2147483647;display:' + (isOpen ? 'flex' : 'none') + ';flex-direction:column;background:#090e1a;border:1px solid #1e293b;box-shadow:0 20px 50px rgba(0,0,0,0.85);font-family:system-ui,-apple-system,sans-serif;color:#f1f5f9;overflow:hidden;';
      }
    });

    switchEngine('general');
  }

  function switchEngine(eng) {
    if (!engineConfigs[eng]) eng = 'general';
    currentEngine = eng;
    var conf = engineConfigs[eng];

    // Update Tab Styles
    document.querySelectorAll('.tg-eng-tab').forEach(function (tab) {
      var isCur = tab.getAttribute('data-eng') === eng;
      if (isCur) {
        tab.style.background = '#f59e0b';
        tab.style.color = '#050814';
        tab.style.fontWeight = '800';
      } else {
        tab.style.background = 'transparent';
        tab.style.color = '#94a3b8';
        tab.style.fontWeight = '700';
      }
    });

    // Update Header
    var title = document.getElementById('tg-ai-header-title');
    if (title) title.innerHTML = escHtml(conf.name) + ' <span style="font-size:9px;background:rgba(253,224,71,0.2);color:#fde047;padding:1px 6px;border-radius:4px;border:1px solid rgba(253,224,71,0.3);font-weight:700;">24x7</span>';
    var tagline = document.getElementById('tg-ai-header-tagline');
    if (tagline) tagline.innerHTML = '<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#22c55e;box-shadow:0 0 6px #22c55e;"></span> ' + escHtml(conf.tagline);
    var statusLabel = document.getElementById('tg-ai-status-label');
    if (statusLabel) statusLabel.textContent = conf.label;

    // Render Chips
    var chipsBox = document.getElementById('tg-ai-chips-container');
    if (chipsBox) {
      chipsBox.innerHTML = conf.chips.map(function (c) {
        return '<button type="button" class="tg-chip" style="padding:4px 10px;background:#1e293b;color:#e2e8f0;border:1px solid #334155;border-radius:9999px;font-size:11px;font-weight:600;white-space:nowrap;cursor:pointer;transition:all 0.15s ease;" data-q="' + escHtml(c.q) + '">' + escHtml(c.text) + '</button>';
      }).join('');
      chipsBox.querySelectorAll('.tg-chip').forEach(function (chip) {
        chip.addEventListener('click', function () {
          var q = this.getAttribute('data-q');
          if (q) submitQuery(q);
        });
      });
    }

    renderMessages();
  }

  function renderMessages() {
    var container = document.getElementById('tg-ai-messages');
    if (!container) return;
    var history = chatHistories[currentEngine] || [];

    var html = '';
    history.forEach(function (msg, idx) {
      if (msg.role === 'user') {
        html += `
          <div style="display:flex;justify-content:flex-end;">
            <div style="max-width:85%;background:linear-gradient(135deg,#3b82f6,#6366f1);color:#ffffff;border-radius:16px 16px 4px 16px;padding:10px 14px;box-shadow:0 4px 12px rgba(59,130,246,0.3);">
              <div>${escHtml(msg.text)}</div>
              <div style="font-size:9px;color:rgba(255,255,255,0.7);text-align:right;margin-top:4px;">${msg.time}</div>
            </div>
          </div>
        `;
      } else {
        html += `
          <div style="display:flex;align-items:flex-start;gap:8px;">
            <div style="width:26px;height:26px;border-radius:8px;background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.3);color:#f59e0b;display:flex;align-items:center;justify-content:center;font-size:13px;shrink:0;margin-top:2px;">
              ⚡
            </div>
            <div style="max-width:88%;background:#0f172a;border:1px solid #1e293b;border-radius:4px 16px 16px 16px;padding:10px 14px;box-shadow:0 4px 12px rgba(0,0,0,0.4);color:#e2e8f0;">
              <div>${renderMarkdown(msg.text)}</div>
              <div style="display:flex;align-items:center;justify-content:space-between;font-size:9px;color:#64748b;margin-top:8px;border-top:1px solid rgba(255,255,255,0.05);padding-top:4px;">
                <span>${msg.time}</span>
                <button type="button" class="tg-copy-btn" data-copy="${escHtml(msg.text)}" style="background:transparent;border:none;color:#94a3b8;font-size:10px;cursor:pointer;padding:2px 4px;">Copy</button>
              </div>
            </div>
          </div>
        `;
      }
    });

    if (isSending) {
      html += `
        <div style="display:flex;align-items:flex-start;gap:8px;" id="tg-ai-typing">
          <div style="width:26px;height:26px;border-radius:8px;background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.3);color:#f59e0b;display:flex;align-items:center;justify-content:center;font-size:13px;shrink:0;margin-top:2px;">
            ⚡
          </div>
          <div style="background:#0f172a;border:1px solid #1e293b;border-radius:4px 16px 16px 16px;padding:10px 14px;box-shadow:0 4px 12px rgba(0,0,0,0.4);color:#94a3b8;display:flex;align-items:center;gap:6px;">
            <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#f59e0b;animation:tgPulse 1s infinite alternate;"></span>
            <span style="font-size:11px;">Fast AI is answering...</span>
          </div>
        </div>
      `;
    }

    container.innerHTML = html;
    scrollToBottom();
  }

  function scrollToBottom() {
    var container = document.getElementById('tg-ai-messages');
    if (container) {
      setTimeout(function () {
        container.scrollTop = container.scrollHeight;
      }, 50);
    }
  }

  // Fallback domain smart assistant if network is offline
  function getLocalDomainAnswer(prompt, engine) {
    var p = (prompt || '').toLowerCase();
    if (p.indexOf('tatkal') >= 0 && (p.indexOf('time') >= 0 || p.indexOf('timing') >= 0 || p.indexOf('samay') >= 0 || p.indexOf('kab') >= 0)) {
      return '🚄 **Tatkal Booking Timings:**\n- **AC Classes (2A, 3A, 3E, CC, EC):** Subah **10:00 AM** par open hota hai.\n- **Non-AC / Sleeper (SL, 2S):** Subah **11:00 AM** par open hota hai.\n\n⚡ **Speed Tip:** Hamare low-latency Indian VPS aur Fast Autofill tool ka use karke aap pehle 5 second me confirmed ticket process kar sakte hain.';
    }
    if (p.indexOf('vps') >= 0 || p.indexOf('server') >= 0 || p.indexOf('speed') >= 0 || p.indexOf('latency') >= 0) {
      return '💻 **Tatkal Guru VPS Features:**\n- **Ultra Low Ping:** Direct Mumbai/Delhi Datacenter (< 2ms ping to IRCTC servers).\n- **Virtualizor Control Panel:** Instant Start, Stop, Reboot aur Reinstall.\n- **Optimized OS:** Windows Server aur Linux jo Tatkal automation ke liye pre-tuned hain.';
    }
    if (p.indexOf('recharge') >= 0 || p.indexOf('wallet') >= 0 || p.indexOf('payment') >= 0 || p.indexOf('upi') >= 0 || p.indexOf('utr') >= 0) {
      return '💰 **Wallet Recharge & UTR Approval:**\n1. Website ke top ya sidebar me **Wallet / Add Balance** par click karein.\n2. Screen par aane wale **UPI QR Code** ko PhonePe, Google Pay ya Paytm se scan karein.\n3. Payment complete hone ke baad **12-digit UTR No.** enter karein.\n4. Submit karte hi balance instantly aapke wallet me add ho jayega.';
    }
    if (p.indexOf('sms') >= 0 || p.indexOf('otp') >= 0 || p.indexOf('number') >= 0) {
      return '📱 **SMS OTP Virtual Numbers:**\n- Tatkal Guru par aapko IRCTC, WhatsApp, Telegram, Google ke liye fresh Indian numbers milte hain.\n- Instant OTP delivery aur automatic refund agar 2 minute me OTP na mile.';
    }
    if (p.indexOf('software') >= 0 || p.indexOf('key') >= 0 || p.indexOf('license') >= 0 || p.indexOf('autofill') >= 0) {
      return '⚡ **Tatkal Software Licenses:**\n- Software purchase karte hi license key aur direct download link instantly delivered hoti hai.\n- Automatic master list fill aur UPI fast payment auto-trigger support shamil hai.';
    }
    if (engine === 'tatkal') {
      return '🚄 **Tatkal Speed Tip:** 10:00 AM AC Tatkal ke liye 09:58 AM par server clock sync karein. Sleeper ke liye 10:58 AM par login karein. Hamare low-latency VPS se captcha aur OTP latency 90% kam ho jati hai.';
    }
    if (engine === 'billing') {
      return '💳 **Wallet & Billing Help:** UPI QR se instant wallet recharge karein. Agar UTR verification me deri ho toh transaction history me UTR check karein ya Admin se contact karein.';
    }
    return '⚡ **Tatkal Guru AI Assistant:**\nAapke sawal "' + escHtml(prompt) + '" ke sandarbh me: Tatkal Guru portal par aapko high-speed Indian VPS, Tatkal automation software, instant SMS OTP verification aur automatic wallet delivery milti hai.\n\nKisi bhi madad ke liye upar diye gaye topic chips par click karein ya sawal poochein!';
  }

  function submitQuery(prompt) {
    if (!prompt || isSending) return;

    var history = chatHistories[currentEngine] || (chatHistories[currentEngine] = []);
    history.push({
      role: 'user',
      text: prompt,
      time: formatTime(new Date())
    });

    isSending = true;
    renderMessages();

    fetch('./api/gemini.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'ask',
        prompt: prompt,
        engine: currentEngine
      })
    })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (res) {
        var reply = res.answer || res.message || getLocalDomainAnswer(prompt, currentEngine);
        history.push({
          role: 'ai',
          text: reply,
          time: formatTime(new Date())
        });
      })
      .catch(function () {
        var reply = getLocalDomainAnswer(prompt, currentEngine);
        history.push({
          role: 'ai',
          text: reply,
          time: formatTime(new Date())
        });
      })
      .finally(function () {
        isSending = false;
        renderMessages();
      });
  }

  function checkTrigger() {
    renderFloatingTrigger();
  }

  setInterval(checkTrigger, 2000);
  setTimeout(checkTrigger, 300);
})();

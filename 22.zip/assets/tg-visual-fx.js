/**
 * Tatkal Guru - Background Visual Effects Engine (10 Types)
 * Features:
 * - 10 Rich Canvas Visual Effects (Matrix, Ambient Particles, Snow, Stars, Fireworks, Confetti, Geometric, Cyber Grid, Bubbles, Neon Pulse) + None.
 * - Crystal clear transparent canvas rendering (does NOT black out the screen).
 * - Fixed auto-defaulting bug: preserves user selection, never forces #1 Matrix as default.
 * - Integrated User Panel floating quick-switcher so users can switch or turn off effects.
 * - Real-time sync to localStorage and ./api/storage_sync.php backend.
 */
(function () {
  'use strict';

  var canvas = null;
  var ctx = null;
  var animFrameId = null;
  var currentEffect = 'none';
  var width = window.innerWidth;
  var height = window.innerHeight;

  var EFFECT_LIST = [
    { id: 'none', name: 'None (Clean Mode)', icon: '🚫' },
    { id: 'matrix', name: '1. Matrix Code Rain', icon: '🟢' },
    { id: 'particles', name: '2. Ambient Particles', icon: '🌐' },
    { id: 'snow', name: '3. Winter Falling Snow', icon: '❄️' },
    { id: 'stars', name: '4. Cosmic Twinkling Stars', icon: '✨' },
    { id: 'fireworks', name: '5. Explosive Fireworks', icon: '🎆' },
    { id: 'confetti', name: '6. Festive Confetti', icon: '🎉' },
    { id: 'geometric', name: '7. Geometric Node Net', icon: '📐' },
    { id: 'cybergrid', name: '8. 3D Cyber Grid', icon: '🕶️' },
    { id: 'bubbles', name: '9. Rising Bubbles', icon: '🫧' },
    { id: 'neonpulse', name: '10. Neon Pulse Perimeter', icon: '⚡' }
  ];

  function getThemeEffect() {
    try {
      // 1. User panel direct choice takes priority
      var userEff = localStorage.getItem('sh_user_visual_effect');
      if (userEff && isValidEffect(userEff)) return userEff;

      // 2. Admin theme settings
      var raw = localStorage.getItem('sh_theme_settings');
      if (raw) {
        var t = JSON.parse(raw);
        if (t && typeof t.visualEffect === 'string' && isValidEffect(t.visualEffect)) {
          return t.visualEffect;
        }
      }
    } catch (e) {}
    return 'none';
  }

  function isValidEffect(eff) {
    for (var i = 0; i < EFFECT_LIST.length; i++) {
      if (EFFECT_LIST[i].id === eff) return true;
    }
    return false;
  }

  function setVisualEffect(effId) {
    if (!isValidEffect(effId)) effId = 'none';
    try {
      localStorage.setItem('sh_user_visual_effect', effId);

      var t = {};
      try {
        t = JSON.parse(localStorage.getItem('sh_theme_settings') || '{}');
      } catch (e) {}
      t.visualEffect = effId;
      localStorage.setItem('sh_theme_settings', JSON.stringify(t));

      // Update sync meta timestamp so bootstrap won't overwrite
      var now = Date.now();
      try {
        var meta = JSON.parse(localStorage.getItem('sh_sync_meta') || '{}');
        meta.sh_theme_settings = now;
        localStorage.setItem('sh_sync_meta', JSON.stringify(meta));
      } catch (e) {}

      // Persist to server backend storage
      fetch('./api/storage_sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: {
            sh_theme_settings: {
              value: JSON.stringify(t),
              updatedAt: now
            }
          }
        })
      }).catch(function () {});
    } catch (e) {}

    setupEffect(effId);
    updateFxUi();
  }

  function initCanvas() {
    if (document.getElementById('tg-bg-fx-canvas')) {
      canvas = document.getElementById('tg-bg-fx-canvas');
      ctx = canvas.getContext('2d');
      return;
    }
    canvas = document.createElement('canvas');
    canvas.id = 'tg-bg-fx-canvas';
    // Transparent overlay with pointer-events:none so all clicks pass through cleanly
    canvas.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:1;overflow:hidden;';
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    resize();
  }

  function resize() {
    if (!canvas) return;
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);

  // State objects for effects
  var matrixCols = [];
  var particles = [];
  var snowFlakes = [];
  var stars = [];
  var shootingStars = [];
  var fireworks = [];
  var confettiPieces = [];
  var geoNodes = [];
  var cyberOffset = 0;
  var bubbles = [];
  var neonPulseAngle = 0;

  var CHARS = '0123456789ABCDEF@#$%&*アイウエオカキクケコサシスセソタチツテト';

  function setupEffect(eff) {
    resize();
    currentEffect = eff;
    if (!ctx) return;
    ctx.clearRect(0, 0, width, height);

    if (eff === 'matrix') {
      var cols = Math.floor(width / 20);
      matrixCols = [];
      for (var i = 0; i < cols; i++) {
        matrixCols.push({
          x: i * 20 + 2,
          y: Math.random() * -100 - 10,
          speed: Math.random() * 2.5 + 2.5,
          length: Math.floor(Math.random() * 14 + 10),
          chars: []
        });
      }
    } else if (eff === 'particles') {
      particles = [];
      var pCount = Math.min(65, Math.floor(width / 22));
      for (var p = 0; p < pCount; p++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 1.1,
          vy: (Math.random() - 0.5) * 1.1,
          radius: Math.random() * 2.5 + 1.2,
          color: p % 3 === 0 ? '#38bdf8' : (p % 3 === 1 ? '#818cf8' : '#34d399')
        });
      }
    } else if (eff === 'snow') {
      snowFlakes = [];
      var sCount = Math.min(80, Math.floor(width / 18));
      for (var s = 0; s < sCount; s++) {
        snowFlakes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: Math.random() * 3 + 1,
          speed: Math.random() * 1.6 + 0.8,
          sway: Math.random() * 2,
          swaySpeed: Math.random() * 0.02 + 0.01
        });
      }
    } else if (eff === 'stars') {
      stars = [];
      var starCount = Math.min(120, Math.floor(width / 12));
      for (var st = 0; st < starCount; st++) {
        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: Math.random() * 1.8 + 0.6,
          alpha: Math.random(),
          speed: Math.random() * 0.03 + 0.01
        });
      }
      shootingStars = [];
    } else if (eff === 'fireworks') {
      fireworks = [];
    } else if (eff === 'confetti') {
      confettiPieces = [];
      var cCount = Math.min(60, Math.floor(width / 25));
      var colors = ['#f43f5e', '#fbbf24', '#38bdf8', '#a855f7', '#34d399', '#fb923c'];
      for (var c = 0; c < cCount; c++) {
        confettiPieces.push({
          x: Math.random() * width,
          y: Math.random() * height,
          w: Math.random() * 10 + 6,
          h: Math.random() * 6 + 4,
          color: colors[c % colors.length],
          vy: Math.random() * 2 + 1.2,
          rot: Math.random() * 360,
          rotSpeed: (Math.random() - 0.5) * 6
        });
      }
    } else if (eff === 'geometric') {
      geoNodes = [];
      var gCount = Math.min(40, Math.floor(width / 35));
      for (var g = 0; g < gCount; g++) {
        geoNodes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 1.3,
          vy: (Math.random() - 0.5) * 1.3,
          radius: Math.random() * 3 + 2
        });
      }
    } else if (eff === 'cybergrid') {
      cyberOffset = 0;
    } else if (eff === 'bubbles') {
      bubbles = [];
      var bCount = Math.min(45, Math.floor(width / 30));
      for (var b = 0; b < bCount; b++) {
        bubbles.push({
          x: Math.random() * width,
          y: height + Math.random() * 200,
          radius: Math.random() * 14 + 6,
          vy: Math.random() * 1.6 + 0.8,
          wobble: Math.random() * Math.PI * 2,
          wobbleSpeed: Math.random() * 0.03 + 0.01,
          hue: Math.floor(Math.random() * 60 + 170)
        });
      }
    } else if (eff === 'neonpulse') {
      neonPulseAngle = 0;
    }
  }

  function render() {
    animFrameId = requestAnimationFrame(render);
    if (!ctx) return;

    var eff = currentEffect;
    if (eff === 'none') {
      ctx.clearRect(0, 0, width, height);
      return;
    }

    // Always clear canvas so the underlying website content remains 100% visible and un-blackened!
    ctx.clearRect(0, 0, width, height);

    if (eff === 'matrix') {
      ctx.font = '13px monospace';
      for (var i = 0; i < matrixCols.length; i++) {
        var col = matrixCols[i];
        col.y += col.speed;

        // Populate trailing characters
        var char = CHARS.charAt(Math.floor(Math.random() * CHARS.length));
        col.chars.unshift(char);
        if (col.chars.length > col.length) {
          col.chars.pop();
        }

        // Render each trailing character with fading opacity
        for (var j = 0; j < col.chars.length; j++) {
          var py = col.y - j * 16;
          if (py < -20 || py > height + 20) continue;

          if (j === 0) {
            // Bright white-green lead
            ctx.fillStyle = '#f0fdf4';
            ctx.shadowBlur = 8;
            ctx.shadowColor = '#4ade80';
            ctx.fillText(col.chars[j], col.x, py);
            ctx.shadowBlur = 0;
          } else {
            var alpha = Math.max(0.1, (1 - j / col.chars.length) * 0.75);
            ctx.fillStyle = 'rgba(74, 222, 128, ' + alpha + ')';
            ctx.fillText(col.chars[j], col.x, py);
          }
        }

        if (col.y - col.length * 16 > height && Math.random() > 0.95) {
          col.y = Math.random() * -80 - 20;
          col.speed = Math.random() * 2.5 + 2.5;
          col.chars = [];
        }
      }
    } else if (eff === 'particles') {
      for (var p = 0; p < particles.length; p++) {
        var pt = particles[p];
        pt.x += pt.vx;
        pt.y += pt.vy;
        if (pt.x < 0) pt.x = width;
        if (pt.x > width) pt.x = 0;
        if (pt.y < 0) pt.y = height;
        if (pt.y > height) pt.y = 0;

        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
        ctx.fillStyle = pt.color;
        ctx.shadowBlur = 6;
        ctx.shadowColor = pt.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        for (var q = p + 1; q < particles.length; q++) {
          var pt2 = particles[q];
          var dist = Math.hypot(pt.x - pt2.x, pt.y - pt2.y);
          if (dist < 95) {
            ctx.beginPath();
            ctx.moveTo(pt.x, pt.y);
            ctx.lineTo(pt2.x, pt2.y);
            ctx.strokeStyle = 'rgba(99, 102, 241, ' + (1 - dist / 95) * 0.3 + ')';
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }
    } else if (eff === 'snow') {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      for (var s = 0; s < snowFlakes.length; s++) {
        var sf = snowFlakes[s];
        sf.y += sf.speed;
        sf.sway += sf.swaySpeed;
        sf.x += Math.sin(sf.sway) * 0.8;
        if (sf.y > height) {
          sf.y = -10;
          sf.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(sf.x, sf.y, sf.radius, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (eff === 'stars') {
      for (var st = 0; st < stars.length; st++) {
        var star = stars[st];
        star.alpha += star.speed;
        var opacity = Math.abs(Math.sin(star.alpha)) * 0.8 + 0.1;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, ' + opacity + ')';
        ctx.fill();
      }
      if (Math.random() < 0.02 && shootingStars.length < 2) {
        shootingStars.push({
          x: Math.random() * width,
          y: Math.random() * (height / 2),
          length: Math.random() * 80 + 50,
          speed: Math.random() * 9 + 10,
          angle: Math.PI / 4 + (Math.random() - 0.5) * 0.2,
          opacity: 1
        });
      }
      for (var ss = shootingStars.length - 1; ss >= 0; ss--) {
        var sStar = shootingStars[ss];
        sStar.x += Math.cos(sStar.angle) * sStar.speed;
        sStar.y += Math.sin(sStar.angle) * sStar.speed;
        sStar.opacity -= 0.03;
        if (sStar.opacity <= 0) {
          shootingStars.splice(ss, 1);
          continue;
        }
        ctx.beginPath();
        ctx.moveTo(sStar.x, sStar.y);
        ctx.lineTo(sStar.x - Math.cos(sStar.angle) * sStar.length, sStar.y - Math.sin(sStar.angle) * sStar.length);
        ctx.strokeStyle = 'rgba(254, 240, 138, ' + sStar.opacity + ')';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    } else if (eff === 'fireworks') {
      if (Math.random() < 0.04 && fireworks.length < 4) {
        var fwColors = ['#f43f5e', '#fbbf24', '#38bdf8', '#a855f7', '#34d399', '#f97316'];
        var fwCol = fwColors[Math.floor(Math.random() * fwColors.length)];
        var targetX = Math.random() * (width - 200) + 100;
        var targetY = Math.random() * (height * 0.5) + 60;
        var sparks = [];
        for (var sp = 0; sp < 32; sp++) {
          var angle = (Math.PI * 2 * sp) / 32;
          var speed = Math.random() * 4 + 2;
          sparks.push({
            x: targetX,
            y: targetY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            alpha: 1,
            color: fwCol
          });
        }
        fireworks.push({ sparks: sparks });
      }
      for (var f = fireworks.length - 1; f >= 0; f--) {
        var fw = fireworks[f];
        var allDead = true;
        for (var k = 0; k < fw.sparks.length; k++) {
          var spark = fw.sparks[k];
          spark.x += spark.vx;
          spark.y += spark.vy;
          spark.vy += 0.07;
          spark.alpha -= 0.02;
          if (spark.alpha > 0) {
            allDead = false;
            ctx.beginPath();
            ctx.arc(spark.x, spark.y, 2.2, 0, Math.PI * 2);
            ctx.fillStyle = spark.color;
            ctx.globalAlpha = Math.max(0, spark.alpha);
            ctx.fill();
            ctx.globalAlpha = 1;
          }
        }
        if (allDead) fireworks.splice(f, 1);
      }
    } else if (eff === 'confetti') {
      for (var c = 0; c < confettiPieces.length; c++) {
        var cf = confettiPieces[c];
        cf.y += cf.vy;
        cf.rot += cf.rotSpeed;
        if (cf.y > height + 20) {
          cf.y = -20;
          cf.x = Math.random() * width;
        }
        ctx.save();
        ctx.translate(cf.x, cf.y);
        ctx.rotate((cf.rot * Math.PI) / 180);
        ctx.fillStyle = cf.color;
        ctx.fillRect(-cf.w / 2, -cf.h / 2, cf.w, cf.h);
        ctx.restore();
      }
    } else if (eff === 'geometric') {
      for (var g = 0; g < geoNodes.length; g++) {
        var gn = geoNodes[g];
        gn.x += gn.vx;
        gn.y += gn.vy;
        if (gn.x < 0 || gn.x > width) gn.vx *= -1;
        if (gn.y < 0 || gn.y > height) gn.vy *= -1;

        ctx.beginPath();
        ctx.arc(gn.x, gn.y, gn.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#6366f1';
        ctx.fill();

        for (var h = g + 1; h < geoNodes.length; h++) {
          var gn2 = geoNodes[h];
          var d = Math.hypot(gn.x - gn2.x, gn.y - gn2.y);
          if (d < 130) {
            ctx.beginPath();
            ctx.moveTo(gn.x, gn.y);
            ctx.lineTo(gn2.x, gn2.y);
            ctx.strokeStyle = 'rgba(99, 102, 241, ' + (1 - d / 130) * 0.25 + ')';
            ctx.stroke();
          }
        }
      }
    } else if (eff === 'cybergrid') {
      cyberOffset = (cyberOffset + 1.2) % 40;
      var horizon = height * 0.55;

      var grad = ctx.createLinearGradient(0, horizon - 80, 0, horizon + 20);
      grad.addColorStop(0, 'transparent');
      grad.addColorStop(1, 'rgba(168, 85, 247, 0.2)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, horizon - 80, width, 100);

      ctx.strokeStyle = 'rgba(6, 182, 212, 0.3)';
      ctx.lineWidth = 1.2;

      var numRays = 18;
      for (var r = -numRays; r <= numRays; r++) {
        var startX = width / 2 + r * 30;
        var endX = width / 2 + r * 140;
        ctx.beginPath();
        ctx.moveTo(startX, horizon);
        ctx.lineTo(endX, height);
        ctx.stroke();
      }

      for (var gy = horizon; gy < height; gy += 18) {
        var distRatio = (gy - horizon) / (height - horizon);
        var actualY = horizon + Math.pow(distRatio, 1.8) * (height - horizon) + (cyberOffset * distRatio * 0.4);
        if (actualY <= height) {
          ctx.beginPath();
          ctx.moveTo(0, actualY);
          ctx.lineTo(width, actualY);
          ctx.stroke();
        }
      }
    } else if (eff === 'bubbles') {
      for (var b = 0; b < bubbles.length; b++) {
        var bub = bubbles[b];
        bub.y -= bub.vy;
        bub.wobble += bub.wobbleSpeed;
        var bx = bub.x + Math.sin(bub.wobble) * 8;
        if (bub.y < -20) {
          bub.y = height + Math.random() * 50;
          bub.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(bx, bub.y, bub.radius, 0, Math.PI * 2);
        ctx.strokeStyle = 'hsla(' + bub.hue + ', 80%, 65%, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = 'hsla(' + bub.hue + ', 80%, 65%, 0.1)';
        ctx.fill();
      }
    } else if (eff === 'neonpulse') {
      neonPulseAngle += 0.04;
      var pulseAlpha = (Math.sin(neonPulseAngle) + 1) / 2 * 0.4 + 0.15;
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(236, 72, 153, ' + pulseAlpha + ')';
      ctx.shadowBlur = 16;
      ctx.shadowColor = '#ec4899';
      ctx.strokeRect(10, 10, width - 20, height - 20);
      ctx.shadowBlur = 0;
    }
  }

  // USER REQUEST: "Website me Effect wala option samne diya hai usko hata do"
  // Floating quick-switcher widget is removed from the website front.
  function createFxWidget() {
    var existing = document.getElementById('tg-fx-control-root');
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
  }

  function updateFxUi() {
    var eff = currentEffect;
    var activeObj = EFFECT_LIST.find(function (x) { return x.id === eff; }) || EFFECT_LIST[0];

    var iconEl = document.getElementById('tg-fx-active-icon');
    var labelEl = document.getElementById('tg-fx-active-label');
    var tagEl = document.getElementById('tg-fx-active-tag');

    if (iconEl) iconEl.textContent = activeObj.icon;
    if (labelEl) labelEl.textContent = activeObj.id === 'none' ? 'FX Off' : activeObj.name.replace(/^\d+\.\s*/, '');
    if (tagEl) {
      tagEl.textContent = activeObj.id === 'none' ? 'Clean' : 'Active';
      tagEl.style.background = activeObj.id === 'none' ? '#475569' : '#10b981';
    }

    var btns = document.querySelectorAll('.tg-fx-choice-btn');
    for (var b = 0; b < btns.length; b++) {
      var fxId = btns[b].getAttribute('data-fx');
      var check = btns[b].querySelector('.tg-fx-check');
      if (fxId === eff) {
        btns[b].style.background = '#1e1b4b';
        btns[b].style.borderColor = '#6366f1';
        btns[b].style.color = '#fff';
        if (check) check.style.display = 'inline';
      } else {
        btns[b].style.background = '#0f172a';
        btns[b].style.borderColor = '#1e293b';
        btns[b].style.color = '#cbd5e1';
        if (check) check.style.display = 'none';
      }
    }
  }

  // Intercept Admin Panel 1 "10 Visual FX" button clicks so they sync to server & update canvas
  function hookAdminPanelButtons() {
    var adminFxBtns = document.querySelectorAll('button');
    for (var i = 0; i < adminFxBtns.length; i++) {
      var btn = adminFxBtns[i];
      var txt = btn.textContent || '';
      for (var e = 0; e < EFFECT_LIST.length; e++) {
        var effItem = EFFECT_LIST[e];
        if (txt.indexOf(effItem.name) >= 0 && !btn.dataset.tgHooked) {
          btn.dataset.tgHooked = '1';
          (function (targetEffId) {
            btn.addEventListener('click', function () {
              setVisualEffect(targetEffId);
            });
          })(effItem.id);
        }
      }
    }
  }

  function start() {
    initCanvas();
    var eff = getThemeEffect();
    setupEffect(eff);
    if (animFrameId) cancelAnimationFrame(animFrameId);
    render();
    createFxWidget();
  }

  // Polling for external changes (Admin modal or other tabs)
  setInterval(function () {
    var eff = getThemeEffect();
    if (eff !== currentEffect) {
      setupEffect(eff);
      updateFxUi();
    }
    hookAdminPanelButtons();
  }, 1000);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }

  // Expose global for dev/debugging
  window.__tgVisualFX = {
    setEffect: setVisualEffect,
    getEffect: function () { return currentEffect; },
    effects: EFFECT_LIST
  };
})();

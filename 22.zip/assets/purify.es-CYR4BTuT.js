// Stub for purify.es needed by jspdf html worker
var DOMPurify = {
  sanitize: function(dirty) {
    if (typeof dirty !== 'string') return dirty;
    return dirty;
  },
  isSupported: true,
  addHook: function() {},
  removeHook: function() {},
  clearHooks: function() {},
  isValidAttribute: function() { return true; }
};

export default DOMPurify;
export { DOMPurify };

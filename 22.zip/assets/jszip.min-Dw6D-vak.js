// Stub for JSZip
class JSZip {
  constructor() {
    this.files = {};
  }
  file(name, data) {
    if (data !== undefined) {
      this.files[name] = data;
      return this;
    }
    return this.files[name];
  }
  folder() {
    return new JSZip();
  }
  async generateAsync() {
    return new Blob([]);
  }
}

export { JSZip as j };
export default JSZip;

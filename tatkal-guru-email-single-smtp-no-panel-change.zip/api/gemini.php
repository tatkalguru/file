<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__.'/dbcon.php';
// Gemini API key configured server-side. It is never sent to the browser.
const GEMINI_CONFIGURED_API_KEY = 'AQ.Ab8RN6L57E60_S22SKh3bAHF_e7vaYvh_TVJRM72UZhRXsGcyw';
function out(bool $ok,string $message,array $extra=[]): void { echo json_encode(array_merge(['ok'=>$ok,'message'=>$message],$extra),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function getSettings(): array { $pdo=db(); $q=$pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? LIMIT 1'); $q->execute(['sh_api_settings']); $r=$q->fetch(); $v=$r?json_decode((string)$r['storage_value'],true):[]; return is_array($v)?$v:[]; }
function saveSettings(array $s): void { $pdo=db(); $now=(int)round(microtime(true)*1000); $v=json_encode($s,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE); $q=$pdo->prepare('INSERT INTO app_storage(storage_key,storage_value,updated_at_ms) VALUES(?,?,?) ON DUPLICATE KEY UPDATE storage_value=VALUES(storage_value),updated_at_ms=VALUES(updated_at_ms)'); $q->execute(['sh_api_settings',$v,$now]); }
$in=json_decode(file_get_contents('php://input')?:'',true); if(!is_array($in)) out(false,'Invalid request.');
$cfg=getSettings(); $action=(string)($in['action']??'');
if($action==='setup'){
  $key=trim((string)($in['apiKey']??'')); if($key==='') $key=GEMINI_CONFIGURED_API_KEY; $email=filter_var((string)($in['adminEmail']??''),FILTER_VALIDATE_EMAIL);
  if($email===false) out(false,'Enter a valid admin email.');
  $cfg['geminiSettings']=['enabled'=>true,'apiKey'=>$key,'model'=>'gemini-3.8-flash'];
  $cfg['notificationSettings']=array_merge(is_array($cfg['notificationSettings']??null)?$cfg['notificationSettings']:[],['enabled'=>true,'adminEmail'=>$email]);
  saveSettings($cfg); out(true,'Gemini AI and email notification setup saved.');
}
if($action==='ask'){
  $g=$cfg['geminiSettings']??[]; $key=trim((string)($g['apiKey']??'')); if($key==='') $key=GEMINI_CONFIGURED_API_KEY; $model='gemini-3.8-flash'; $prompt=trim((string)($in['prompt']??''));
  if($prompt==='') out(false,'Enter a question.'); if($key==='') out(false,'Gemini API key is not configured. Open Admin → AI / Email Setup.');
  $url='https://generativelanguage.googleapis.com/v1beta/models/'.rawurlencode($model).':generateContent?key='.rawurlencode($key);
  $body=json_encode(['contents'=>[['parts'=>[['text'=>'You are the Tatkal Guru website support assistant. Give concise, practical help about account, orders, products, website setup and admin settings. Never ask for or expose passwords, API keys, OTPs, payment credentials or other secrets.\n\nUser question: '.$prompt]]]]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>$body,CURLOPT_TIMEOUT=>30]); $raw=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($raw===false||$err) out(false,'Gemini connection failed.'); $j=json_decode($raw,true); if($code<200||$code>=300) out(false,(string)($j['error']['message']??'Gemini API request failed.'));
  $answer=''; foreach(($j['candidates'][0]['content']['parts']??[]) as $part){$answer.=(string)($part['text']??'');} if($answer==='') out(false,'Gemini returned no answer.'); out(true,'OK',['answer'=>$answer]);
}
out(false,'Unknown action.');

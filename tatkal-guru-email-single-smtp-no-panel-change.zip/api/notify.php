<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__.'/dbcon.php';

function njson(bool $ok,string $message,array $extra=[]):void{echo json_encode(array_merge(['ok'=>$ok,'message'=>$message],$extra),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function nload(PDO $pdo,string $key,$default=[]){$q=$pdo->prepare('SELECT storage_value FROM app_storage WHERE storage_key=? LIMIT 1');$q->execute([$key]);$r=$q->fetch();if(!$r)return $default;$v=json_decode((string)$r['storage_value'],true);return is_array($v)?$v:$default;}
function nsave(PDO $pdo,string $key,$value):void{$q=$pdo->prepare('INSERT INTO app_storage(storage_key,storage_value,updated_at_ms) VALUES(?,?,?) ON DUPLICATE KEY UPDATE storage_value=VALUES(storage_value),updated_at_ms=VALUES(updated_at_ms)');$q->execute([$key,json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),(int)round(microtime(true)*1000)]);}
function esc($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function cfg(PDO $pdo):array{
 $s=nload($pdo,'sh_api_settings',[]);
 $n=is_array($s['notificationSettings']??null)?$s['notificationSettings']:[];
 // The existing Admin Panel > APIs & Payment Config > SMTP Mail Setup is the single source of truth.
 $existingMail=is_array($s['mailSettings']??null)?$s['mailSettings']:[];
 $defaultsMail=['enabled'=>true,'smtpHost'=>'','smtpPort'=>465,'smtpUser'=>'','smtpPass'=>'','senderName'=>'Tatkal Guru','senderEmail'=>'','encryption'=>'SSL','sendOrderEmail'=>true,'sendPasswordResetEmail'=>true];
 $mail=array_replace_recursive($defaultsMail,$existingMail);
 $notificationEmail=is_array($n['email']??null)?$n['email']:[];
 // Preserve only notification-specific toggle here; SMTP credentials always come from mailSettings.
 $mail['enabled']=array_key_exists('enabled',$notificationEmail)?(bool)$notificationEmail['enabled']:(bool)$mail['enabled'];
 $n['email']=$mail;
 $out=array_replace_recursive([
  'enabled'=>true,'adminEmail'=>'irsad98@gmail.com','adminMobile'=>'','adminWhatsApp'=>'','timezone'=>'Asia/Kolkata',
  'website'=>['enabled'=>true],
  'email'=>$mail,
  'sms'=>['enabled'=>false,'provider'=>'','apiUrl'=>'','apiKey'=>'','senderId'=>''],
  'whatsapp'=>['enabled'=>false,'mode'=>'api','apiUrl'=>'','apiToken'=>'','phoneId'=>'','template'=>'','webhookUrl'=>'']
 ],$n);
 $out['email']=array_replace($mail,is_array($out['email']??null)?$out['email']:[]);
 $out['email']['smtpHost']=$mail['smtpHost'];$out['email']['smtpPort']=$mail['smtpPort'];$out['email']['smtpUser']=$mail['smtpUser'];$out['email']['smtpPass']=$mail['smtpPass'];$out['email']['senderName']=$mail['senderName'];$out['email']['senderEmail']=$mail['senderEmail'];$out['email']['encryption']=$mail['encryption'];
 return $out;
}
function smtpRead($fp):string{$x='';while(($l=fgets($fp,8192))!==false){$x.=$l;if(strlen($l)<4||$l[3]!=='-')break;}return trim($x);}
function mh(string $s):string{return function_exists('mb_encode_mimeheader')?mb_encode_mimeheader($s,'UTF-8'):'=?UTF-8?B?'.base64_encode($s).'?=';}
function sendEmail(array $c,string $to,string $sub,string $html):void{
 $host=trim((string)($c['smtpHost']??''));$port=(int)($c['smtpPort']??465);$user=trim((string)($c['smtpUser']??''));$pass=(string)($c['smtpPass']??'');$from=trim((string)($c['senderEmail']??$user));$name=trim((string)($c['senderName']??'Tatkal Guru'));$enc=strtolower((string)($c['encryption']??'ssl'));
 if(!$host||!$user||!$pass||!$from)throw new RuntimeException('SMTP settings incomplete');
 $fp=@stream_socket_client((($enc==='ssl'||$port===465)?'ssl://':'').$host.':'.$port,$e,$es,15,STREAM_CLIENT_CONNECT);if(!$fp)throw new RuntimeException('SMTP connection failed');stream_set_timeout($fp,15);smtpRead($fp);
 $cmd=function($x,$codes)use($fp){fwrite($fp,$x."\r\n");$r=smtpRead($fp);if(!in_array((int)substr($r,0,3),$codes,true))throw new RuntimeException('SMTP error');};
 $cmd('EHLO tatkalguru.com',[250]);if($enc==='tls'&&$port!==465){$cmd('STARTTLS',[220]);stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT);$cmd('EHLO tatkalguru.com',[250]);}
 try{$cmd('AUTH LOGIN',[334]);$cmd(base64_encode($user),[334]);$cmd(base64_encode($pass),[235]);}catch(Throwable $x){$cmd('AUTH PLAIN '.base64_encode("\0$user\0$pass"),[235]);}
 $cmd('MAIL FROM:<'.$from.'>',[250]);$cmd('RCPT TO:<'.$to.'>',[250,251]);$cmd('DATA',[354]);$headers='From: '.mh($name).' <'.$from.">\r\nTo: <$to>\r\nSubject: ".mh($sub)."\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nDate: ".date(DATE_RFC2822)."\r\n\r\n";$cmd($headers.$html."\r\n.",[250]);@fwrite($fp,"QUIT\r\n");fclose($fp);
}
function httpPost(string $url,array $headers,array $body):array{$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_HTTPHEADER=>array_merge(['Content-Type: application/json','Accept: application/json,text/plain,*/*'],$headers),CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>25,CURLOPT_SSL_VERIFYPEER=>true]);$r=curl_exec($ch);$e=curl_error($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if($r===false)throw new RuntimeException($e?:'Provider connection failed');if($code>=400)throw new RuntimeException('Provider HTTP '.$code);return [$r,$code];}
function sendSms(array $c,string $to,string $message):void{$url=trim((string)($c['apiUrl']??''));$key=(string)($c['apiKey']??'');if(!$url||!$key)throw new RuntimeException('SMS provider settings incomplete');httpPost($url,['Authorization: Bearer '.$key],['to'=>$to,'sender_id'=>(string)($c['senderId']??''),'message'=>$message]);}
function sendWhatsApp(array $c,string $to,string $message,string $template=''):void{
 $mode=strtolower((string)($c['mode']??'api'));$url=trim((string)($c['apiUrl']??''));$token=(string)($c['apiToken']??'');
 if($mode==='web' || $mode==='web_automation'){ $bridge=trim((string)($c['webhookUrl']??''));if(!$bridge)throw new RuntimeException('WhatsApp Web bridge URL is not configured');httpPost($bridge,['Authorization: Bearer '.$token],['to'=>$to,'message'=>$message,'template'=>$template]);return; }
 if(!$url||!$token)throw new RuntimeException('WhatsApp API settings incomplete');httpPost($url,['Authorization: Bearer '.$token],['to'=>$to,'message'=>$message,'template'=>$template,'phone_id'=>(string)($c['phoneId']??'')]);
}
function addLog(PDO $pdo,array $row):void{static $ok=false;if(!$ok){$pdo->exec("CREATE TABLE IF NOT EXISTS notification_logs(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,event_name VARCHAR(80) NOT NULL,user_id VARCHAR(190) NULL,recipient VARCHAR(255) NULL,channel VARCHAR(30) NOT NULL,status VARCHAR(30) NOT NULL,error_message TEXT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,sent_at TIMESTAMP NULL,INDEX(event_name),INDEX(user_id),INDEX(status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");$ok=true;}$q=$pdo->prepare('INSERT INTO notification_logs(event_name,user_id,recipient,channel,status,error_message,sent_at) VALUES(?,?,?,?,?,?,'.($row['status']==='Sent'?'NOW()':'NULL').')');$q->execute([$row['event'],$row['user_id']??null,$row['recipient']??null,$row['channel'],$row['status'],$row['error']??null]);}
function inbox(PDO $pdo,string $userId,string $role):array{static $ready=false;if(!$ready){$pdo->exec("CREATE TABLE IF NOT EXISTS site_notifications(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id VARCHAR(190) NULL,role VARCHAR(20) NOT NULL DEFAULT 'user',title VARCHAR(255) NOT NULL,message TEXT NOT NULL,event_name VARCHAR(80) NOT NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX(user_id),INDEX(role),INDEX(is_read)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");$ready=true;}$q=$pdo->prepare('SELECT * FROM site_notifications WHERE (user_id=? OR (user_id IS NULL AND role=?)) ORDER BY id DESC LIMIT 100');$q->execute([$userId,$role]);return $q->fetchAll();}

$pdo=db();$in=json_decode(file_get_contents('php://input')?:'',true);if(!is_array($in))$in=$_POST;if(!is_array($in))njson(false,'Invalid request');$action=(string)($in['action']??'send');
if($action==='get_settings'){
 $c=cfg($pdo); njson(true,'OK',['settings'=>$c]);
}
if($action==='save_settings'){
 $incoming=$in['settings']??[]; if(!is_array($incoming)) njson(false,'Invalid settings.');
 $s=nload($pdo,'sh_api_settings',[]); $old=is_array($s['notificationSettings']??null)?$s['notificationSettings']:[];
 $base=cfg($pdo);
 $merged=array_replace_recursive($base,$old,$incoming);
 // Keep SMTP credentials in the existing mailSettings block. Do not create a second SMTP config.
 $existingMail=is_array($s['mailSettings']??null)?$s['mailSettings']:[];
 $merged['email']=array_replace_recursive($base['email'],$existingMail,['enabled'=>(bool)($incoming['email']['enabled']??$base['email']['enabled'])]);
 $s['mailSettings']=$merged['email'];
 $s['notificationSettings']=$merged; nsave($pdo,'sh_api_settings',$s);
 njson(true,'Notification settings saved. Existing SMTP Mail Setup is being used.',['settings'=>$merged]);
}
if($action==='test'){
 $channel=strtolower((string)($in['channel']??'')); $to=trim((string)($in['to']??'')); $c=cfg($pdo); $msg='Tatkal Guru test notification - '.date('Y-m-d H:i:s');
 try{
  if($channel==='email'){ if(!$to) $to=(string)$c['adminEmail']; sendEmail($c['email'],$to,'Tatkal Guru Notification Test','<p>'.$msg.'</p>'); }
  elseif($channel==='sms'){ if(!$to) $to=(string)$c['adminMobile']; sendSms($c['sms'],$to,$msg); }
  elseif($channel==='whatsapp'){ if(!$to) $to=(string)$c['adminWhatsApp']; sendWhatsApp($c['whatsapp'],preg_replace('/\D+/','',$to),$msg,(string)($c['whatsapp']['template']??'')); }
  elseif($channel==='website'){ $pdo->exec("CREATE TABLE IF NOT EXISTS site_notifications(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id VARCHAR(190) NULL,role VARCHAR(20) NOT NULL DEFAULT 'user',title VARCHAR(255) NOT NULL,message TEXT NOT NULL,event_name VARCHAR(80) NOT NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX(user_id),INDEX(role),INDEX(is_read)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); $q=$pdo->prepare("INSERT INTO site_notifications(user_id,role,title,message,event_name) VALUES(NULL,'admin',?,?,?)"); $q->execute(['Notification Test',$msg,'test']); }
  else njson(false,'Invalid test channel.');
  njson(true,ucfirst($channel).' test successful.');
 }catch(Throwable $e){ njson(false,ucfirst($channel).' test failed: '.$e->getMessage()); }
}
if($action==='setup'){
 $s=nload($pdo,'sh_api_settings',[]);$s['notificationSettings']=array_replace_recursive(cfg($pdo),is_array($s['notificationSettings']??null)?$s['notificationSettings']:[]);$s['notificationSettings']['adminEmail']=$s['notificationSettings']['adminEmail']?:'irsad98@gmail.com';nsave($pdo,'sh_api_settings',$s);
 $pdo->exec("CREATE TABLE IF NOT EXISTS site_notifications(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id VARCHAR(190) NULL,role VARCHAR(20) NOT NULL DEFAULT 'user',title VARCHAR(255) NOT NULL,message TEXT NOT NULL,event_name VARCHAR(80) NOT NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX(user_id),INDEX(role),INDEX(is_read)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");$pdo->exec("CREATE TABLE IF NOT EXISTS notification_logs(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,event_name VARCHAR(80) NOT NULL,user_id VARCHAR(190) NULL,recipient VARCHAR(255) NULL,channel VARCHAR(30) NOT NULL,status VARCHAR(30) NOT NULL,error_message TEXT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,sent_at TIMESTAMP NULL,INDEX(event_name),INDEX(user_id),INDEX(status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");nsave($pdo,'notification_setup_locked',['locked'=>true,'version'=>1,'at'=>gmdate('c')]);njson(true,'Notification hard setup completed.');
}
if($action==='inbox'){njson(true,'OK',['notifications'=>inbox($pdo,(string)($in['userId']??''),(string)($in['role']??'user'))]);}
if($action==='mark_read'){$q=$pdo->prepare('UPDATE site_notifications SET is_read=1 WHERE id=? AND (user_id=? OR (user_id IS NULL AND role=?))');$q->execute([(int)($in['id']??0),(string)($in['userId']??''),(string)($in['role']??'user')]);njson(true,'Marked as read.');}
$type=(string)($in['type']??'event');$p=is_array($in['payload']??null)?$in['payload']:[];$user=is_array($p['user']??null)?$p['user']:[];$adminTarget=is_array($p['admin']??null)?$p['admin']:[];$item=is_array($p['item']??null)?$p['item']:[];$settings=cfg($pdo);if(!$settings['enabled'])njson(true,'Master notifications disabled.');
$labels=['registration'=>'Registration','balance_request'=>'Balance Add Request','balance_approved'=>'Balance Approved','balance_rejected'=>'Balance Rejected','password_otp'=>'Password Forgot OTP','order_confirmation'=>'Order Confirmation','order_status'=>'Order Status Changed'];$label=$labels[$type]??'Account Notification';$name=(string)($user['fullName']??$user['name']??'User');$email=filter_var((string)($user['email']??''),FILTER_VALIDATE_EMAIL);$mobile=preg_replace('/\D+/','',(string)($user['mobile']??$user['phone']??''));$orderId=(string)($item['order_id']??$item['orderId']??$item['id']??'');$amount=(string)($item['amount']??$item['totalAmount']??'');$status=(string)($item['status']??'');$otp=(string)($item['otp']??'');$message=(string)($p['message']??($label.' notification for '.$name));$message=str_replace(['{{name}}','{{email}}','{{mobile}}','{{order_id}}','{{amount}}','{{status}}','{{otp}}','{{date}}','{{time}}'],[$name,(string)$email,$mobile,$orderId,$amount,$status,$otp,date('Y-m-d'),date('H:i:s')],$message);
$title='Tatkal Guru - '.$label;$html='<div style="font-family:Arial,sans-serif;max-width:650px;margin:auto"><h2>Tatkal Guru</h2><p><b>'.esc($label).'</b></p><p>'.nl2br(esc($message)).'</p></div>';
$targets=[];if($email)$targets[]=['email',$email];if($mobile)$targets[]=['sms',$mobile];$wa=(string)($user['whatsapp']??$user['mobile']??'');if($wa)$targets[]=['whatsapp',preg_replace('/\D+/','',$wa)];$adminEmail=filter_var((string)$settings['adminEmail'],FILTER_VALIDATE_EMAIL);$adminMobile=preg_replace('/\D+/','',(string)$settings['adminMobile']);$adminWa=preg_replace('/\D+/','',(string)$settings['adminWhatsApp']);
// Website notification is always recorded independently for the target user and admin.
$pdo->exec("CREATE TABLE IF NOT EXISTS site_notifications(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id VARCHAR(190) NULL,role VARCHAR(20) NOT NULL DEFAULT 'user',title VARCHAR(255) NOT NULL,message TEXT NOT NULL,event_name VARCHAR(80) NOT NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX(user_id),INDEX(role),INDEX(is_read)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
if(!empty($settings['website']['enabled'])){$q=$pdo->prepare('INSERT INTO site_notifications(user_id,role,title,message,event_name) VALUES(?,?,?,?,?)');if(!empty($user['id']))$q->execute([(string)$user['id'],'user',$title,$message,$type]);$q->execute([null,'admin',$title,$message,$type]);addLog($pdo,['event'=>$type,'user_id'=>$user['id']??null,'channel'=>'website','status'=>'Sent']);}
$sent=0;$errors=[];$mailC=$settings['email'];$smsC=$settings['sms'];$waC=$settings['whatsapp'];
$sendTo=function(string $channel,string $recipient)use(&$sent,&$errors,$pdo,$type,$user,$html,$message,$label,$settings,$mailC,$smsC,$waC){try{if($channel==='email'){sendEmail($mailC,$recipient,'Tatkal Guru - '.$label.' Notification',$html);}elseif($channel==='sms'){sendSms($smsC,$recipient,$message);}else{sendWhatsApp($waC,$recipient,$message,(string)($waC['template']??''));}$sent++;addLog($pdo,['event'=>$type,'user_id'=>$user['id']??null,'recipient'=>$recipient,'channel'=>$channel,'status'=>'Sent']);}catch(Throwable $e){$errors[]=$channel.': '.$e->getMessage();addLog($pdo,['event'=>$type,'user_id'=>$user['id']??null,'recipient'=>$recipient,'channel'=>$channel,'status'=>'Failed','error'=>$e->getMessage()]);}};
if(!empty($settings['email']['enabled'])&&$email)$sendTo('email',$email);if(!empty($settings['sms']['enabled'])&&$mobile)$sendTo('sms',$mobile);if(!empty($settings['whatsapp']['enabled'])&&$wa)$sendTo('whatsapp',$wa);
if($adminEmail&&(!empty($settings['email']['enabled'])))$sendTo('email',$adminEmail);if($adminMobile&&(!empty($settings['sms']['enabled'])))$sendTo('sms',$adminMobile);if($adminWa&&(!empty($settings['whatsapp']['enabled'])))$sendTo('whatsapp',$adminWa);
njson(true,'Notification processed.',['event'=>$type,'sent'=>$sent,'errors'=>$errors]);

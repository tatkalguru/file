<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function out(bool $ok,string $message,array $extra=[]):void{echo json_encode(array_merge(['ok'=>$ok,'message'=>$message],$extra),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function items():array{
 $db=json_decode(@file_get_contents(__DIR__.'/../data/app_storage.json')?:'',true);
 return is_array($db['items']??null)?$db['items']:[];
}
function getItem(array $it,string $key,$def=null){
 if(!isset($it[$key]['value']))return $def;
 $v=json_decode((string)$it[$key]['value'],true);
 return $v===null&&trim((string)$it[$key]['value'])!=='null'?$def:$v;
}
function httpGet(string $url):array{
 $ch=curl_init($url);
 curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>25,CURLOPT_USERAGENT=>'TatkalGuru-SMS-Gateway/1.0',CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_HTTPHEADER=>['Accept: application/json,text/plain,*/*']]);
 $body=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
 if($body===false) throw new RuntimeException('Provider connection failed: '.$err);
 if($code>=400) throw new RuntimeException('Provider HTTP '.$code);
 return [$body,$code];
}
function cfg(array $api,string $provider):array{
 $provider=strtolower($provider);
 if(str_contains($provider,'server 1')||str_contains($provider,'grizzly')){
   return ['key'=>(string)($api['grizzlyApiKey']??''),'base'=>(string)($api['grizzlyApiBaseUrl']??'https://api.grizzlysms.com/stubs/handler_api.php')];
 }
 $base=(string)($api['smsIndiaApiBaseUrl']??'https://api.smsindia.pro/stubs/handler_api.php');
 $base=str_replace('api.smsindia.pro.com','api.smsindia.pro',$base);
 return ['key'=>(string)($api['smsIndiaApiKey']??''),'base'=>$base];
}
function callProvider(array $c,array $q):string{
 if($c['key']==='')throw new RuntimeException('SMS API key is not configured.');
 $q=array_merge(['api_key'=>$c['key']],$q);
 $url=$c['base'].'?'.http_build_query($q);
 [$body,]=httpGet($url);
 return trim($body);
}
$in=json_decode(file_get_contents('php://input')?:'',true);
if(!is_array($in))out(false,'Invalid request.');
$it=items();$api=getItem($it,'sh_api_settings',[]);if(!is_array($api))$api=[];
$action=(string)($in['action']??'');$provider=(string)($in['provider']??'');
$c=cfg($api,$provider);

try{
 if($action==='buy'){
   $service=preg_replace('/[^a-zA-Z0-9_\-]/','',(string)($in['service']??''));
   $country=(string)($in['country']??'22'); // India = 22 on compatible activation APIs
   if($service==='')out(false,'SMS service code is missing.');
   $body=callProvider($c,['action'=>'getNumberV2','service'=>$service,'country'=>$country]);
   $id='';$phone='';$cost=null;
   $j=json_decode($body,true);
   if(is_array($j)&&isset($j['activationId'])){
      $id=(string)$j['activationId'];$phone=(string)($j['phoneNumber']??'');$cost=$j['activationCost']??null;
   } elseif(preg_match('/ACCESS_NUMBER:([^:]+):(.+)/',$body,$m)){
      $id=$m[1];$phone=$m[2];
   } else {
      // fallback to legacy getNumber
      $body=callProvider($c,['action'=>'getNumber','service'=>$service,'country'=>$country]);
      if(preg_match('/ACCESS_NUMBER:([^:]+):(.+)/',$body,$m)){$id=$m[1];$phone=$m[2];}
   }
   if($id===''||$phone==='')out(false,'Provider did not return a phone number: '.$body);
   out(true,'Live SMS number assigned.',['activationId'=>$id,'phoneNumber'=>$phone,'providerResponse'=>$body,'activationCost'=>$cost]);
 }
 if($action==='check'){
   $id=(string)($in['activationId']??'');if($id==='')out(false,'Activation ID missing.');
   $body=callProvider($c,['action'=>'getStatusV2','id'=>$id]);
   $j=json_decode($body,true);$code='';$status='Waiting';
   if(is_array($j)&&isset($j['sms']['code'])){$code=(string)$j['sms']['code'];$status='Received';}
   elseif(preg_match('/STATUS_OK:([^\s]+)/',$body,$m)){$code=$m[1];$status='Received';}
   elseif(str_contains($body,'STATUS_CANCEL'))$status='Cancelled';
   out(true,$code!==''?'OTP received':'SMS still waiting.',['status'=>$status,'otpCode'=>$code,'providerResponse'=>$body]);
 }
 if($action==='cancel'){
   $id=(string)($in['activationId']??'');if($id==='')out(false,'Activation ID missing.');
   $body=callProvider($c,['action'=>'setStatus','status'=>'8','id'=>$id]);
   $ok=str_contains($body,'ACCESS_CANCEL')||str_contains($body,'STATUS_CANCEL');
   out($ok,$ok?'Provider activation cancelled.':'Provider cancellation response: '.$body,['providerResponse'=>$body]);
 }
 if($action==='balance'){
   $body=callProvider($c,['action'=>'getBalance']);
   out(true,'Provider balance returned.',['balanceResponse'=>$body]);
 }
 out(false,'Unknown SMS action.');
}catch(Throwable $e){out(false,$e->getMessage());}
?>
